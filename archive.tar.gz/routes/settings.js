import express from 'express';

export default function(dependencies) {
  const router = express.Router();
  const { getDb, requireAdmin } = dependencies;

router.get('/office-config', (req, res) => {
    const db = getDb();
  const cfg = Object.fromEntries(OFFICE_KEYS.map(k => [k, getConfig(k)]));
  res.json(cfg);
});

router.post('/office-config', (req, res) => requireAdmin(req, res, () => {
  for (const k of OFFICE_KEYS) if (k in req.body) setConfig(k, req.body[k] === '' ? null : req.body[k]);
  res.json(Object.fromEntries(OFFICE_KEYS.map(k => [k, getConfig(k)])));
}));

router.get('/settings', (req, res) => {
    const db = getDb();
  const getList = (key, defaults) => {
    const val = getConfig(key);
    try { if (val) return JSON.parse(val); } catch {}
    return defaults;
  };

  // Auto-align with active employees list (all employees are consultants by default)
  let activeEmployees = [];
  try {
    activeEmployees = db.prepare("SELECT id, name, emp_id, role FROM employees WHERE active = 'Yes' OR active IS NULL OR active = '1' ORDER BY name").all();
  } catch (e) {
    console.error("Could not fetch active employees for settings:", e);
  }
  const customConsultants = getList('settings_consultants', ['Ema','Afsana','Sakib','Mukta','Rafi','Admin']);
  const combinedConsultants = Array.from(new Set([...activeEmployees.map(e => e.name), ...customConsultants])).filter(Boolean).sort();

  // Document templates from settings (object keyed by destination)
  let docTemplates = DOC_TEMPLATES;
  try {
    const saved = getConfig('settings_docTemplates');
    if (saved) docTemplates = JSON.parse(saved);
  } catch {}

  res.json({
    consultants: combinedConsultants,
    employees: activeEmployees,
    leadSources: getList('settings_leadSources', ['China Web Form','Web Lead (New)','Client Sheet','WhatsApp','Facebook Ad','Instagram Ad','Referral','Walk-in','YouTube','Google Ad','Meta Lead Ad']),
    destinations: getList('settings_destinations', ['China', 'Malta', 'Hungary', 'Greece', 'Estonia', 'Georgia', 'Malaysia', 'Thailand']),
    leadStatuses: getList('settings_leadStatuses', ['New Lead','No Response','Positive','Office Visited','File Opened','Enrolled','Not Interested']),
    fileStages: getList('settings_fileStages', [
      'Documents Collecting',
      'Documents Ready',
      'Applied to University',
      'Interview',
      'Pre-Admission',
      'Deposit',
      'Admission/JW Received',
      'Visa Applied',
      'Visa Approved',
      'Visa Rejected',
      'Enrolled',
      'Cancelled',
      'Withdraw'
    ]),
    paymentStatuses: getList('settings_paymentStatuses', ['Pending','Partial','Paid','Refunded']),
    incomeCategories: getList('settings_incomeCategories', ['Service Charge','Application Deposit','App Fee','File Opening','Marketing Refund','Invest','Previous Cash','Other Income']),
    expenseCategories: getList('settings_expenseCategories', ['Salary','Office Rent','Marketing','Air Ticket','Airport Pickup','App Fee','Visa Fee','Medical','Mobile Recharge','Client Lunch+Snacks','Transport','Bua Bill','Tissue+Room Spray','Letterhead','Logo','Job Post','Testimonial Video','Review','Yearly Fee','Electrician+Sign Board','Mata Support','Other Expense']),
    docTemplates,
  });
});

router.post('/settings', (req, res) => requireAdmin(req, res, () => {
  const { key, value } = req.body || {};
  if (!key) {
    return res.status(400).json({ error: 'key is required' });
  }
  const allowedKeys = [
    'settings_consultants',
    'settings_leadSources',
    'settings_destinations',
    'settings_leadStatuses',
    'settings_fileStages',
    'settings_paymentStatuses',
    'settings_incomeCategories',
    'settings_expenseCategories',
    'settings_docTemplates'
  ];
  if (!allowedKeys.includes(key)) {
    return res.status(400).json({ error: 'invalid settings key' });
  }
  setConfig(key, JSON.stringify(value));
  res.json({ ok: true });
}));

  return router;
}
