import express from 'express';

export default function(dependencies) {
  const { getDb, requireAdmin, hashPassword, logActivity } = dependencies;
  const router = express.Router();

  router.get('/', (req, res) => requireAdmin(req, res, () => {
    const db = getDb();
    const users = db.prepare("SELECT id,email,name,role,consultant_name,emp_id,active,created_at,last_login FROM users ORDER BY id").all();
    for (const u of users) {
      const roles = db.prepare("SELECT role FROM user_roles WHERE user_id=?").all(u.id).map(r => r.role);
      u.roles = roles.length ? roles : [u.role === 'admin' ? 'founder_ceo' : u.role === 'manager' ? 'application_manager' : 'consultant'];
    }
    res.json(users);
  }));

  router.post('/', (req, res) => requireAdmin(req, res, () => {
    const db = getDb();
    const { email, name, password, role = 'consultant', roles = [], consultant_name = null, emp_id = null } = req.body || {};
    if (!email || !password) return res.status(400).json({ error: 'email and password required' });
    try {
      const safeRole = ['admin', 'manager', 'consultant'].includes(role) ? role : 'consultant';
      const info = db.prepare(`INSERT INTO users (email,name,password_hash,role,consultant_name,emp_id) VALUES (?,?,?,?,?,?)`)
        .run(String(email).toLowerCase().trim(), name || null, hashPassword(password), safeRole, consultant_name, emp_id);
      const newUserId = info.lastInsertRowid;
      
      const newRoles = Array.isArray(roles) && roles.length ? roles : [safeRole === 'admin' ? 'founder_ceo' : safeRole === 'manager' ? 'application_manager' : 'consultant'];
      const insertRole = db.prepare(`INSERT OR IGNORE INTO user_roles (user_id, role) VALUES (?, ?)`);
      for (const r of newRoles) insertRole.run(newUserId, r);
      
      const u = db.prepare("SELECT id,email,name,role,consultant_name,emp_id,active FROM users WHERE id=?").get(newUserId);
      u.roles = newRoles;
      logActivity({ type: 'user_created', actor: req.user, to: u.email, details: { role: u.role, roles: newRoles, consultant_name: u.consultant_name } });
      res.json(u);
    } catch (e) {
      res.status(400).json({ error: e.message.includes('UNIQUE') ? 'That email is already in use' : e.message });
    }
  }));

  router.put('/:id', (req, res) => requireAdmin(req, res, () => {
    const db = getDb();
    const { name, role, roles, consultant_name, emp_id, active, password } = req.body || {};
    const cur = db.prepare("SELECT * FROM users WHERE id=?").get(req.params.id);
    if (!cur) return res.status(404).json({ error: 'Not found' });
    
    const newHash = password ? hashPassword(password) : cur.password_hash;
    db.prepare(`UPDATE users SET name=COALESCE(?,name), role=COALESCE(?,role), consultant_name=COALESCE(?,consultant_name), emp_id=COALESCE(?,emp_id), active=COALESCE(?,active), password_hash=? WHERE id=?`)
      .run(name ?? null, role ?? null, consultant_name ?? null, emp_id ?? null, active ?? null, newHash, req.params.id);
    
    if (Array.isArray(roles)) {
      db.prepare("DELETE FROM user_roles WHERE user_id=?").run(req.params.id);
      const insertRole = db.prepare("INSERT OR IGNORE INTO user_roles (user_id, role) VALUES (?, ?)");
      for (const r of roles) insertRole.run(req.params.id, r);
    }
    
    const u = db.prepare("SELECT id,email,name,role,consultant_name,emp_id,active FROM users WHERE id=?").get(req.params.id);
    const updatedRoles = db.prepare("SELECT role FROM user_roles WHERE user_id=?").all(req.params.id).map(r => r.role);
    u.roles = updatedRoles.length ? updatedRoles : [role === 'admin' ? 'founder_ceo' : role === 'manager' ? 'application_manager' : 'consultant'];
    res.json(u);
  }));

  router.delete('/:id', (req, res) => requireAdmin(req, res, () => {
    const db = getDb();
    if (parseInt(req.params.id) === req.user.id) return res.status(400).json({ error: "You can't delete your own account" });
    db.prepare("DELETE FROM user_roles WHERE user_id=?").run(req.params.id);
    db.prepare("DELETE FROM users WHERE id=?").run(req.params.id);
    res.json({ ok: true });
  }));

  return router;
};
