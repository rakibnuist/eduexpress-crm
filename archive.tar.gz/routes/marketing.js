import express from 'express';

export default function(dependencies) {
  const router = express.Router();
  const { 
    getDb, requireAdmin, requireManagerOrAdmin, userHasRole, isFullAdmin, canViewOwnLeadsOnly, isChinaBlockedForUser, leadIsVisibleTo, logActivity, sendCAPIEvent, uploadLimiter, getConfig, PERSISTENT_HOME, nextChinaLeadId, nextLeadId, leadParams, LEAD_INSERT_SQL, LEAD_UPDATE_SQL, requireMarketing
  } = dependencies;

router.get('/marketing/posts', (req, res) => requireMarketing(req, res, () => {
  const { week, page, status } = req.query;
  const where = [], params = [];
  if (week)   { where.push('week=?');   params.push(week); }
  if (page)   { where.push('page=?');   params.push(page); }
  if (status) { where.push('status=?'); params.push(status); }
  const sql = `SELECT * FROM content_posts ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY post_date, slot_time`;
  res.json(db.prepare(sql).all(...params));
}));

router.get('/marketing/posts/due', (req, res) => requireMarketing(req, res, () => {
  const limit = parseInt(req.query.limit) || 20;
  const rows = db.prepare(
    `SELECT * FROM content_posts WHERE status IN ('approved','asset_ready') ORDER BY created_at DESC LIMIT ?`
  ).all(limit);
  res.json(rows);
}));

router.post('/marketing/posts', (req, res) => requireMarketing(req, res, () => {
  const data = pickFields(req.body, POST_COLS);
  const keys = Object.keys(data);
  if (!keys.length) return res.status(400).json({ error: 'no valid fields' });
  const info = db.prepare(`INSERT INTO content_posts (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`).run(...keys.map(k => data[k]));
  res.json(db.prepare(`SELECT * FROM content_posts WHERE id=?`).get(info.lastInsertRowid));
}));

router.put('/marketing/posts/:id/status', (req, res) => requireMarketing(req, res, () => {
  const { status, rejection_reason } = req.body || {};
  const allowed = ['drafted','approved','edit','rejected','asset_ready','scheduled','published'];
  if (!allowed.includes(status)) return res.status(400).json({ error: 'invalid status' });
  db.prepare(`UPDATE content_posts SET status=?, rejection_reason=?, updated_at=datetime('now') WHERE id=?`)
    .run(status, rejection_reason || null, req.params.id);
  res.json(db.prepare(`SELECT * FROM content_posts WHERE id=?`).get(req.params.id));
}));

router.put('/marketing/posts/:id/published', (req, res) => requireMarketing(req, res, () => {
  const { published_url, reach, engagement } = req.body || {};
  db.prepare(`UPDATE content_posts SET status='published', published_url=?, reach=?, engagement=?, updated_at=datetime('now') WHERE id=?`)
    .run(published_url || null, reach ?? null, engagement ?? null, req.params.id);
  res.json(db.prepare(`SELECT * FROM content_posts WHERE id=?`).get(req.params.id));
}));

router.put('/marketing/posts/:id', (req, res) => requireMarketing(req, res, () => {
  const data = pickFields(req.body, POST_COLS);
  const keys = Object.keys(data);
  if (!keys.length) return res.status(400).json({ error: 'no valid fields' });
  db.prepare(`UPDATE content_posts SET ${keys.map(k => k + '=?').join(',')}, updated_at=datetime('now') WHERE id=?`)
    .run(...keys.map(k => data[k]), req.params.id);
  res.json(db.prepare(`SELECT * FROM content_posts WHERE id=?`).get(req.params.id));
}));

router.delete('/marketing/posts/:id', (req, res) => requireMarketing(req, res, () => {
  db.prepare(`DELETE FROM content_posts WHERE id=?`).run(req.params.id);
  res.json({ ok: true });
}));

router.post('/marketing/posts/approve-week', (req, res) => requireMarketing(req, res, () => {
  const { week } = req.body || {};
  if (!week) return res.status(400).json({ error: 'week required' });
  const info = db.prepare(`UPDATE content_posts SET status='approved', updated_at=datetime('now') WHERE week=? AND status IN ('drafted','edit')`).run(week);
  logActivity({ type: 'content_week_approved', actor: req.user, to: week, details: { approved: info.changes } });
  res.json({ ok: true, approved: info.changes });
}));

router.post('/marketing/plan/import', (req, res) => requireMarketing(req, res, () => {
  const { week, posts } = req.body || {};
  if (!week || !Array.isArray(posts)) return res.status(400).json({ error: 'week and posts[] required' });
  // Clear only the drafted n8n posts for the PAGES present in this import, so split
  // per-page workflows (china / bd / tiktok) don't wipe each other's drafts. Falls back
  // to clearing the whole week when posts span all pages (single combined import).
  const pages = [...new Set((posts || []).map(p => p && p.page).filter(Boolean))];
  if (pages.length) {
    const ph = pages.map(() => '?').join(',');
    db.prepare(`DELETE FROM content_posts WHERE week=? AND source='n8n' AND status='drafted' AND page IN (${ph})`).run(week, ...pages);
  } else {
    db.prepare(`DELETE FROM content_posts WHERE week=? AND source='n8n' AND status='drafted'`).run(week);
  }
  let inserted = 0;
  const stmt = db.prepare(`INSERT INTO content_posts (${POST_COLS.join(',')}) VALUES (${POST_COLS.map(() => '?').join(',')})`);
  for (const p of posts) {
    const row = { ...p, week, source: 'n8n', status: p.status || 'drafted' };
    stmt.run(...POST_COLS.map(c => row[c] ?? null));
    inserted++;
  }
  logActivity({ type: 'content_plan_imported', actor: req.user, to: week, details: { posts: inserted } });
  if (typeof broadcast === 'function') broadcast('content_plan_ready', { week, count: inserted });
  res.json({ ok: true, week, inserted });
}));

router.get('/marketing/brain', (req, res) => requireMarketing(req, res, () => {
  res.json(db.prepare(`SELECT * FROM brain_api_pool ORDER BY priority`).all());
}));

router.post('/marketing/brain', (req, res) => requireMarketing(req, res, () => {
  const cols = ['priority','provider','model','cred_label','req_min','req_day','used_today','status','cooldown_until','notes'];
  const data = pickFields(req.body, cols);
  const keys = Object.keys(data);
  if (!keys.length) return res.status(400).json({ error: 'no valid fields' });
  const info = db.prepare(`INSERT INTO brain_api_pool (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`).run(...keys.map(k => data[k]));
  res.json(db.prepare(`SELECT * FROM brain_api_pool WHERE id=?`).get(info.lastInsertRowid));
}));

router.put('/marketing/brain/:id', (req, res) => requireMarketing(req, res, () => {
  const cols = ['priority','provider','model','cred_label','req_min','req_day','used_today','status','cooldown_until','notes'];
  const data = pickFields(req.body, cols);
  const keys = Object.keys(data);
  if (!keys.length) return res.status(400).json({ error: 'no valid fields' });
  db.prepare(`UPDATE brain_api_pool SET ${keys.map(k => k + '=?').join(',')} WHERE id=?`).run(...keys.map(k => data[k]), req.params.id);
  res.json(db.prepare(`SELECT * FROM brain_api_pool WHERE id=?`).get(req.params.id));
}));

router.delete('/marketing/brain/:id', (req, res) => requireMarketing(req, res, () => {
  db.prepare(`DELETE FROM brain_api_pool WHERE id=?`).run(req.params.id);
  res.json({ ok: true });
}));

router.get('/marketing/designer-queue', (req, res) => requireMarketing(req, res, () => {
  const { status, designer_id } = req.query;
  const where = [], params = [];
  if (status) { where.push('status=?'); params.push(status); }
  if (designer_id) { where.push('designer_id=?'); params.push(designer_id); }
  const sql = `SELECT * FROM designer_queue ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY created_at DESC`;
  res.json(db.prepare(sql).all(...params));
}));

router.post('/marketing/designer-queue', (req, res) => requireMarketing(req, res, () => {
  const cols = ['post_id','designer_id','brief','priority','deadline','status','draft_asset_url','final_asset_url','feedback'];
  const data = pickFields(req.body, cols);
  const keys = Object.keys(data);
  if (!keys.length) return res.status(400).json({ error: 'no valid fields' });
  const info = db.prepare(`INSERT INTO designer_queue (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`).run(...keys.map(k => data[k]));
  res.json(db.prepare(`SELECT * FROM designer_queue WHERE id=?`).get(info.lastInsertRowid));
}));

router.put('/marketing/designer-queue/:id', (req, res) => requireMarketing(req, res, () => {
  const cols = ['post_id','designer_id','brief','priority','deadline','status','draft_asset_url','final_asset_url','feedback'];
  const data = pickFields(req.body, cols);
  const keys = Object.keys(data);
  if (!keys.length) return res.status(400).json({ error: 'no valid fields' });
  db.prepare(`UPDATE designer_queue SET ${keys.map(k => k + '=?').join(',')} WHERE id=?`).run(...keys.map(k => data[k]), req.params.id);
  res.json(db.prepare(`SELECT * FROM designer_queue WHERE id=?`).get(req.params.id));
}));

router.delete('/marketing/designer-queue/:id', (req, res) => requireMarketing(req, res, () => {
  db.prepare(`DELETE FROM designer_queue WHERE id=?`).run(req.params.id);
  res.json({ ok: true });
}));

router.get('/marketing/posts/:id/quality', (req, res) => requireMarketing(req, res, () => {
  const post = db.prepare(`SELECT id, quality_score, quality_checks FROM content_posts WHERE id=?`).get(req.params.id);
  if (!post) return res.status(404).json({ error: 'not found' });
  res.json(post);
}));

router.put('/marketing/posts/:id/quality', (req, res) => requireMarketing(req, res, () => {
  const { quality_score, quality_checks } = req.body || {};
  db.prepare(`UPDATE content_posts SET quality_score=?, quality_checks=?, updated_at=datetime('now') WHERE id=?`)
    .run(quality_score ?? null, quality_checks ?? null, req.params.id);
  res.json(db.prepare(`SELECT * FROM content_posts WHERE id=?`).get(req.params.id));
}));

router.get('/marketing/analytics/overview', (req, res) => requireMarketing(req, res, () => {
  const days = parseInt(req.query.days) || 30;
  const total = db.prepare(`SELECT COUNT(*) as c FROM content_posts`).get().c;
  const published = db.prepare(`SELECT COUNT(*) as c FROM content_posts WHERE status='published' AND created_at >= date('now', '-${days} days')`).get().c;
  const drafted = db.prepare(`SELECT COUNT(*) as c FROM content_posts WHERE status='drafted'`).get().c;
  const avgReach = db.prepare(`SELECT AVG(reach) as avg FROM content_posts WHERE status='published' AND created_at >= date('now', '-${days} days')`).get().avg || 0;
  const totalLeads = db.prepare(`SELECT SUM(leads) as s FROM content_posts WHERE status='published' AND created_at >= date('now', '-${days} days')`).get().s || 0;
  res.json({ total, published, drafted, avgReach: Math.round(avgReach), totalLeads });
}));

router.get('/marketing/analytics/funnel', (req, res) => requireMarketing(req, res, () => {
  const days = parseInt(req.query.days) || 30;
  const reach = db.prepare(`SELECT SUM(reach) as s FROM content_posts WHERE status='published' AND created_at >= date('now', '-${days} days')`).get().s || 0;
  const leads = db.prepare(`SELECT COUNT(*) as c FROM leads WHERE created_at >= date('now', '-${days} days')`).get().c || 0;
  const files = db.prepare(`SELECT COUNT(*) as c FROM leads WHERE application_stage IS NOT NULL AND created_at >= date('now', '-${days} days')`).get().c || 0;
  const enrolled = db.prepare(`SELECT COUNT(*) as c FROM leads WHERE lead_status='enrolled' AND created_at >= date('now', '-${days} days')`).get().c || 0;
  res.json({ reach, leads, files, enrolled, conversion_leads: reach ? (leads/reach*100).toFixed(1) : 0, conversion_files: leads ? (files/leads*100).toFixed(1) : 0, conversion_enrolled: files ? (enrolled/files*100).toFixed(1) : 0 });
}));

router.get('/marketing/analytics/pillars', (req, res) => requireMarketing(req, res, () => {
  const days = parseInt(req.query.days) || 30;
  const rows = db.prepare(`SELECT pillar, COUNT(*) as posts, AVG(reach) as avg_reach, AVG(engagement) as avg_engagement, SUM(leads) as total_leads FROM content_posts WHERE status='published' AND created_at >= date('now', '-${days} days') GROUP BY pillar`).all();
  res.json(rows);
}));

router.get('/marketing/analytics/pages', (req, res) => requireMarketing(req, res, () => {
  const days = parseInt(req.query.days) || 30;
  const rows = db.prepare(`SELECT page, COUNT(*) as posts, AVG(reach) as avg_reach, AVG(engagement) as avg_engagement, SUM(leads) as total_leads FROM content_posts WHERE status='published' AND created_at >= date('now', '-${days} days') GROUP BY page`).all();
  res.json(rows);
}));

router.get('/marketing/analytics/consistency', (req, res) => requireMarketing(req, res, () => {
  // Count published posts per week vs target (7 per page = 28/week total, adjusted for IG=BD, TikTok=3)
  // Target: China 7, BD 7, TikTok 3 = 17 distinct posts/week (Instagram mirrors BD)
  const targetPerWeek = 17;
  const weeks = db.prepare(`SELECT week, COUNT(*) as c FROM content_posts WHERE status='published' GROUP BY week ORDER BY week DESC LIMIT 12`).all();
  const scores = weeks.map(w => ({ week: w.week, published: w.c, target: targetPerWeek, score: Math.round((w.c / targetPerWeek) * 100) }));
  res.json(scores);
}));

router.get('/marketing/analytics/attribution', (req, res) => requireMarketing(req, res, () => {
  const days = parseInt(req.query.days) || 30;
  const rows = db.prepare(`
    SELECT cp.page, cp.pillar, cp.hook, cp.id as post_id, COUNT(la.lead_id) as lead_count, SUM(la.enrollment_value) as revenue
    FROM content_posts cp
    LEFT JOIN lead_attribution la ON cp.id = la.content_post_id
    WHERE cp.status='published' AND cp.created_at >= date('now', '-${days} days')
    GROUP BY cp.id
    ORDER BY lead_count DESC
    LIMIT 50
  `).all();
  res.json(rows);
}));

router.get('/marketing/analytics/hook-performance', (req, res) => requireMarketing(req, res, () => {
  const days = parseInt(req.query.days) || 30;
  const rows = db.prepare(`
    SELECT hook, COUNT(*) as uses, AVG(reach) as avg_reach, AVG(engagement) as avg_engagement, SUM(leads) as total_leads
    FROM content_posts
    WHERE status='published' AND hook IS NOT NULL AND created_at >= date('now', '-${days} days')
    GROUP BY hook
    ORDER BY total_leads DESC
    LIMIT 20
  `).all();
  res.json(rows);
}));

router.get('/marketing/analytics/scale-up-signals', (req, res) => requireMarketing(req, res, () => {
  const days = parseInt(req.query.days) || 30;
  const pillars = db.prepare(`SELECT pillar, AVG(engagement) as avg_engagement FROM content_posts WHERE status='published' AND created_at >= date('now', '-${days} days') GROUP BY pillar ORDER BY avg_engagement DESC`).all();
  const pages = db.prepare(`SELECT page, AVG(engagement) as avg_engagement FROM content_posts WHERE status='published' AND created_at >= date('now', '-${days} days') GROUP BY page ORDER BY avg_engagement DESC`).all();
  const topHooks = db.prepare(`SELECT hook, AVG(reach) as avg_reach FROM content_posts WHERE status='published' AND hook IS NOT NULL AND created_at >= date('now', '-${days} days') GROUP BY hook ORDER BY avg_reach DESC LIMIT 10`).all();
  res.json({ pillars, pages, topHooks });
}));

router.get('/marketing/research/competitor-summary', (req, res) => requireMarketing(req, res, () => {
  const days = parseInt(req.query.days) || 30;
  const rows = db.prepare(`
    SELECT competitor, COUNT(*) as findings, 
      SUM(CASE WHEN urgency='critical' THEN 1 ELSE 0 END) as critical_count,
      SUM(CASE WHEN urgency='high' THEN 1 ELSE 0 END) as high_count,
      MAX(research_date) as last_seen
    FROM research_intelligence
    WHERE research_date >= date('now', '-${days} days')
    GROUP BY competitor
    ORDER BY findings DESC
  `).all();
  res.json(rows);
}));

router.get('/marketing/research/feed', (req, res) => requireMarketing(req, res, () => {
  const limit = parseInt(req.query.limit) || 50;
  const rows = db.prepare(`
    SELECT * FROM research_intelligence
    ORDER BY 
      CASE urgency
        WHEN 'critical' THEN 1
        WHEN 'high' THEN 2
        WHEN 'normal' THEN 3
        WHEN 'low' THEN 4
      END,
      research_date DESC
    LIMIT ?
  `).all(limit);
  res.json(rows);
}));

router.get('/marketing/kb/universities/search', (req, res) => requireMarketing(req, res, () => {
  const { q, country, limit } = req.query;
  let sql = 'SELECT * FROM kb_universities WHERE 1=1';
  const params = [];
  if (q) { sql += ' AND (name LIKE ? OR city LIKE ? OR programs LIKE ?)'; params.push(`%${q}%`, `%${q}%`, `%${q}%`); }
  if (country) { sql += ' AND country = ?'; params.push(country); }
  sql += ' ORDER BY partner DESC, name LIMIT ?';
  params.push(parseInt(limit) || 20);
  res.json(db.prepare(sql).all(...params));
}));

router.get('/marketing/kb/scholarships/search', (req, res) => requireMarketing(req, res, () => {
  const { q, country, status, limit } = req.query;
  let sql = 'SELECT * FROM kb_scholarships WHERE 1=1';
  const params = [];
  if (q) { sql += ' AND (name LIKE ? OR coverage LIKE ? OR eligibility LIKE ?)'; params.push(`%${q}%`, `%${q}%`, `%${q}%`); }
  if (country) { sql += ' AND country = ?'; params.push(country); }
  if (status) { sql += ' AND status = ?'; params.push(status); }
  sql += ' ORDER BY deadline LIMIT ?';
  params.push(parseInt(limit) || 20);
  res.json(db.prepare(sql).all(...params));
}));

router.get('/marketing/hooks/best', (req, res) => requireMarketing(req, res, () => {
  const { page, pillar, destination, limit } = req.query;
  let sql = 'SELECT * FROM content_hooks WHERE 1=1';
  const params = [];
  if (page) { sql += ' AND (page = ? OR page IS NULL)'; params.push(page); }
  if (pillar) { sql += ' AND (pillar = ? OR pillar IS NULL)'; params.push(pillar); }
  if (destination) { sql += ' AND (destination = ? OR destination IS NULL)'; params.push(destination); }
  sql += ' ORDER BY conversion_rate DESC, usage_count DESC LIMIT ?';
  params.push(parseInt(limit) || 10);
  res.json(db.prepare(sql).all(...params));
}));

router.get('/marketing/research/active', (req, res) => requireMarketing(req, res, () => {
  const rows = db.prepare(`
    SELECT * FROM research_intelligence
    WHERE status IN ('new','reviewed') AND (urgency IN ('critical','high') OR category IN ('viral_signal','offer_alert','trending_topic'))
    ORDER BY urgency_sort, research_date DESC
    LIMIT 20
  `).all();
  res.json(rows);
}));

router.get('/marketing/attribution/summary', (req, res) => requireMarketing(req, res, () => {
  const days = parseInt(req.query.days) || 30;
  const rows = db.prepare(`
    SELECT utm_source, utm_campaign, COUNT(*) as leads, SUM(enrollment_value) as revenue
    FROM lead_attribution
    WHERE first_touch_at >= date('now', '-${days} days')
    GROUP BY utm_source, utm_campaign
    ORDER BY leads DESC
  `).all();
  res.json(rows);
}));

router.get('/marketing/publishing-queue/due', (req, res) => requireMarketing(req, res, () => {
  res.json(db.prepare(`SELECT * FROM publishing_queue WHERE status='queued' AND scheduled_at <= datetime('now') ORDER BY scheduled_at`).all());
}));

router.get('/marketing/llm-config', (req, res) => {
    const db = getDb();
  try {
    const provider = db.prepare("SELECT value FROM meta_config WHERE key='llm_provider'").get()?.value || 'openai';
    const model = db.prepare("SELECT value FROM meta_config WHERE key='llm_model'").get()?.value || 'gpt-4o-mini';
    const hasKey = !!(process.env.OPENAI_API_KEY || process.env.GEMINI_API_KEY || db.prepare("SELECT value FROM meta_config WHERE key='llm_api_key'").get()?.value);
    res.json({ provider, model, hasKey });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/marketing/llm-config', (req, res) => {
    const db = getDb();
  try {
    const { provider, model, apiKey } = req.body || {};
    if (provider) db.prepare("INSERT OR REPLACE INTO meta_config (key, value, updated_at) VALUES ('llm_provider', ?, datetime('now'))").run(provider);
    if (model) db.prepare("INSERT OR REPLACE INTO meta_config (key, value, updated_at) VALUES ('llm_model', ?, datetime('now'))").run(model);
    if (apiKey) db.prepare("INSERT OR REPLACE INTO meta_config (key, value, updated_at) VALUES ('llm_api_key', ?, datetime('now'))").run(apiKey);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/marketing/llm-test', async (req, res) => {
    const db = getDb();
  try {
    const { provider, prompt } = req.body || {};
    
    const HARD_CODED_KEYS = [
      { key:'sk-KF63PVImS4EsF2iaEvwTNHcFNqNVzEoIHJZ8K01poqEM97qZ8smo52DEye5g9KaL', provider:'opencode-go', model:'glm-5.1' }
    ];
    
    let llmProvider = provider || db.prepare("SELECT value FROM meta_config WHERE key='llm_provider'").get()?.value || '';
    let llmModel = db.prepare("SELECT value FROM meta_config WHERE key='llm_model'").get()?.value || '';
    let llmApiKey = db.prepare("SELECT value FROM meta_config WHERE key='llm_api_key'").get()?.value || process.env.OPENAI_API_KEY || process.env.GEMINI_API_KEY || process.env.OPENCODE_GO_API_KEY || '';
    
    if (!llmApiKey && HARD_CODED_KEYS.length > 0) {
      const fallback = HARD_CODED_KEYS[0];
      llmApiKey = fallback.key;
      llmProvider = fallback.provider;
      llmModel = fallback.model;
    }
    
    if (!llmApiKey) return res.status(400).json({ error: 'No LLM API key available' });
    if (!llmProvider) {
      if (llmApiKey.startsWith('AIza')) llmProvider = 'gemini';
      else llmProvider = 'opencode-go';
    }
    if (!llmModel) {
      if (llmProvider === 'opencode-go') llmModel = 'glm-5.1';
      if (llmProvider === 'openai') llmModel = 'gpt-4o-mini';
      if (llmProvider === 'gemini') llmModel = 'gemini-1.5-pro-latest';
    }
    
    let result = null;
    let error = null;
    let statusCode = null;
    let rawResponse = null;
    
    try {
      if (llmProvider === 'opencode-go') {
        const resp = await fetch('https://api.opencode.ai/v1/chat/completions', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${llmApiKey}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: llmModel,
            messages: [{ role: 'user', content: prompt || 'Say "hello" and return a JSON with key "status" set to "ok"' }],
            temperature: 0.7,
            max_tokens: 200
          })
        });
        statusCode = resp.status;
        rawResponse = await resp.text();
        try { result = JSON.parse(rawResponse); } catch {}
      } else if (llmProvider === 'openai') {
        const resp = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${llmApiKey}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: llmModel,
            messages: [{ role: 'user', content: prompt || 'Say hello' }],
            temperature: 0.7,
            max_tokens: 200
          })
        });
        statusCode = resp.status;
        rawResponse = await resp.text();
        try { result = JSON.parse(rawResponse); } catch {}
      } else if (llmProvider === 'gemini') {
        const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${llmModel}:generateContent?key=${llmApiKey}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ contents: [{ parts: [{ text: prompt || 'Say hello' }] }] })
        });
        statusCode = resp.status;
        rawResponse = await resp.text();
        try { result = JSON.parse(rawResponse); } catch {}
      }
    } catch (netErr) {
      error = netErr.message;
    }
    
    res.json({
      provider: llmProvider,
      model: llmModel,
      hasKey: !!llmApiKey,
      keyPrefix: llmApiKey.slice(0, 7) + '...',
      statusCode,
      error,
      rawResponse: rawResponse?.slice(0, 1000),
      parsedResponse: result
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/marketing/generate', async (req, res) => {
    const db = getDb();
  try {
    const { page, pillar, format, language, tone, topic, hook, selectedUniversity, selectedScholarship, researchIntel } = req.body || {};

    // Get LLM API config from meta_config or env or hardcoded fallback
    const HARD_CODED_KEYS = [
      { key:'sk-KF63PVImS4EsF2iaEvwTNHcFNqNVzEoIHJZ8K01poqEM97qZ8smo52DEye5g9KaL', provider:'opencode-go', model:'glm-5.1' }
    ];
    const dbProvider = db.prepare("SELECT value FROM meta_config WHERE key='llm_provider'").get()?.value;
    const dbModel = db.prepare("SELECT value FROM meta_config WHERE key='llm_model'").get()?.value;
    const dbKey = db.prepare("SELECT value FROM meta_config WHERE key='llm_api_key'").get()?.value;
    const envKey = process.env.OPENAI_API_KEY || process.env.GEMINI_API_KEY || process.env.OPENCODE_GO_API_KEY || '';
    
    let llmProvider = dbProvider || process.env.LLM_PROVIDER || '';
    let llmModel = dbModel || process.env.LLM_MODEL || '';
    let llmApiKey = dbKey || envKey || '';
    
    // Auto-detect from hardcoded keys if nothing configured
    if (!llmApiKey && HARD_CODED_KEYS.length > 0) {
      const fallback = HARD_CODED_KEYS[0];
      llmApiKey = fallback.key;
      llmProvider = fallback.provider;
      llmModel = fallback.model;
    }
    
    // Auto-detect provider from key prefix if not set
    if (!llmProvider && llmApiKey) {
      if (llmApiKey.startsWith('sk-')) llmProvider = 'openai'; // could be OpenAI or OpenCode
      if (llmApiKey.startsWith('AIza')) llmProvider = 'gemini';
    }
    if (!llmModel && llmProvider === 'opencode-go') llmModel = 'glm-5.1';
    if (!llmModel && llmProvider === 'openai') llmModel = 'gpt-4o-mini';
    if (!llmModel && llmProvider === 'gemini') llmModel = 'gemini-1.5-pro-latest';

    if (!llmApiKey) {
      return res.status(400).json({
        error: 'No LLM API key configured. Add OPENAI_API_KEY or GEMINI_API_KEY env var, or set via LLM Config panel.',
        fallback: true
      });
    }

    // Build the system prompt with brand voice rules
    const systemPrompt = `You are the senior content strategist for EduExpress International, an education consultancy in Dhaka, Bangladesh that helps students study abroad (China, Malaysia, Korea, Hungary, Malta, etc.).

STRICT RULES (violating any = content rejected):
1. NEVER use these banned phrases: "guaranteed visa", "100% visa success", "100% admission", "guaranteed admission", "visa confirmed", "no rejection", "zero rejection", "government registered", "licensed by government", "official representative", "authorized agent", "best consultancy", "no. 1 consultancy", "100% scholarship guaranteed", "free education", "no cost at all"
2. NEVER use: "CSC scholarship" (use "Chinese Government Scholarship" or "CSC"), "GKS scholarship" (use "Korean Government Scholarship"), "Stipendium Hungaricum" (use "Hungary Government Scholarship"), "no IELTS" (use "MOI Certificate" instead)
3. NEVER use fake numbers: "5000+ students", "99% visa success", "$5M revenue"
4. Use REAL numbers: 98% visa success rate (with disclaimer), 2,000+ students placed, 8+ years experience, 150+ partner universities
5. Stipend range: ৳10,000-60,000/month (NOT a fixed number)
6. Language: ${language === 'bangla' ? 'Write 50% Bangla + 50% English naturally. Technical terms (university names, CSC, MOI) stay in English. Each sentence should be one language, not mixed within a sentence.' : language === 'mixed' ? 'Write primarily in Bangla with key English terms naturally woven in. English for technical terms and CTAs.' : 'Write in English with occasional Bangla words for cultural resonance.'}
7. Tone: ${tone || 'expert_consultant'} — ${tone === 'expert_consultant' ? 'Professional, factual, reassuring. Use "আমরা" (we), not "তুমি" (you). Address parents as guardians.' : tone === 'empathetic_brother' ? 'Warm, conversational, understanding pain points. Use "ভাই" (brother) energy. Short sentences.' : tone === 'success_story' ? 'Inspirational, aspirational, specific details. Show transformation from doubt to achievement.' : 'Friendly, peer-to-peer, relatable. Use conversational Bangla. Share personal-feeling insights.'}
8. Hook: MUST be under 15 words, emotional or curiosity-driven, not clickbait
9. Body: 3-5 short paragraphs, each with a clear point
10. CTA: Must be clear and actionable

OUTPUT FORMAT — Return ONLY this JSON (no markdown, no explanations):
{"hook": "...", "body": "...", "hashtags": "...", "cta": "...", "brief": "design brief for designer..."}`;

    const userPrompt = `Write a ${format || 'Carousel'} post for the ${page === 'china' ? 'China Study Abroad' : page === 'bd' ? 'Bangladesh Study Abroad' : page} Facebook page.

PILLAR: ${pillar || 'scholarship'}
TOPIC: ${topic || 'Study abroad opportunity'}
${selectedUniversity ? `UNIVERSITY CONTEXT: ${selectedUniversity.name} in ${selectedUniversity.city}, ${selectedUniversity.country}. Programs: ${selectedUniversity.programs}. Tuition: ${selectedUniversity.tuition}. ${selectedUniversity.csca_free ? 'CSCA-free admission.' : ''}` : ''}
${selectedScholarship ? `SCHOLARSHIP CONTEXT: ${selectedScholarship.name}. Coverage: ${selectedScholarship.coverage}. Eligibility: ${selectedScholarship.eligibility}` : ''}
${researchIntel ? `MARKET INTELLIGENCE: ${researchIntel.topic} — ${researchIntel.insight_summary}` : ''}
${hook ? `SUGGESTED HOOK ANGLE: ${hook}` : ''}

Write the complete post now. Return ONLY JSON.`;

    let generatedContent;

    // Call LLM API based on provider
    if (llmProvider === 'openai') {
      const openaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${llmApiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: llmModel,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt }
          ],
          temperature: 0.7,
          max_tokens: 1500,
          response_format: { type: 'json_object' }
        })
      });
      const openaiData = await openaiRes.json();
      if (openaiData.error) throw new Error(openaiData.error.message);
      const content = openaiData.choices?.[0]?.message?.content;
      generatedContent = JSON.parse(content);
    } else if (llmProvider === 'gemini') {
      // Gemini API
      const geminiRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${llmModel}:generateContent?key=${llmApiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: systemPrompt + '\n\n' + userPrompt }] }],
          generationConfig: { temperature: 0.7, maxOutputTokens: 1500 }
        })
      });
      const geminiData = await geminiRes.json();
      if (geminiData.error) throw new Error(geminiData.error.message);
      const text = geminiData.candidates?.[0]?.content?.parts?.[0]?.text || '';
      try {
        generatedContent = JSON.parse(text);
      } catch (e) {
        const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/);
        if (jsonMatch) generatedContent = JSON.parse(jsonMatch[1]);
        else throw new Error('Could not parse LLM response as JSON');
      }
    } else if (llmProvider === 'opencode-go') {
      // OpenCode AI — GLM models (OpenAI-compatible)
      // Correct endpoint: https://api.opencode.ai/v1/chat/completions
      let openCodeRes;
      try {
        openCodeRes = await fetch('https://api.opencode.ai/v1/chat/completions', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${llmApiKey}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: llmModel || 'glm-5.1',
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: userPrompt }
            ],
            temperature: 0.7,
            max_tokens: 1500
          })
        });
      } catch (netErr) {
        console.error('[generate] Network error calling opencode.ai:', netErr.message);
        throw new Error(`Network error calling opencode.ai: ${netErr.message}. Check if the API endpoint is reachable.`);
      }
      
      let openCodeData;
      try {
        openCodeData = await openCodeRes.json();
      } catch (parseErr) {
        const rawText = await openCodeRes.text().catch(() => '');
        console.error('[generate] Failed to parse opencode-go response:', rawText.slice(0, 500));
        throw new Error(`OpenCode GO returned non-JSON (HTTP ${openCodeRes.status}): ${rawText.slice(0, 200)}`);
      }
      
      if (!openCodeRes.ok) {
        console.error('[generate] OpenCode GO error:', openCodeData);
        throw new Error(openCodeData.error?.message || openCodeData.message || `HTTP ${openCodeRes.status}: ${JSON.stringify(openCodeData).slice(0, 200)}`);
      }
      
      const content = openCodeData.choices?.[0]?.message?.content || openCodeData.choices?.[0]?.content;
      if (!content) {
        console.error('[generate] No content in opencode-go response:', openCodeData);
        throw new Error('OpenCode GO returned empty content. Response: ' + JSON.stringify(openCodeData).slice(0, 300));
      }
      
      try {
        generatedContent = JSON.parse(content);
      } catch (e) {
        // Try to extract JSON from markdown code block
        const jsonMatch = content.match(/```json\s*([\s\S]*?)\s*```/);
        if (jsonMatch) generatedContent = JSON.parse(jsonMatch[1]);
        else {
          // Fallback: try to find JSON object in text
          const objMatch = content.match(/\{[\s\S]*"hook"[\s\S]*\}/);
          if (objMatch) generatedContent = JSON.parse(objMatch[0]);
          else {
            console.error('[generate] Could not parse content as JSON:', content.slice(0, 500));
            throw new Error('OpenCode GO returned non-JSON content. Raw: ' + content.slice(0, 200));
          }
        }
      }
    } else {
      return res.status(400).json({ error: `Unsupported LLM provider: ${llmProvider}. Use 'openai', 'gemini', or 'opencode-go'.` });
    }

    res.json({
      success: true,
      hook: generatedContent.hook || '',
      body: generatedContent.body || '',
      hashtags: generatedContent.hashtags || '',
      cta: generatedContent.cta || '',
      brief: generatedContent.brief || `${format} design for ${pillar} post.`,
      provider: llmProvider,
      model: llmModel
    });

  } catch (e) {
    console.error('[generate] AI generation failed:', e.message);
    res.status(500).json({ error: e.message, fallback: true });
  }
});

router.post('/marketing/publish/:postId', (req, res) => requireMarketing(req, res, () => {
  const postId = parseInt(req.params.postId);
  const post = db.prepare(`SELECT * FROM content_posts WHERE id=?`).get(postId);
  if (!post) return res.status(404).json({ error: 'Post not found' });
  if (post.status !== 'approved') return res.status(400).json({ error: 'Post must be approved before publishing' });

  const platform = req.body.platform || post.platform || 'facebook';
  const page = req.body.page || post.page || 'bd';
  const scheduledAt = req.body.scheduled_at || new Date().toISOString();
  const assetUrl = req.body.asset_url || post.asset_url || null;

  // Check for existing queued/published entry for this post on this platform
  const existing = db.prepare(`SELECT * FROM publishing_queue WHERE post_id=? AND platform=? AND status IN ('queued','published')`).get(postId, platform);
  if (existing) return res.status(400).json({ error: `Already ${existing.status} on ${platform}`, queue: existing });

  // Create queue entry
  const qInfo = db.prepare(`INSERT INTO publishing_queue (post_id, page, platform, scheduled_at, status) VALUES (?, ?, ?, ?, 'queued')`).run(postId, page, platform, scheduledAt);
  const queue = db.prepare(`SELECT * FROM publishing_queue WHERE id=?`).get(qInfo.lastInsertRowid);

  // Update post status to scheduled
  db.prepare(`UPDATE content_posts SET status='scheduled', updated_at=datetime('now') WHERE id=?`).run(postId);

  // Send to n8n webhook (fire-and-forget, n8n will callback)
  const n8nWebhook = process.env.N8N_PUBLISH_WEBHOOK || 'https://vibeacademy.cloud/webhook/eduexpress-publish';
  const payload = {
    postId: postId,
    page: page,
    platform: platform,
    body: post.body || '',
    hashtags: post.hashtags || '',
    cta: post.cta || '',
    assetUrl: assetUrl,
    queueId: queue.id,
    crmBase: `${req.protocol}://${req.get('host')}`,
    crmKey: INTERNAL_API_KEY
  };

  fetch(n8nWebhook, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  }).then(r => r.json().catch(() => ({}))).then(n8nRes => {
    console.log(`[publish] n8n response for post ${postId}:`, n8nRes.success ? 'OK' : n8nRes.error);
    if (!n8nRes.success) {
      // If n8n rejected immediately, update queue
      db.prepare(`UPDATE publishing_queue SET status='failed', error_message=? WHERE id=?`).run(n8nRes.error || 'n8n rejected', queue.id);
      db.prepare(`UPDATE content_posts SET status='approved', updated_at=datetime('now') WHERE id=?`).run(postId);
    }
  }).catch(e => {
    console.error(`[publish] n8n webhook failed for post ${postId}:`, e.message);
    db.prepare(`UPDATE publishing_queue SET status='failed', error_message=? WHERE id=?`).run(`n8n unreachable: ${e.message}`, queue.id);
    db.prepare(`UPDATE content_posts SET status='approved', updated_at=datetime('now') WHERE id=?`).run(postId);
  });

  res.json({ success: true, queued: queue, post: db.prepare(`SELECT * FROM content_posts WHERE id=?`).get(postId) });
}));

router.post('/marketing/publish/webhook', (req, res) => {
    const db = getDb();
  // Auth check: must be n8n or logged-in user
  const isInternal = req.headers['x-api-key'] === INTERNAL_API_KEY;
  const isUser = req.user && req.user.id;
  if (!isInternal && !isUser) return res.status(401).json({ error: 'Unauthorized' });

  const { postId, success, platformPostId, publishUrl, error, platform, page } = req.body || {};
  if (!postId) return res.status(400).json({ error: 'postId required' });

  const post = db.prepare(`SELECT * FROM content_posts WHERE id=?`).get(postId);
  if (!post) return res.status(404).json({ error: 'Post not found' });

  // Find the most recent queue entry for this post
  const queue = db.prepare(`SELECT * FROM publishing_queue WHERE post_id=? ORDER BY created_at DESC LIMIT 1`).get(postId);

  if (success) {
    // Update queue to published
    db.prepare(`UPDATE publishing_queue SET status='published', published_at=datetime('now'), platform_post_id=?, platform_post_url=?, error_message=NULL WHERE id=?`)
      .run(platformPostId || null, publishUrl || null, queue?.id || 0);
    // Update post to published
    db.prepare(`UPDATE content_posts SET status='published', published_at=datetime('now'), updated_at=datetime('now') WHERE id=?`).run(postId);
    console.log(`[publish] ✅ Post ${postId} published to ${platform} (${page})`);
    res.json({ success: true, postId, status: 'published' });
  } else {
    // Update queue to failed
    const errMsg = error || 'Unknown publishing error';
    db.prepare(`UPDATE publishing_queue SET status='failed', error_message=? WHERE id=?`).run(errMsg, queue?.id || 0);
    // Revert post to approved (so user can retry)
    db.prepare(`UPDATE content_posts SET status='approved', updated_at=datetime('now') WHERE id=?`).run(postId);
    console.log(`[publish] ❌ Post ${postId} failed on ${platform}: ${errMsg}`);
    res.json({ success: false, postId, error: errMsg, status: 'failed' });
  }
});

router.post('/marketing/publish/retry/:queueId', (req, res) => requireMarketing(req, res, () => {
  const queueId = parseInt(req.params.queueId);
  const queue = db.prepare(`SELECT * FROM publishing_queue WHERE id=?`).get(queueId);
  if (!queue) return res.status(404).json({ error: 'Queue entry not found' });
  if (queue.status !== 'failed') return res.status(400).json({ error: `Cannot retry — status is ${queue.status}` });

  const post = db.prepare(`SELECT * FROM content_posts WHERE id=?`).get(queue.post_id);
  if (!post) return res.status(404).json({ error: 'Post not found' });

  // Reset queue to queued
  db.prepare(`UPDATE publishing_queue SET status='queued', error_message=NULL, scheduled_at=datetime('now') WHERE id=?`).run(queueId);
  db.prepare(`UPDATE content_posts SET status='scheduled', updated_at=datetime('now') WHERE id=?`).run(queue.post_id);

  // Re-send to n8n
  const n8nWebhook = process.env.N8N_PUBLISH_WEBHOOK || 'https://vibeacademy.cloud/webhook/eduexpress-publish';
  const payload = {
    postId: queue.post_id,
    page: queue.page,
    platform: queue.platform,
    body: post.body || '',
    hashtags: post.hashtags || '',
    cta: post.cta || '',
    assetUrl: post.asset_url || null,
    queueId: queueId,
    crmBase: `${req.protocol}://${req.get('host')}`,
    crmKey: INTERNAL_API_KEY
  };

  fetch(n8nWebhook, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  }).then(r => r.json().catch(() => ({}))).then(n8nRes => {
    console.log(`[publish-retry] n8n response for post ${queue.post_id}:`, n8nRes.success ? 'OK' : n8nRes.error);
  }).catch(e => {
    console.error(`[publish-retry] n8n webhook failed:`, e.message);
  });

  res.json({ success: true, queue: db.prepare(`SELECT * FROM publishing_queue WHERE id=?`).get(queueId), message: 'Retry triggered' });
}));

router.get('/marketing/publishing-queue/full', (req, res) => requireMarketing(req, res, () => {
  const { status, page, platform, limit } = req.query;
  let sql = `
    SELECT pq.*, cp.hook as post_title, cp.body as post_body, cp.hook as post_hook, cp.pillar, cp.page as post_page, cp.quality_score, cp.asset_url
    FROM publishing_queue pq
    LEFT JOIN content_posts cp ON pq.post_id = cp.id
    WHERE 1=1
  `;
  const params = [];
  if (status) { sql += ' AND pq.status = ?'; params.push(status); }
  if (page) { sql += ' AND pq.page = ?'; params.push(page); }
  if (platform) { sql += ' AND pq.platform = ?'; params.push(platform); }
  sql += ' ORDER BY pq.created_at DESC LIMIT ?';
  params.push(parseInt(limit) || 100);
  res.json(db.prepare(sql).all(...params));
}));

router.get('/marketing/publish/n8n-config', (req, res) => {
    const db = getDb();
  // Only allow internal n8n service or super_admin
  const isInternal = req.headers['x-api-key'] === INTERNAL_API_KEY;
  const isSuperAdmin = req.user && (req.user.role === 'super_admin' || req.user.roles?.includes('founder_ceo'));
  if (!isInternal && !isSuperAdmin) return res.status(401).json({ error: 'Unauthorized' });

  // Get page IDs from Facebook/Messenger channels
  const channels = db.prepare("SELECT name, page_id, access_token FROM channels WHERE type IN ('facebook', 'messenger') AND active = 1 AND page_id IS NOT NULL").all();
  const pageIds = {};
  for (const ch of channels) {
    if (ch.name.toLowerCase().includes('china')) pageIds.china = ch.page_id;
    else if (ch.name.toLowerCase().includes('bd') || ch.name.toLowerCase().includes('bangladesh')) pageIds.bd = ch.page_id;
  }

  // Get global page_access_token from meta_config
  const token = db.prepare("SELECT value FROM meta_config WHERE key='page_access_token'").get()?.value || '';

  res.json({
    facebook: {
      page_access_token: token,
      page_ids: pageIds
    },
    instagram: false,
    tiktok: false,
    crm_base: `${req.protocol}://${req.get('host')}`
  });
});

router.get('/marketing/publish/config', (req, res) => requireMarketing(req, res, () => {
  const token = db.prepare("SELECT value FROM meta_config WHERE key='page_access_token'").get()?.value || '';
  const channels = db.prepare("SELECT name, page_id FROM channels WHERE type IN ('facebook', 'messenger') AND active = 1 AND page_id IS NOT NULL").all();
  const fbChina = channels.some(c => c.name.toLowerCase().includes('china') && c.page_id);
  const fbBD = channels.some(c => (c.name.toLowerCase().includes('bd') || c.name.toLowerCase().includes('bangladesh')) && c.page_id);
  const n8nConfigured = true; // n8n workflow is hardcoded and active
  res.json({
    facebook: { china: fbChina, bd: fbBD, token_exists: !!token },
    instagram: false, // v2 feature
    tiktok: false, // v2 feature
    n8n: n8nConfigured,
    n8nWebhook: 'https://vibeacademy.cloud/webhook/eduexpress-publish',
    crm_base: `${req.protocol}://${req.get('host')}`
  });
}));

router.get('/marketing/campaigns', (req, res) => requireMarketing(req, res, () => {
  const { status, page, pillar } = req.query;
  let sql = `SELECT c.*, COUNT(cp.id) as post_count FROM campaigns c LEFT JOIN content_posts cp ON c.id = cp.campaign_id WHERE 1=1`;
  const params = [];
  if (status) { sql += ' AND c.status = ?'; params.push(status); }
  if (page) { sql += ' AND c.page = ?'; params.push(page); }
  if (pillar) { sql += ' AND c.pillar = ?'; params.push(pillar); }
  sql += ` GROUP BY c.id ORDER BY c.created_at DESC`;
  res.json(db.prepare(sql).all(...params));
}));

router.get('/marketing/campaigns/:id', (req, res) => requireMarketing(req, res, () => {
  const campaign = db.prepare(`SELECT * FROM campaigns WHERE id=?`).get(req.params.id);
  if (!campaign) return res.status(404).json({ error: 'Campaign not found' });
  const posts = db.prepare(`SELECT * FROM content_posts WHERE campaign_id=? ORDER BY created_at DESC`).all(req.params.id);
  res.json({ ...campaign, posts });
}));

router.post('/marketing/campaigns', (req, res) => requireMarketing(req, res, () => {
  const { name, description, page, pillar, start_date, end_date, budget, target_audience, goals, color } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name required' });
  const info = db.prepare(`INSERT INTO campaigns (name, description, page, pillar, start_date, end_date, budget, target_audience, goals, color, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(name, description || '', page || 'china', pillar || 'scholarship', start_date || null, end_date || null, budget || '', target_audience || '', goals || '', color || '#3B82F6', req.user?.name || '');
  res.json({ success: true, id: info.lastInsertRowid });
}));

router.put('/marketing/campaigns/:id', (req, res) => requireMarketing(req, res, () => {
  const { name, description, status, page, pillar, start_date, end_date, budget, target_audience, goals, color } = req.body || {};
  const existing = db.prepare(`SELECT * FROM campaigns WHERE id=?`).get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Campaign not found' });
  db.prepare(`UPDATE campaigns SET name=?, description=?, status=?, page=?, pillar=?, start_date=?, end_date=?, budget=?, target_audience=?, goals=?, color=?, updated_at=datetime('now') WHERE id=?`)
    .run(name || existing.name, description !== undefined ? description : existing.description, status || existing.status, page || existing.page, pillar || existing.pillar, start_date !== undefined ? start_date : existing.start_date, end_date !== undefined ? end_date : existing.end_date, budget !== undefined ? budget : existing.budget, target_audience !== undefined ? target_audience : existing.target_audience, goals !== undefined ? goals : existing.goals, color !== undefined ? color : existing.color, req.params.id);
  res.json({ success: true });
}));

router.delete('/marketing/campaigns/:id', (req, res) => requireMarketing(req, res, () => {
  db.prepare(`DELETE FROM campaigns WHERE id=?`).run(req.params.id);
  db.prepare(`UPDATE content_posts SET campaign_id=NULL WHERE campaign_id=?`).run(req.params.id);
  res.json({ success: true });
}));

router.get('/marketing/pipeline', (req, res) => requireMarketing(req, res, () => {
  const { campaign_id, page, pillar } = req.query;
  let where = 'WHERE 1=1';
  const params = [];
  if (campaign_id) { where += ' AND campaign_id=?'; params.push(campaign_id); }
  if (page) { where += ' AND page=?'; params.push(page); }
  if (pillar) { where += ' AND pillar=?'; params.push(pillar); }
  
  const posts = db.prepare(`SELECT cp.*, c.name as campaign_name, c.color as campaign_color FROM content_posts cp LEFT JOIN campaigns c ON cp.campaign_id = c.id ${where} ORDER BY cp.updated_at DESC`).all(...params);
  
  // Group by status
  const stages = ['ideation','brief_ready','writing','quality_review','design','design_review','approved','scheduled','published','archived'];
  const pipeline = {};
  for (const s of stages) pipeline[s] = [];
  for (const p of posts) {
    const status = p.status || 'ideation';
    if (!pipeline[status]) pipeline[status] = [];
    pipeline[status].push(p);
  }
  
  res.json({ stages: pipeline, counts: Object.fromEntries(Object.entries(pipeline).map(([k, v]) => [k, v.length])) });
}));

router.post('/marketing/posts/:id/move', (req, res) => requireMarketing(req, res, () => {
  const postId = parseInt(req.params.id);
  const { to_status, note } = req.body || {};
  const validStatuses = ['ideation','brief_ready','writing','quality_review','design','design_review','approved','scheduled','published','archived'];
  if (!validStatuses.includes(to_status)) return res.status(400).json({ error: 'Invalid status' });
  
  const post = db.prepare(`SELECT * FROM content_posts WHERE id=?`).get(postId);
  if (!post) return res.status(404).json({ error: 'Post not found' });
  
  const fromStatus = post.status || 'ideation';
  db.prepare(`UPDATE content_posts SET status=?, updated_at=datetime('now') WHERE id=?`).run(to_status, postId);
  db.prepare(`INSERT INTO pipeline_logs (post_id, from_status, to_status, actor, note) VALUES (?, ?, ?, ?, ?)`)
    .run(postId, fromStatus, to_status, req.user?.name || 'system', note || '');
  
  res.json({ success: true, postId, from: fromStatus, to: to_status });
}));

router.get('/marketing/posts/:id/comments', (req, res) => requireMarketing(req, res, () => {
  const comments = db.prepare(`SELECT * FROM post_comments WHERE post_id=? ORDER BY created_at DESC`).all(req.params.id);
  res.json(comments);
}));

router.post('/marketing/posts/:id/comments', (req, res) => requireMarketing(req, res, () => {
  const { comment } = req.body || {};
  if (!comment) return res.status(400).json({ error: 'comment required' });
  const info = db.prepare(`INSERT INTO post_comments (post_id, user_name, user_role, comment) VALUES (?, ?, ?, ?)`)
    .run(req.params.id, req.user?.name || 'User', req.user?.role || 'consultant', comment);
  res.json({ success: true, id: info.lastInsertRowid });
}));

router.delete('/marketing/posts/comments/:id', (req, res) => requireMarketing(req, res, () => {
  db.prepare(`DELETE FROM post_comments WHERE id=?`).run(req.params.id);
  res.json({ success: true });
}));

router.get('/marketing/posts/:id/performance', (req, res) => requireMarketing(req, res, () => {
  const perf = db.prepare(`SELECT * FROM post_performance WHERE post_id=? ORDER BY recorded_at DESC`).all(req.params.id);
  res.json(perf);
}));

router.post('/marketing/posts/:id/performance', (req, res) => requireMarketing(req, res, () => {
  const { platform, impressions, reach, engagement, likes, comments, shares, clicks, cta_clicks, video_views, saves } = req.body || {};
  const info = db.prepare(`INSERT INTO post_performance (post_id, platform, impressions, reach, engagement, likes, comments, shares, clicks, cta_clicks, video_views, saves) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(req.params.id, platform || 'facebook', impressions || 0, reach || 0, engagement || 0, likes || 0, comments || 0, shares || 0, clicks || 0, cta_clicks || 0, video_views || 0, saves || 0);
  res.json({ success: true, id: info.lastInsertRowid });
}));

router.get('/marketing/assets', (req, res) => requireMarketing(req, res, () => {
  const { post_id, campaign_id, status } = req.query;
  let sql = `SELECT a.*, cp.hook as post_title FROM content_assets a LEFT JOIN content_posts cp ON a.post_id = cp.id WHERE 1=1`;
  const params = [];
  if (post_id) { sql += ' AND a.post_id = ?'; params.push(post_id); }
  if (campaign_id) { sql += ' AND a.campaign_id = ?'; params.push(campaign_id); }
  if (status) { sql += ' AND a.status = ?'; params.push(status); }
  sql += ' ORDER BY a.created_at DESC';
  res.json(db.prepare(sql).all(...params));
}));

router.post('/marketing/assets', (req, res) => requireMarketing(req, res, () => {
  const { post_id, campaign_id, asset_type, asset_url, thumbnail_url, file_name, file_size } = req.body || {};
  const info = db.prepare(`INSERT INTO content_assets (post_id, campaign_id, asset_type, asset_url, thumbnail_url, file_name, file_size, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(post_id || null, campaign_id || null, asset_type || 'image', asset_url || '', thumbnail_url || '', file_name || '', file_size || '', req.user?.name || '');
  res.json({ success: true, id: info.lastInsertRowid });
}));

router.put('/marketing/assets/:id', (req, res) => requireMarketing(req, res, () => {
  const { status, feedback, asset_url, thumbnail_url } = req.body || {};
  const existing = db.prepare(`SELECT * FROM content_assets WHERE id=?`).get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Asset not found' });
  db.prepare(`UPDATE content_assets SET status=?, feedback=?, asset_url=?, thumbnail_url=?, updated_at=datetime('now') WHERE id=?`)
    .run(status !== undefined ? status : existing.status, feedback !== undefined ? feedback : existing.feedback, asset_url !== undefined ? asset_url : existing.asset_url, thumbnail_url !== undefined ? thumbnail_url : existing.thumbnail_url, req.params.id);
  res.json({ success: true });
}));

router.delete('/marketing/assets/:id', (req, res) => requireMarketing(req, res, () => {
  db.prepare(`DELETE FROM content_assets WHERE id=?`).run(req.params.id);
  res.json({ success: true });
}));

router.get('/marketing/templates', (req, res) => requireMarketing(req, res, () => {
  const { pillar, page, active } = req.query;
  let sql = `SELECT * FROM content_templates WHERE 1=1`;
  const params = [];
  if (pillar) { sql += ' AND pillar = ?'; params.push(pillar); }
  if (page) { sql += ' AND (page = ? OR page = "all")'; params.push(page); }
  if (active === '1') { sql += ' AND is_active = 1'; }
  sql += ' ORDER BY usage_count DESC, created_at DESC';
  res.json(db.prepare(sql).all(...params));
}));

router.get('/marketing/templates/:id', (req, res) => requireMarketing(req, res, () => {
  const t = db.prepare(`SELECT * FROM content_templates WHERE id=?`).get(req.params.id);
  if (!t) return res.status(404).json({ error: 'Template not found' });
  res.json(t);
}));

router.post('/marketing/templates', (req, res) => requireMarketing(req, res, () => {
  const { name, description, pillar, page, format, language, platform, tone, hook_template, body_template, hashtags_template, cta_template, brief_template, variables } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name required' });
  const info = db.prepare(`INSERT INTO content_templates (name, description, pillar, page, format, language, platform, tone, hook_template, body_template, hashtags_template, cta_template, brief_template, variables, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(name, description || '', pillar || 'scholarship', page || 'china', format || 'Carousel', language || 'bangla', platform || 'facebook', tone || 'expert_consultant', hook_template || '', body_template || '', hashtags_template || '', cta_template || '', brief_template || '', variables || '', req.user?.name || '');
  res.json({ success: true, id: info.lastInsertRowid });
}));

router.put('/marketing/templates/:id', (req, res) => requireMarketing(req, res, () => {
  const { name, description, pillar, page, format, language, platform, tone, hook_template, body_template, hashtags_template, cta_template, brief_template, variables, is_active } = req.body || {};
  const existing = db.prepare(`SELECT * FROM content_templates WHERE id=?`).get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Template not found' });
  db.prepare(`UPDATE content_templates SET name=?, description=?, pillar=?, page=?, format=?, language=?, platform=?, tone=?, hook_template=?, body_template=?, hashtags_template=?, cta_template=?, brief_template=?, variables=?, is_active=? WHERE id=?`)
    .run(name || existing.name, description !== undefined ? description : existing.description, pillar || existing.pillar, page || existing.page, format || existing.format, language || existing.language, platform || existing.platform, tone || existing.tone, hook_template !== undefined ? hook_template : existing.hook_template, body_template !== undefined ? body_template : existing.body_template, hashtags_template !== undefined ? hashtags_template : existing.hashtags_template, cta_template !== undefined ? cta_template : existing.cta_template, brief_template !== undefined ? brief_template : existing.brief_template, variables !== undefined ? variables : existing.variables, is_active !== undefined ? is_active : existing.is_active, req.params.id);
  res.json({ success: true });
}));

router.delete('/marketing/templates/:id', (req, res) => requireMarketing(req, res, () => {
  db.prepare(`DELETE FROM content_templates WHERE id=?`).run(req.params.id);
  res.json({ success: true });
}));

router.post('/marketing/templates/:id/use', (req, res) => requireMarketing(req, res, () => {
  const template = db.prepare(`SELECT * FROM content_templates WHERE id=?`).get(req.params.id);
  if (!template) return res.status(404).json({ error: 'Template not found' });
  const vars = req.body?.variables || {};
  // Simple string replacement for variables
  let hook = template.hook_template || '';
  let body = template.body_template || '';
  let hashtags = template.hashtags_template || '';
  let cta = template.cta_template || '';
  let brief = template.brief_template || '';
  for (const [key, val] of Object.entries(vars)) {
    const regex = new RegExp(`{{\\s*${key}\\s*}}`, 'g');
    hook = hook.replace(regex, val);
    body = body.replace(regex, val);
    hashtags = hashtags.replace(regex, val);
    cta = cta.replace(regex, val);
    brief = brief.replace(regex, val);
  }
  db.prepare(`UPDATE content_templates SET usage_count = usage_count + 1 WHERE id=?`).run(req.params.id);
  res.json({ success: true, hook, body, hashtags, cta, brief, template });
}));

router.get('/marketing/calendar', (req, res) => requireMarketing(req, res, () => {
  const { month, page, status } = req.query; // month = YYYY-MM
  if (!month) return res.status(400).json({ error: 'month (YYYY-MM) required' });
  let sql = `SELECT s.*, cp.hook, cp.body, cp.status as post_status, cp.pillar, cp.format, cp.platform, cp.quality_score, cp.asset_url FROM content_calendar_slots s LEFT JOIN content_posts cp ON s.post_id = cp.id WHERE s.slot_date LIKE ?`;
  const params = [month + '%'];
  if (page) { sql += ' AND s.page = ?'; params.push(page); }
  if (status) { sql += ' AND s.status = ?'; params.push(status); }
  sql += ' ORDER BY s.slot_date, s.slot_time';
  res.json(db.prepare(sql).all(...params));
}));

router.post('/marketing/calendar', (req, res) => requireMarketing(req, res, () => {
  const { slot_date, slot_time, page, pillar, notes } = req.body || {};
  if (!slot_date) return res.status(400).json({ error: 'slot_date required' });
  const info = db.prepare(`INSERT INTO content_calendar_slots (slot_date, slot_time, page, pillar, status, notes) VALUES (?, ?, ?, ?, 'empty', ?)`)
    .run(slot_date, slot_time || null, page || 'china', pillar || null, notes || '');
  res.json({ success: true, id: info.lastInsertRowid });
}));

router.put('/marketing/calendar/:id', (req, res) => requireMarketing(req, res, () => {
  const { slot_date, slot_time, post_id, status, notes } = req.body || {};
  const existing = db.prepare(`SELECT * FROM content_calendar_slots WHERE id=?`).get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Slot not found' });
  db.prepare(`UPDATE content_calendar_slots SET slot_date=?, slot_time=?, post_id=?, status=?, notes=? WHERE id=?`)
    .run(slot_date !== undefined ? slot_date : existing.slot_date, slot_time !== undefined ? slot_time : existing.slot_time, post_id !== undefined ? post_id : existing.post_id, status !== undefined ? status : existing.status, notes !== undefined ? notes : existing.notes, req.params.id);
  res.json({ success: true });
}));

router.delete('/marketing/calendar/:id', (req, res) => requireMarketing(req, res, () => {
  db.prepare(`DELETE FROM content_calendar_slots WHERE id=?`).run(req.params.id);
  res.json({ success: true });
}));

router.post('/marketing/calendar/:id/assign', (req, res) => requireMarketing(req, res, () => {
  const slotId = parseInt(req.params.id);
  const { post_id } = req.body || {};
  if (!post_id) return res.status(400).json({ error: 'post_id required' });
  db.prepare(`UPDATE content_calendar_slots SET post_id=?, status='planned' WHERE id=?`).run(post_id, slotId);
  res.json({ success: true });
}));

router.post('/marketing/auto-schedule', (req, res) => requireMarketing(req, res, () => {
  const { post_id, page, platform, preferred_date, preferred_time } = req.body || {};
  if (!post_id) return res.status(400).json({ error: 'post_id required' });
  
  const post = db.prepare(`SELECT * FROM content_posts WHERE id=?`).get(post_id);
  if (!post) return res.status(404).json({ error: 'Post not found' });
  
  // Determine best time
  let date = preferred_date;
  let time = preferred_time;
  
  if (!date) {
    // Default to tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    date = tomorrow.toISOString().slice(0, 10);
  }
  
  if (!time) {
    // Get best time for this page/platform/day
    const dayOfWeek = new Date(date).getDay();
    const bestTime = db.prepare(`SELECT time_slot, engagement_score FROM best_time_slots WHERE page=? AND platform=? AND day_of_week=? ORDER BY engagement_score DESC LIMIT 1`).get(page || post.page, platform || post.platform || 'facebook', dayOfWeek);
    time = bestTime?.time_slot || '19:00';
  }
  
  // Create calendar slot if not exists
  const existingSlot = db.prepare(`SELECT * FROM content_calendar_slots WHERE slot_date=? AND slot_time=? AND page=?`).get(date, time, page || post.page);
  let slotId;
  if (!existingSlot) {
    const slot = db.prepare(`INSERT INTO content_calendar_slots (slot_date, slot_time, page, pillar, post_id, status, notes) VALUES (?, ?, ?, ?, ?, 'scheduled', ?)`)
      .run(date, time, page || post.page, post.pillar, post_id, `Auto-scheduled for ${time}`);
    slotId = slot.lastInsertRowid;
  } else {
    db.prepare(`UPDATE content_calendar_slots SET post_id=?, status='scheduled' WHERE id=?`).run(post_id, existingSlot.id);
    slotId = existingSlot.id;
  }
  
  // Create publishing schedule entry
  const sched = db.prepare(`INSERT INTO publishing_schedule (post_id, page, platform, scheduled_date, scheduled_time, status) VALUES (?, ?, ?, ?, ?, 'pending')`)
    .run(post_id, page || post.page, platform || post.platform || 'facebook', date, time);
  
  // Update post status
  db.prepare(`UPDATE content_posts SET status='scheduled', post_date=?, post_time=? WHERE id=?`).run(date, time, post_id);
  
  res.json({ success: true, slot_id: slotId, schedule_id: sched.lastInsertRowid, date, time });
}));

router.get('/marketing/best-times', (req, res) => requireMarketing(req, res, () => {
  const { page, platform } = req.query;
  let sql = `SELECT * FROM best_time_slots WHERE 1=1`;
  const params = [];
  if (page) { sql += ' AND page = ?'; params.push(page); }
  if (platform) { sql += ' AND platform = ?'; params.push(platform); }
  sql += ' ORDER BY engagement_score DESC';
  res.json(db.prepare(sql).all(...params));
}));

router.post('/marketing/best-times', (req, res) => requireMarketing(req, res, () => {
  const { page, platform, day_of_week, time_slot, engagement_score } = req.body || {};
  if (!page || time_slot === undefined || day_of_week === undefined) return res.status(400).json({ error: 'page, day_of_week, time_slot required' });
  const info = db.prepare(`INSERT OR REPLACE INTO best_time_slots (page, platform, day_of_week, time_slot, engagement_score) VALUES (?, ?, ?, ?, ?)`)
    .run(page, platform || 'facebook', day_of_week, time_slot, engagement_score || 0);
  res.json({ success: true });
}));

router.get('/marketing/publishing-schedule/due', (req, res) => {
    const db = getDb();
  // This is called by n8n to get posts that are due to publish
  const isInternal = req.headers['x-api-key'] === INTERNAL_API_KEY;
  if (!isInternal) return res.status(401).json({ error: 'Unauthorized' });
  
  const now = new Date().toISOString();
  const due = db.prepare(`SELECT ps.*, cp.hook, cp.body, cp.hashtags, cp.cta, cp.asset_url, cp.brief FROM publishing_schedule ps LEFT JOIN content_posts cp ON ps.post_id = cp.id WHERE ps.status = 'pending' AND (ps.scheduled_date || 'T' || ps.scheduled_time) <= ? ORDER BY ps.scheduled_date, ps.scheduled_time LIMIT 10`).get(now);
  res.json(due || []);
});

router.post('/marketing/publishing-schedule/:id/publish', (req, res) => requireMarketing(req, res, () => {
  const scheduleId = parseInt(req.params.id);
  const { platform_post_id, platform_post_url } = req.body || {};
  db.prepare(`UPDATE publishing_schedule SET status='published', published_at=datetime('now'), platform_post_id=?, platform_post_url=? WHERE id=?`).run(platform_post_id || null, platform_post_url || null, scheduleId);
  res.json({ success: true });
}));

router.post('/marketing/publishing-schedule/:id/fail', (req, res) => requireMarketing(req, res, () => {
  const scheduleId = parseInt(req.params.id);
  const { error } = req.body || {};
  db.prepare(`UPDATE publishing_schedule SET status='failed', error_message=? WHERE id=?`).run(error || 'Unknown', scheduleId);
  res.json({ success: true });
}));

router.get('/marketing/posts/:id/logs', (req, res) => requireMarketing(req, res, () => {
  const logs = db.prepare(`SELECT * FROM pipeline_logs WHERE post_id=? ORDER BY created_at DESC`).all(req.params.id);
  res.json(logs);
}));

router.get('/marketing/dashboard', (req, res) => requireMarketing(req, res, () => {
  const totalPosts = db.prepare(`SELECT COUNT(*) as count FROM content_posts`).get().count;
  const byStatus = db.prepare(`SELECT status, COUNT(*) as count FROM content_posts GROUP BY status`).all();
  const publishedThisMonth = db.prepare(`SELECT COUNT(*) as count FROM content_posts WHERE status='published' AND strftime('%Y-%m', published_at) = strftime('%Y-%m', 'now')`).get().count;
  const activeCampaigns = db.prepare(`SELECT COUNT(*) as count FROM campaigns WHERE status='active'`).get().count;
  const pendingAssets = db.prepare(`SELECT COUNT(*) as count FROM content_assets WHERE status IN ('pending','in_progress')`).get().count;
  const queuedPosts = db.prepare(`SELECT COUNT(*) as count FROM publishing_queue WHERE status='queued'`).get().count;
  
  res.json({ totalPosts, byStatus, publishedThisMonth, activeCampaigns, pendingAssets, queuedPosts });
}));

  return router;
}
