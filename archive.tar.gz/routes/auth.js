import express from 'express';

export default function(dependencies) {
  const { 
    getDb, 
    verifyPassword, 
    isFullAdmin, 
    getConfig, 
    haversineMeters, 
    signToken, 
    setAuthCookie, 
    autoCheckIn, 
    clearAuthCookie, 
    verifyToken,
    getCookie,
    AUTH_COOKIE
  } = dependencies;
  
  const router = express.Router();

  router.post('/login', (req, res) => {
    const db = getDb();
    const { email, password, lat, lng, ssid, device_id } = req.body || {};
    if (!email || !password) return res.status(400).json({ error: 'Username/Email and password required' });
    
    const queryVal = String(email).trim().toLowerCase();
    const user = db.prepare(`
      SELECT * FROM users 
      WHERE (LOWER(email) = ? OR LOWER(name) = ? OR LOWER(consultant_name) = ? OR LOWER(emp_id) = ?) 
        AND active = 1
    `).get(queryVal, queryVal, queryVal, queryVal);

    if (!user || !verifyPassword(password, user.password_hash)) {
      return res.status(401).json({ error: 'Invalid username/email or password' });
    }

    const enforceLocation = !isFullAdmin(user);
    const parsedLat = Number.isFinite(parseFloat(lat)) ? parseFloat(lat) : NaN;
    const parsedLng = Number.isFinite(parseFloat(lng)) ? parseFloat(lng) : NaN;

    let allowedSSIDs = [];
    try { allowedSSIDs = JSON.parse(getConfig('office_allowed_ssids') || '[]'); } catch {}
    if (!Array.isArray(allowedSSIDs) || allowedSSIDs.length === 0) {
      const single = getConfig('office_wifi_ssid');
      if (single) allowedSSIDs = [single];
    }

    if (enforceLocation && ssid && allowedSSIDs.length > 0) {
      const ssidMatch = allowedSSIDs.some(s =>
        String(s).toLowerCase().trim() === String(ssid).toLowerCase().trim()
      );
      if (!ssidMatch) {
        return res.status(403).json({
          error: 'Not connected to the office network. Please connect to the EduExpress or HTA Wi-Fi and try again.',
          code: 'WRONG_NETWORK',
        });
      }
    }

    const officeLat = parseFloat(getConfig('office_lat'));
    const officeLng = parseFloat(getConfig('office_lng'));
    if (enforceLocation && Number.isFinite(officeLat) && Number.isFinite(officeLng)) {
      const officeRadius = parseInt(getConfig('office_radius_m')) || 200;
      if (!Number.isFinite(parsedLat) || !Number.isFinite(parsedLng)) {
        console.warn(`[login] User ${email} logged in without location coordinates`);
      } else {
        const distFromOffice = haversineMeters(officeLat, officeLng, parsedLat, parsedLng);
        if (distFromOffice > officeRadius) {
          return res.status(403).json({
            error: `You must be at the office to log in. You are currently ${Math.round(distFromOffice)}m away.`,
            code: 'OUTSIDE_OFFICE',
            distance: Math.round(distFromOffice),
          });
        }
      }
    }

    db.prepare("UPDATE users SET last_login=datetime('now') WHERE id=?").run(user.id);
    const userRoles = db.prepare("SELECT role FROM user_roles WHERE user_id=?").all(user.id).map(r => r.role);
    if (userRoles.length === 0) {
      const roleMap = { admin: 'founder_ceo', manager: 'application_manager', consultant: 'consultant' };
      userRoles.push(roleMap[user.role] || user.role || 'consultant');
    }
    const token = signToken({ id: user.id, role: user.role, roles: userRoles, email: user.email, name: user.name, consultant_name: user.consultant_name, emp_id: user.emp_id });
    setAuthCookie(res, token);

    let attendance = null;
    try {
      attendance = autoCheckIn(user, {
        lat: Number.isFinite(parseFloat(lat)) ? parseFloat(lat) : undefined,
        lng: Number.isFinite(parseFloat(lng)) ? parseFloat(lng) : undefined,
        ssid,
        device_id,
      });
    } catch (e) { console.error('[auto-attendance]', e.message); }

    res.json({
      id: user.id, email: user.email, name: user.name, role: user.role, roles: userRoles,
      consultant_name: user.consultant_name, emp_id: user.emp_id,
      attendance,
    });
  });

  router.post('/logout', (_req, res) => { 
    clearAuthCookie(res); 
    res.json({ ok: true }); 
  });

  router.get('/me', (req, res) => {
    const db = getDb();
    const cookie = getCookie(req, AUTH_COOKIE);
    let payload;
    try {
      payload = verifyToken(cookie);
    } catch (err) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    if (!payload) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    let user;
    try {
      user = db.prepare("SELECT id,email,name,role,consultant_name,emp_id,active FROM users WHERE id=? AND active=1").get(payload.id);
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
    if (!user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    let roles;
    try {
      roles = db.prepare("SELECT role FROM user_roles WHERE user_id=?").all(user.id).map(r => r.role);
      if (roles.length === 0) {
        const roleMap = { admin: 'founder_ceo', manager: 'application_manager', consultant: 'consultant' };
        roles = [roleMap[user.role] || user.role || 'consultant'];
      }
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({
      id: user.id, email: user.email, name: user.name, role: user.role, roles,
      consultant_name: user.consultant_name, emp_id: user.emp_id
    });
  });

  return router;
};
