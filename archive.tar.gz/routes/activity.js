import express from 'express';

export default function(dependencies) {
  const router = express.Router();
  const { getDb, requireAdmin, requireManagerOrAdmin, userHasRole, canViewOwnLeadsOnly, isFullAdmin } = dependencies;

router.get('/activity', (req, res) => {
    const db = getDb();
  const { type, actor, lead_id, since, before, limit = 100 } = req.query;
  const where = []; const params = [];
  
  // Consultants are strictly locked to their own activities
  if (canViewOwnLeadsOnly(req.user)) {
    where.push("actor_user_id=?");
    params.push(req.user.id);
  } else {
    // Admins and managers can filter by actor
    if (actor) {
      where.push("actor_user_id=?");
      params.push(actor);
    }
  }
  
  if (type)    { where.push("type=?");          params.push(type); }
  if (lead_id) { where.push("lead_id=?");       params.push(lead_id); }
  if (since)   { where.push("created_at >= ?"); params.push(since); }
  if (before)  { where.push("id < ?");          params.push(parseInt(before)); }
  
  const ws = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const rows = db.prepare(`SELECT * FROM activity_log ${ws} ORDER BY id DESC LIMIT ${Math.min(parseInt(limit) || 100, 500)}`).all(...params);
  res.json(rows);
});

router.get('/events', (req, res) => {
    const db = getDb();
  // Auth via cookie — EventSource always sends cookies, no extra setup needed.
  const payload = verifyToken(getCookie(req, AUTH_COOKIE));
  if (!payload) return res.status(401).end();

  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');   // disables nginx buffering
  res.setHeader('X-LiteSpeed-Buffer', 'no');  // disables LiteSpeed buffering (Hostinger)
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.flushHeaders();

  const id = Date.now() + Math.random();
  sseClients.set(id, { res, user: payload });
  res.write(`event: connected\ndata: ${JSON.stringify({ type: 'connected', id })}\n\n`);
  if (typeof res.flush === 'function') res.flush();

  const ping = setInterval(() => {
    try {
      res.write(`: ping\n\n`);
      if (typeof res.flush === 'function') res.flush();
    } catch { clearInterval(ping); sseClients.delete(id); }
  }, 5000);

  req.on('close', () => { clearInterval(ping); sseClients.delete(id); });
});

router.get('/daily-logs', (req, res) => {
    const db = getDb();
  const { emp_id, from, to, date } = req.query;
  const where = []; const params = [];
  if (emp_id)         { where.push('emp_id=?'); params.push(emp_id); }
  if (from)           { where.push('date >= ?'); params.push(from); }
  if (to)             { where.push('date <= ?'); params.push(to); }
  if (date)           { where.push('date = ?'); params.push(date); }

  // Consultants only see their own logs (scoped by their linked emp_id or name match)
  // Consultants are scoped to their own leads — enforced server-side.
  // Admins, Managing Directors, Investors, and Application Managers see everything.
  if (canViewOwnLeadsOnly(req.user)) {
    const emp = findEmployeeForUser(req.user);
    if (!emp) return res.json([]);
    where.push('emp_id=?'); params.push(emp.emp_id);
  }
  const ws = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const rows = db.prepare(`SELECT * FROM daily_logs ${ws} ORDER BY date DESC, id DESC LIMIT 365`).all(...params);
  res.json(rows);
});

router.post('/daily-logs', (req, res) => {
    const db = getDb();
  const emp = findEmployeeForUser(req.user);
  if (!emp) return res.status(400).json({ error: 'Your user account is not linked to an HR employee — ask the admin to link it in Settings → Users.' });
  const today = new Date().toISOString().slice(0, 10);
  const date  = (req.body?.date || today).slice(0, 10);
  if (date > today) return res.status(400).json({ error: "Can't log for a future date" });

  const { accomplishments, challenges, tomorrow_plan, metrics } = req.body || {};
  if (!accomplishments?.trim()) return res.status(400).json({ error: 'Accomplishments is required' });
  const metrics_json = metrics ? JSON.stringify(metrics) : null;

  const existing = db.prepare("SELECT id FROM daily_logs WHERE emp_id=? AND date=?").get(emp.emp_id, date);
  if (existing) {
    db.prepare(`UPDATE daily_logs SET accomplishments=?, challenges=?, tomorrow_plan=?, metrics_json=?, updated_at=datetime('now') WHERE id=?`)
      .run(accomplishments.trim(), challenges?.trim() || null, tomorrow_plan?.trim() || null, metrics_json, existing.id);
    logActivity({ type: 'daily_log_updated', actor: req.user, details: { date, emp_id: emp.emp_id } });
  } else {
    db.prepare(`INSERT INTO daily_logs (emp_id, user_id, date, accomplishments, challenges, tomorrow_plan, metrics_json) VALUES (?,?,?,?,?,?,?)`)
      .run(emp.emp_id, req.user.id || null, date, accomplishments.trim(), challenges?.trim() || null, tomorrow_plan?.trim() || null, metrics_json);
    logActivity({ type: 'daily_log_submitted', actor: req.user, details: { date, emp_id: emp.emp_id } });
  }
  res.json(db.prepare("SELECT * FROM daily_logs WHERE emp_id=? AND date=?").get(emp.emp_id, date));
});

router.get('/daily-logs/me/today', (req, res) => {
    const db = getDb();
  const emp = findEmployeeForUser(req.user);
  if (!emp) return res.json({ linked: false });
  const today = new Date().toISOString().slice(0, 10);
  const row = db.prepare("SELECT * FROM daily_logs WHERE emp_id=? AND date=?").get(emp.emp_id, today);
  res.json({ linked: true, emp_id: emp.emp_id, emp_name: emp.name, today, log: row || null });
});

  return router;
}
