import express from 'express';

export default function(dependencies) {
  const router = express.Router();
  const { 
    getDb, requireAdmin, requireManagerOrAdmin, requireFinanceOrAdmin
  } = dependencies;

router.get('/income', (req, res) => {
    const db = getDb();
  const { month, page=1, limit=50 } = req.query;
  const pageNum = Math.max(1, parseInt(page) || 1);
  const limitNum = Math.min(Math.max(1, parseInt(limit) || 50), 500);
  const offset = (pageNum - 1) * limitNum;
  const params = {};
  let w = 'WHERE (exclude_from_cash IS NULL OR exclude_from_cash = 0)';
  if (month) { w += ' AND month=@month'; params.month = month; }
  const sum = db.prepare(`SELECT SUM(amount) as s FROM income ${w}`).get(params).s || 0;
  const total = db.prepare(`SELECT COUNT(*) as c FROM income ${w}`).get(params).c;
  const rows = db.prepare(`SELECT i.*, e.name AS employee_name FROM income i LEFT JOIN employees e ON e.id = i.employee_id ${w} ORDER BY i.date DESC LIMIT ${limitNum} OFFSET ${offset}`).all(params);
  res.json({ rows, total, sum, page: pageNum, pages: Math.ceil(total/limitNum) });
});

router.put('/income/:id', (req, res) => {
    const db = getDb();
  const d = req.body; const month = d.date?.slice(0,7)||null;
  db.prepare(`UPDATE income SET date=@date,month=@month,category=@category,lead_id=@lead_id,client_name=@client_name,reference=@reference,amount=@amount,notes=@notes,employee_id=@employee_id WHERE id=@id`).run({ ...d, id: req.params.id, month, amount: d.amount||0, employee_id: d.employee_id || null });
  res.json(db.prepare("SELECT * FROM income WHERE id=?").get(req.params.id));
});

router.delete('/income/:id', (req, res) => {
    const db = getDb(); db.prepare("DELETE FROM income WHERE id=?").run(req.params.id); res.json({ ok:true }); });

router.get('/expenses', (req, res) => {
    const db = getDb();
  const { month, page=1, limit=50 } = req.query;
  const pageNum = Math.max(1, parseInt(page) || 1);
  const limitNum = Math.min(Math.max(1, parseInt(limit) || 50), 500);
  const offset = (pageNum - 1) * limitNum;
  const params = {};
  let w = '';
  if (month) { w = 'WHERE month=@month'; params.month = month; }
  const sum = db.prepare(`SELECT SUM(amount) as s FROM expenses ${w}`).get(params).s || 0;
  const total = db.prepare(`SELECT COUNT(*) as c FROM expenses ${w}`).get(params).c;
  const rows = db.prepare(`SELECT x.*, e.name AS employee_name FROM expenses x LEFT JOIN employees e ON e.id = x.employee_id ${w} ORDER BY x.date DESC LIMIT ${limitNum} OFFSET ${offset}`).all(params);
  res.json({ rows, total, sum, page: pageNum, pages: Math.ceil(total/limitNum) });
});

router.post('/expenses', (req, res) => {
    const db = getDb();
  const d = req.body; const month = d.date?.slice(0,7)||null;
  const info = db.prepare(`INSERT INTO expenses (date,month,category,paid_to,reference,amount,notes,employee_id) VALUES (@date,@month,@category,@paid_to,@reference,@amount,@notes,@employee_id)`).run({ ...d, month, amount: d.amount||0, employee_id: d.employee_id || null });
  const row = db.prepare("SELECT * FROM expenses WHERE id=?").get(info.lastInsertRowid);
  logActivity({ type: 'expense_recorded', actor: req.user, amount: row.amount, details: { paid_to: row.paid_to, category: row.category, reference: row.reference } });
  res.json(row);
});

router.put('/expenses/:id', (req, res) => {
    const db = getDb();
  const d = req.body; const month = d.date?.slice(0,7)||null;
  db.prepare(`UPDATE expenses SET date=@date,month=@month,category=@category,paid_to=@paid_to,reference=@reference,amount=@amount,notes=@notes,employee_id=@employee_id WHERE id=@id`).run({ ...d, id: req.params.id, month, amount: d.amount||0, employee_id: d.employee_id || null });
  res.json(db.prepare("SELECT * FROM expenses WHERE id=?").get(req.params.id));
});

router.delete('/expenses/:id', (req, res) => {
    const db = getDb(); db.prepare("DELETE FROM expenses WHERE id=?").run(req.params.id); res.json({ ok:true }); });

router.get('/pnl', (req, res) => {
    const db = getDb();
  const months = db.prepare("SELECT DISTINCT month FROM (SELECT month FROM income UNION SELECT month FROM expenses) WHERE month IS NOT NULL ORDER BY month").all().map(r => r.month);
  res.json(months.map(m => {
    const inc = db.prepare("SELECT SUM(amount) as s FROM income WHERE month=? AND (exclude_from_cash IS NULL OR exclude_from_cash = 0)").get(m).s||0;
    const exp = db.prepare("SELECT SUM(amount) as s FROM expenses WHERE month=?").get(m).s||0;
    return { month: m, income: inc, expense: exp, profit: inc-exp, margin: inc>0?((inc-exp)/inc*100).toFixed(1):0 };
  }));
});

router.get('/cashflow/categories', (req, res) => {
    const db = getDb();
  res.json({ income: INCOME_CATEGORIES, expense: EXPENSE_CATEGORIES });
});

router.put('/cashflow/initial', (req, res) => requireAdmin(req, res, () => {
  const v = Number(req.body?.amount);
  if (!Number.isFinite(v)) return res.status(400).json({ error: 'amount required' });
  setConfig('cash_initial', String(v));
  res.json({ ok: true, cash_initial: v });
}));

router.get('/cashflow', (req, res) => requireFinance(req, res, () => {
  const month = req.query.month || new Date().toISOString().slice(0, 7);
  const incomeRows  = db.prepare(`SELECT i.id,i.date,i.category,i.client_name,i.reference,i.amount,i.notes,i.employee_id,e.name AS employee_name FROM income i LEFT JOIN employees e ON e.id = i.employee_id WHERE i.month=? AND (i.exclude_from_cash IS NULL OR i.exclude_from_cash = 0) ORDER BY i.date, i.id`).all(month);
  const expenseRows = db.prepare(`SELECT x.id,x.date,x.category,x.paid_to AS client_name,x.reference,x.amount,x.notes,x.employee_id,e.name AS employee_name FROM expenses x LEFT JOIN employees e ON e.id = x.employee_id WHERE x.month=? ORDER BY x.date, x.id`).all(month);
  const opening = computeOpeningBalance(month);
  const totalIn  = incomeRows.reduce((s, r) => s + (r.amount || 0), 0);
  const totalOut = expenseRows.reduce((s, r) => s + (r.amount || 0), 0);

  // Build a unified chronological feed for running-balance computation.
  const events = [
    ...incomeRows.map(r => ({ ...r, kind: 'in',  ts: `${r.date || month + '-01'}-i-${r.id}` })),
    ...expenseRows.map(r => ({ ...r, kind: 'out', ts: `${r.date || month + '-01'}-o-${r.id}` })),
  ].sort((a, b) => a.ts.localeCompare(b.ts));
  let running = opening;
  for (const e of events) { running += e.kind === 'in' ? e.amount : -e.amount; e.running = running; }

  // Re-attach running balance back to each row in order
  const incomeWithRun  = incomeRows.map(r => ({ ...r, running: events.find(e => e.kind === 'in'  && e.id === r.id)?.running }));
  const expenseWithRun = expenseRows.map(r => ({ ...r, running: events.find(e => e.kind === 'out' && e.id === r.id)?.running }));

  // Category breakdowns for the donut/sidebar
  const incByCat  = {}; incomeRows.forEach(r  => { const k = r.category || 'Uncategorised'; incByCat[k]  = (incByCat[k]  || 0) + (r.amount || 0); });
  const expByCat  = {}; expenseRows.forEach(r => { const k = r.category || 'Uncategorised'; expByCat[k]  = (expByCat[k]  || 0) + (r.amount || 0); });
  // Per-reference (who handled / referred) breakdown for income
  const incByRef  = {}; incomeRows.forEach(r  => { const k = r.reference || 'Direct'; incByRef[k] = (incByRef[k] || 0) + (r.amount || 0); });

  res.json({
    month, opening,
    income:  incomeWithRun,
    expense: expenseWithRun,
    totals: { in: totalIn, out: totalOut, net: totalIn - totalOut, closing: opening + totalIn - totalOut },
    by_category: {
      income:  Object.entries(incByCat).sort((a,b) => b[1]-a[1]).map(([name, amount]) => ({ name, amount })),
      expense: Object.entries(expByCat).sort((a,b) => b[1]-a[1]).map(([name, amount]) => ({ name, amount })),
    },
    income_by_reference: Object.entries(incByRef).sort((a,b) => b[1]-a[1]).map(([name, amount]) => ({ name, amount })),
  });
}));

router.get('/cashflow/year', (req, res) => requireFinance(req, res, () => {
  const year = (req.query.year || new Date().toISOString().slice(0, 4)).toString();
  const months = Array.from({ length: 12 }, (_, i) => `${year}-${String(i + 1).padStart(2, '0')}`);
  const initial = parseFloat(getConfig('cash_initial')) || 0;
  const priorIn  = db.prepare("SELECT COALESCE(SUM(amount),0) AS s FROM income   WHERE month < ? AND (exclude_from_cash IS NULL OR exclude_from_cash = 0)").get(`${year}-01`).s;
  const priorOut = db.prepare("SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE month < ?").get(`${year}-01`).s;
  let running = initial + priorIn - priorOut;

  const rows = months.map(m => {
    const inc = db.prepare("SELECT COALESCE(SUM(amount),0) AS s FROM income   WHERE month=? AND (exclude_from_cash IS NULL OR exclude_from_cash = 0)").get(m).s;
    const exp = db.prepare("SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE month=?").get(m).s;
    const opening = running;
    const closing = opening + inc - exp;
    running = closing;
    return { month: m, opening, income: inc, expense: exp, net: inc - exp, closing };
  });
  res.json({ year, opening: rows[0]?.opening || initial, closing: rows[11]?.closing || initial, rows });
}));

router.get('/cashflow/investors', (req, res) => requireFinance(req, res, () => {
  const rows = db.prepare(`SELECT date, month, client_name, reference, amount, notes
                           FROM income WHERE category='Investment' ORDER BY date, id`).all();
  const byPerson = {};
  rows.forEach(r => {
    const key = r.client_name || 'Unknown';
    byPerson[key] = (byPerson[key] || 0) + (r.amount || 0);
  });
  res.json({
    total: rows.reduce((s, r) => s + (r.amount || 0), 0),
    contributions: rows,
    by_person: Object.entries(byPerson).sort((a, b) => b[1] - a[1]).map(([name, amount]) => ({ name, amount })),
  });
}));

  return router;
}
