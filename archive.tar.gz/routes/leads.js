import express from 'express';
import { readFileSync, writeFileSync, existsSync, mkdirSync, copyFileSync } from 'fs';
import { dirname, join } from 'path';

export default function(dependencies) {
  const router = express.Router();
  const { 
    getDb, requireAdmin, requireManagerOrAdmin, userHasRole, isFullAdmin, canViewOwnLeadsOnly, isChinaBlockedForUser, leadIsVisibleTo, logActivity, sendCAPIEvent, sendWhatsAppMessage, sendEmail, uploadLimiter, getConfig, notifyClients, nextChinaLeadId, nextLeadId, leadParams, LEAD_INSERT_SQL, LEAD_UPDATE_SQL, PERSISTENT_HOME 
  } = dependencies;

router.put('/:id/stage', (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });

  const {
    stage, visa_deadline, departure_date, university, intake_term, application_notes,
    source, referrer, nationality, passport, degree, major, drive_link, deposit,
    blood_group, date_of_birth, medical_notes, emergency_contact,
    destination, assigned_consultant, assigned_employee_id, lead_source, english_score,
    next_followup, client_name, phone, email, program, notes, lead_status,
    service_fee, paid, last_education,
  } = req.body || {};

  const stages = getApplicationStages();
  if (stage && !stages.some(s => s.key === stage)) {
    return res.status(400).json({ error: 'Unknown stage' });
  }
  const oldStage = lead.application_stage;
  db.prepare(`UPDATE leads SET
    application_stage = COALESCE(?, application_stage),
    visa_deadline     = COALESCE(?, visa_deadline),
    departure_date    = COALESCE(?, departure_date),
    university        = COALESCE(?, university),
    intake_term       = COALESCE(?, intake_term),
    application_notes = COALESCE(?, application_notes),
    source            = COALESCE(?, source),
    referrer          = COALESCE(?, referrer),
    nationality       = COALESCE(?, nationality),
    passport          = COALESCE(?, passport),
    degree            = COALESCE(?, degree),
    major             = COALESCE(?, major),
    drive_link        = COALESCE(?, drive_link),
    deposit           = COALESCE(?, deposit),
    blood_group       = COALESCE(?, blood_group),
    date_of_birth     = COALESCE(?, date_of_birth),
    medical_notes     = COALESCE(?, medical_notes),
    emergency_contact = COALESCE(?, emergency_contact),
    destination       = COALESCE(?, destination),
    assigned_consultant = COALESCE(?, assigned_consultant),
    assigned_employee_id = COALESCE(?, assigned_employee_id),
    lead_source       = COALESCE(?, lead_source),
    english_score     = COALESCE(?, english_score),
    next_followup     = COALESCE(?, next_followup),
    client_name       = COALESCE(?, client_name),
    phone             = COALESCE(?, phone),
    email             = COALESCE(?, email),
    program           = COALESCE(?, program),
    notes             = COALESCE(?, notes),
    lead_status       = COALESCE(?, lead_status),
    service_fee       = COALESCE(?, service_fee),
    paid              = COALESCE(?, paid),
    last_education    = COALESCE(?, last_education)
    WHERE id=?`).run(
      stage ?? null, visa_deadline ?? null, departure_date ?? null,
      university ?? null, intake_term ?? null, application_notes ?? null,
      source ?? null, referrer ?? null, nationality ?? null, passport ?? null,
      degree ?? null, major ?? null, drive_link ?? null,
      (deposit === '' || deposit == null) ? null : Number(deposit),
      blood_group ?? null, date_of_birth ?? null, medical_notes ?? null, emergency_contact ?? null,
      destination ?? null, assigned_consultant ?? null,
      (assigned_employee_id === '' || assigned_employee_id == null) ? null : Number(assigned_employee_id),
      lead_source ?? null, english_score ?? null, next_followup ?? null,
      client_name ?? null, phone ?? null, email ?? null, program ?? null, notes ?? null,
      lead_status ?? null,
      (service_fee === '' || service_fee == null) ? null : Number(service_fee),
      (paid === '' || paid == null) ? null : Number(paid),
      last_education ?? null,
      req.params.id);
  const fresh = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  if (stage && oldStage !== stage) {
    logActivity({ type: 'application_stage_changed', actor: req.user, lead: fresh, from: oldStage, to: stage });
  }
  res.json(fresh);
});

router.get('/:id/university-applications', (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });
  const rows = db.prepare("SELECT * FROM lead_university_applications WHERE lead_id=? ORDER BY id").all(lead.id);
  res.json(rows);
});

router.post('/:id/university-applications', (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });
  const { university, program = null, status = 'documents', application_id = null, notes = null } = req.body || {};
  if (!university) return res.status(400).json({ error: 'university is required' });
  if (!UNI_APP_STATUSES.includes(status)) return res.status(400).json({ error: 'Bad status' });
  const info = db.prepare(`INSERT INTO lead_university_applications
    (lead_id, university, program, status, application_id, notes, updated_by)
    VALUES (?,?,?,?,?,?,?)`).run(
      lead.id, university, program, status, application_id, notes,
      req.user?.name || req.user?.email || null);
  res.json(db.prepare("SELECT * FROM lead_university_applications WHERE id=?").get(info.lastInsertRowid));
});

router.get('/:id/documents', (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });

  // If no docs yet and this lead has a destination, seed from template once.
  const count = db.prepare("SELECT COUNT(*) as c FROM lead_documents WHERE lead_id=?").get(lead.id).c;
  if (count === 0 && lead.destination) {
    const seed = db.prepare("INSERT INTO lead_documents (lead_id, doc_type, status) VALUES (?,?,?)");
    db.transaction(() => {
      for (const docType of templateFor(lead.destination)) seed.run(lead.id, docType, 'pending');
    })();
  }
  const docs = db.prepare("SELECT * FROM lead_documents WHERE lead_id=? ORDER BY id").all(lead.id);
  res.json(docs);
});

router.post('/:id/documents', (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });

  const { doc_type, status = 'pending', notes = null, file_url = null } = req.body || {};
  if (!doc_type) return res.status(400).json({ error: 'doc_type is required' });
  const info = db.prepare(`INSERT INTO lead_documents (lead_id, doc_type, status, notes, file_url, updated_by)
    VALUES (?,?,?,?,?,?)`).run(lead.id, doc_type, status, notes, file_url, req.user?.name || req.user?.email || null);
  res.json(db.prepare("SELECT * FROM lead_documents WHERE id=?").get(info.lastInsertRowid));
});

router.get('/', (req, res) => {
    const db = getDb();
  const { search, status, consultant, destination, source, page = 1, limit = 50 } = req.query;
  const where = []; const params = {};
  if (search && search !== 'undefined' && search !== 'null') { where.push("(client_name LIKE @search OR phone LIKE @search OR lead_id LIKE @search OR email LIKE @search)"); params.search = `%${search}%`; }
  if (status)      { where.push("lead_status=@status");           params.status = status; }
  if (consultant)  { where.push("assigned_consultant=@consultant");params.consultant = consultant; }
  if (destination) { where.push("destination=@destination");      params.destination = destination; }
  if (source) {
    if (source === 'meta') {
      where.push("meta_lead_id IS NOT NULL");
    } else {
      where.push("lead_source=@source");
      params.source = source;
    }
  }
  // Consultants are scoped to their own assigned leads — enforced server-side.
  // Admins, Managing Directors, Investors, and Application Managers see everything.
  if (canViewOwnLeadsOnly(req.user)) {
    const meName = req.user.consultant_name || req.user.name || '';
    const meClean = meName.split(' ')[0];
    where.push("(TRIM(LOWER(assigned_consultant)) = TRIM(LOWER(@me)) OR TRIM(LOWER(assigned_consultant)) = TRIM(LOWER(@meClean)) OR TRIM(LOWER(@me)) LIKE '%' || TRIM(LOWER(assigned_consultant)) || '%' OR TRIM(LOWER(assigned_consultant)) LIKE '%' || TRIM(LOWER(@meClean)) || '%')");
    params.me = meName;
    params.meClean = meClean;
  }
  // China data isolation: exclude China leads for unauthorized users unless they own/are assigned to them
  if (!canViewChinaData(req.user) && !canViewOwnLeadsOnly(req.user)) {
    where.push("(destination != 'China' AND source != 'China')");
  }
  const ws = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const offset = (parseInt(page) - 1) * parseInt(limit);
  const total  = db.prepare(`SELECT COUNT(*) as c FROM leads ${ws}`).get(params).c;
  const leads  = db.prepare(`SELECT l.*, e.name as employee_name, e.emp_id as employee_emp_id, e.role as employee_role FROM leads l LEFT JOIN employees e ON l.assigned_employee_id = e.id ${ws} ORDER BY l.id DESC LIMIT ${limit} OFFSET ${offset}`).all(params);
  res.json({ leads, total, page: parseInt(page), pages: Math.ceil(total / parseInt(limit)) });
});

router.get('/:id', (req, res) => {
    const db = getDb();
  const lead = db.prepare(`SELECT l.*, e.name as employee_name, e.emp_id as employee_emp_id, e.role as employee_role FROM leads l LEFT JOIN employees e ON l.assigned_employee_id = e.id WHERE l.id=? OR l.lead_id=?`).get(req.params.id, req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to this lead record' });
  }
  res.json(lead);
});

router.post('/', async (req, res) => {
    const db = getDb();
  const d = req.body;
  const isChinaApp = d.isChinaApp || d.source === 'China' || (d.lead_id && String(d.lead_id).startsWith('C-'));
  // RBAC: Only full admins and Application Managers can create China applications
  if (isChinaApp && !isFullAdmin(req.user) && !userHasRole(req.user, 'application_manager')) {
    return res.status(403).json({ error: 'Only Application Managers and Administrators can create China applications.' });
  }
  // Chat inbox leads must go to Bangladesh
  const fromChat = d.lead_source === 'WhatsApp' || d.lead_source === 'Messenger' || d.lead_source === 'Instagram' || d.lead_source === 'TikTok';
  if (fromChat && d.destination !== 'Bangladesh') {
    d.destination = 'Bangladesh';
    d.source = d.source || 'In-House';
  }
  const lead_id = d.lead_id || (isChinaApp ? nextChinaLeadId() : nextLeadId());
  const balance = (parseFloat(d.service_fee)||0) - (parseFloat(d.paid)||0);
  const params = leadParams(d, lead_id, balance);
  const info = db.prepare(LEAD_INSERT_SQL).run(params);
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(info.lastInsertRowid);
  sendCAPIEvent('Lead', lead).catch(() => {});
  logActivity({ type: 'lead_created', actor: req.user, lead, details: { source: lead.lead_source, destination: lead.destination, assigned_consultant: lead.assigned_consultant } });
  if (lead.assigned_consultant)
    logActivity({ type: 'lead_assigned', actor: req.user, lead, to: lead.assigned_consultant });
  res.json(lead);
});

router.put('/:id', async (req, res) => {
    const db = getDb();
  const d = req.body;
  const oldLead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  if (!oldLead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(oldLead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(oldLead, req.user)) {
    return res.status(403).json({ error: 'Access denied to this lead record' });
  }
  const balance = (parseFloat(d.service_fee)||0) - (parseFloat(d.paid)||0);
  const params = leadParams(d, oldLead.lead_id, balance);
  db.prepare(LEAD_UPDATE_SQL).run({ ...params, id: req.params.id });
  let lead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);

  // Audit the changes that matter to an owner.
  let autoUpdates = [];
  if (oldLead?.lead_status !== lead.lead_status) {
    logActivity({ type: 'lead_status_changed', actor: req.user, lead, from: oldLead?.lead_status, to: lead.lead_status });
    const evtMap = { 'Enrolled':'Purchase','File Opened':'InitiateCheckout','Office Visited':'Schedule','Positive':'Lead' };
    if (evtMap[lead.lead_status]) sendCAPIEvent(evtMap[lead.lead_status], lead).catch(() => {});

    // Auto-move to applications when status becomes 'File Opened'
    if (lead.lead_status === 'File Opened') {
      let newStage = lead.application_stage || 'documents';
      if (!lead.application_stage) {
        autoUpdates.push("application_stage = 'documents'");
      }
      let newSource = lead.source;
      let newDestination = lead.destination;
      if (lead.destination === 'China') {
        newSource = 'China';
        if (lead.source !== 'China') autoUpdates.push("source = 'China'");
      } else if (lead.destination === 'Bangladesh') {
        if (lead.source === 'B2B') {
          newSource = 'B2B';
        } else {
          newSource = 'In-House';
          if (lead.source !== 'In-House') autoUpdates.push("source = 'In-House'");
        }
      }
      if (autoUpdates.length) {
        db.prepare(`UPDATE leads SET ${autoUpdates.join(', ')} WHERE id=?`).run(req.params.id);
      }
      logActivity({ type: 'application_stage_changed', actor: req.user, lead, details: { stage: newStage, source: newSource, destination: newDestination } });
    }
  }
  if (autoUpdates.length) {
    lead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  }
  if ((oldLead?.assigned_consultant || '') !== (lead.assigned_consultant || '')) {
    logActivity({ type: 'lead_assigned', actor: req.user, lead, from: oldLead?.assigned_consultant, to: lead.assigned_consultant });
  }
  if ((parseFloat(oldLead?.paid) || 0) !== (parseFloat(lead.paid) || 0)) {
    const delta = (parseFloat(lead.paid) || 0) - (parseFloat(oldLead?.paid) || 0);
    if (delta !== 0) logActivity({ type: 'lead_payment', actor: req.user, lead, amount: delta, from: oldLead.paid, to: lead.paid });
  }
  res.json(lead);
});

router.post('/bulk-assign', (req, res) => requireManagerOrAdmin(req, res, () => {
  try {
    const { ids, consultant } = req.body || {};
    if (!Array.isArray(ids) || ids.length === 0) return res.status(400).json({ error: 'ids array required' });
    if (!consultant || typeof consultant !== 'string') return res.status(400).json({ error: 'consultant name required' });
    const updated = [];
    for (const id of ids) {
      const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(id);
      if (!lead) continue;
      if (!leadIsVisibleTo(lead, req.user)) continue;
      if (isChinaBlockedForUser(lead, req.user)) continue;
      db.prepare("UPDATE leads SET assigned_consultant=? WHERE id=?").run(consultant, id);
      const updatedLead = db.prepare("SELECT * FROM leads WHERE id=?").get(id);
      updated.push(updatedLead);
      logActivity({ type: 'lead_assigned', actor: req.user, lead: updatedLead, from: lead.assigned_consultant, to: consultant });
    }
    res.json({ ok: true, updated: updated.length, leads: updated });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}));

router.delete('/:id', (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to this lead record' });
  }
  db.prepare("DELETE FROM leads WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

router.get('/:id/timeline', (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=? OR lead_id=?").get(req.params.id, req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });

  // 1) Activity log entries tied to this lead (numeric id link)
  const activities = db.prepare("SELECT * FROM activity_log WHERE lead_id=? ORDER BY id DESC LIMIT 500").all(lead.id);

  // 2) Income rows that reference the human lead_id — useful for older entries
  //    that were recorded before the activity log existed.
  const incomes = lead.lead_id
    ? db.prepare("SELECT id, date, amount, category, reference, notes FROM income WHERE lead_id=? ORDER BY id DESC").all(lead.lead_id)
    : [];

  // De-dupe: if we already logged a payment_recorded for the same amount on
  // the same date, skip the income row (it'd be a duplicate event).
  const seen = new Set(activities
    .filter(a => a.type === 'payment_recorded' && a.amount)
    .map(a => `${a.amount}|${(a.created_at || '').slice(0, 10)}`));
  const extraIncome = incomes
    .filter(i => !seen.has(`${i.amount}|${i.date}`))
    .map(i => ({
      id: 'inc-' + i.id,
      type: 'payment_recorded',
      actor_name: null,
      amount: i.amount,
      details: JSON.stringify({ category: i.category, reference: i.reference, notes: i.notes }),
      created_at: i.date + ' 12:00:00',
    }));

  const merged = [...activities, ...extraIncome]
    .sort((a, b) => (b.created_at || '').localeCompare(a.created_at || ''));

  res.json({ lead, timeline: merged });
});

router.post('/:id/notes', (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=? OR lead_id=?").get(req.params.id, req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });
  const { text } = req.body || {};
  if (!text || !text.trim()) return res.status(400).json({ error: 'text is required' });
  logActivity({ type: 'note', actor: req.user, lead, details: text.trim() });
  res.json({ ok: true });
});

router.post('/:id/reply-to-student', (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=? OR lead_id=?").get(req.params.id, req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });
  const { text } = req.body || {};
  if (!text?.trim()) return res.status(400).json({ error: 'text required' });
  logActivity({ type: 'reply_to_student', actor: req.user, lead, details: text.trim() });
  res.json({ ok: true });
});

router.post('/:id/regenerate-token', (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });
  const token = generatePublicToken();
  db.prepare("UPDATE leads SET public_token=?, public_enabled=1 WHERE id=?").run(token, lead.id);
  res.json({ public_token: token });
});

router.put('/:id/public', (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });
  const { enabled } = req.body || {};
  db.prepare("UPDATE leads SET public_enabled=? WHERE id=?").run(enabled ? 1 : 0, lead.id);
  res.json({ ok: true });
});

router.get('/:id/qr', async (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  if (!lead) return res.status(404).end();
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).end();
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).end();
  if (!lead.public_token) {
    const token = generatePublicToken();
    db.prepare("UPDATE leads SET public_token=?, public_enabled=1 WHERE id=?").run(token, lead.id);
    lead.public_token = token;
  }
  const proto = req.headers['x-forwarded-proto'] || req.protocol || 'https';
  const host = req.headers['x-forwarded-host'] || req.get('host');
  const url = `${proto}://${host}/s/${lead.public_token}`;
  const size = Math.min(parseInt(req.query.size) || 240, 600);
  try {
    const r = await fetch(`https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(url)}&margin=0`);
    const buf = Buffer.from(await r.arrayBuffer());
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.send(buf);
  } catch {
    res.status(500).end();
  }
});

router.post('/:id/convert-to-application', (req, res) => {
    const db = getDb();
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to this lead record' });
  }

  const updates = [];
  if (lead.lead_status !== 'File Opened') updates.push("lead_status = 'File Opened'");
  if (lead.application_stage !== 'documents') updates.push("application_stage = 'documents'");

  let newSource = lead.source;
  if (lead.destination === 'China') {
    if (lead.source !== 'China') {
      newSource = 'China';
      updates.push("source = 'China'");
    }
  } else if (lead.destination === 'Bangladesh') {
    if (lead.source === 'B2B') {
      newSource = 'B2B';
    } else if (lead.source !== 'In-House') {
      newSource = 'In-House';
      updates.push("source = 'In-House'");
    }
  }

  if (updates.length) {
    db.prepare(`UPDATE leads SET ${updates.join(', ')} WHERE id=?`).run(req.params.id);
  }

  const updatedLead = db.prepare("SELECT * FROM leads WHERE id=?").get(req.params.id);
  logActivity({ type: 'application_stage_changed', actor: req.user, lead: updatedLead, details: { stage: updatedLead.application_stage || 'documents', source: newSource, destination: updatedLead.destination } });
  sendCAPIEvent('InitiateCheckout', updatedLead).catch(() => {});
  res.json(updatedLead);
});

  return router;
}
