import express from 'express';
import { join, dirname } from 'path';
import { readFileSync, writeFileSync, existsSync } from 'fs';

export default function(dependencies) {
  const router = express.Router();
  const { 
    getDb, requireAdmin, requireManagerOrAdmin, userHasRole, isFullAdmin, canViewOwnLeadsOnly, isChinaBlockedForUser, leadIsVisibleTo, logActivity, sendCAPIEvent, uploadLimiter, getConfig, PERSISTENT_HOME, nextChinaLeadId, nextLeadId, leadParams, LEAD_INSERT_SQL, LEAD_UPDATE_SQL, haversineMeters, signToken, setAuthCookie, autoCheckIn, clearAuthCookie, verifyToken, getCookie, AUTH_COOKIE, hashPassword, requireMarketing 
  } = dependencies;

router.post('/messages/poll', (req, res) => {
    const db = getDb();
  const payload = verifyToken(getCookie(req, AUTH_COOKIE));
  if (!payload) return res.status(401).json({ error: 'Unauthorized' });

  let isResolved = false;
  const clientObj = {
    user: payload,
    send: (event) => {
      if (isResolved) return;
      isResolved = true;
      longPollClients.delete(clientObj);
      res.json(event);
    }
  };

  longPollClients.add(clientObj);

  const timeout = setTimeout(() => {
    if (isResolved) return;
    isResolved = true;
    longPollClients.delete(clientObj);
    res.json({ type: 'timeout' });
  }, 20000);

  req.on('close', () => {
    clearTimeout(timeout);
    longPollClients.delete(clientObj);
  });
});

router.get('/channels', (req, res) => {
    const db = getDb();
  const channels = db.prepare("SELECT * FROM channels ORDER BY id").all();
  // Mask tokens
  let result = channels.map(c => ({ ...c, access_token: c.access_token ? c.access_token.slice(0,14)+'••••••' : null }));
  
  // Filter for non-admin/non-manager
  const loggedInUser = db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
  if (loggedInUser && loggedInUser.role !== 'admin' && loggedInUser.role !== 'manager') {
    const employee = loggedInUser.emp_id
      ? db.prepare("SELECT phone FROM employees WHERE emp_id=?").get(loggedInUser.emp_id)
      : null;
    const empPhone = employee?.phone ? String(employee.phone).replace(/\D/g, '') : '';
    
    result = result.filter(ch => {
      if (ch.type !== 'whatsapp') return true;
      if (!empPhone || empPhone.length < 6) return false;
      const cleanName = String(ch.name || '').replace(/\D/g, '');
      const cleanPhoneId = String(ch.phone_number_id || '').replace(/\D/g, '');
      return (cleanName && (cleanName.endsWith(empPhone) || empPhone.endsWith(cleanName))) ||
             (cleanPhoneId && (cleanPhoneId.endsWith(empPhone) || empPhone.endsWith(cleanPhoneId)));
    });
  }
  
  res.json(result);
});

router.post('/channels', (req, res) => {
    const db = getDb();
  const d = req.body;
  const info = db.prepare(`INSERT INTO channels (type,name,consultant,phone_number_id,waba_id,page_id,ig_account_id,access_token,webhook_verify_token,status,color,active) VALUES (@type,@name,@consultant,@phone_number_id,@waba_id,@page_id,@ig_account_id,@access_token,@webhook_verify_token,@status,@color,@active)`)
    .run({ type: d.type, name: d.name, consultant: d.consultant||null, phone_number_id: d.phone_number_id||null, waba_id: d.waba_id||null, page_id: d.page_id||null, ig_account_id: d.ig_account_id||null, access_token: d.access_token||null, webhook_verify_token: d.webhook_verify_token||'eduexpress_verify_2024', status: d.status||'active', color: d.color||'#3b82f6', active: d.active ?? 1 });
  const newChan = db.prepare("SELECT * FROM channels WHERE id=?").get(info.lastInsertRowid);
  syncChannelMetadata(newChan.id).catch(e => console.error('[channel-metadata] Post-create sync failed:', e.message));
  res.json(newChan);
});

router.put('/channels/:id', (req, res) => {
    const db = getDb();
  const d = req.body;
  const existing = db.prepare("SELECT * FROM channels WHERE id=?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Not found' });
  const token = (d.access_token && !d.access_token.includes('••')) ? d.access_token : existing.access_token;
  db.prepare(`UPDATE channels SET type=@type,name=@name,consultant=@consultant,phone_number_id=@phone_number_id,waba_id=@waba_id,page_id=@page_id,ig_account_id=@ig_account_id,access_token=@access_token,webhook_verify_token=@webhook_verify_token,status=@status,color=@color,active=@active WHERE id=@id`)
    .run({ ...d, id: req.params.id, consultant: d.consultant||null, access_token: token, active: d.active ?? existing.active ?? 1 });
  const updatedChan = db.prepare("SELECT * FROM channels WHERE id=?").get(req.params.id);
  syncChannelMetadata(updatedChan.id).catch(e => console.error('[channel-metadata] Post-update sync failed:', e.message));
  res.json(updatedChan);
});

router.delete('/channels/:id', (req, res) => {
    const db = getDb(); db.prepare("DELETE FROM channels WHERE id=?").run(req.params.id); res.json({ ok:true }); });

router.post('/channels/:id/load-history', async (req, res) => {
    const db = getDb();
  const channel = db.prepare("SELECT * FROM channels WHERE id=?").get(req.params.id);
  if (!channel) return res.status(404).json({ error: 'Channel not found' });
  let effectiveToken = channel.access_token || getConfig('page_access_token');
  if (!effectiveToken) return res.status(400).json({ error: 'No access token configured for this channel' });
  if (!channel.page_id) return res.status(400).json({ error: 'No page_id set on this channel' });
  if (channel.type !== 'messenger' && channel.type !== 'instagram' && channel.type !== 'tiktok')
    return res.status(400).json({ error: 'Sync only supported for Messenger and Instagram channels' });
  if (channel.type === 'tiktok')
    return res.status(400).json({ error: 'TikTok sync is not yet supported' });
  if (activeSyncs.has(channel.id))
    return res.status(409).json({ error: 'A sync is already running for this channel' });

  const { months = 6 } = req.body || {};

  // Dynamically resolve the Page Access Token from the configured token (e.g. System User token)
  effectiveToken = await resolvePageAccessToken(channel.page_id, effectiveToken);

  // ── Validate the token before starting background sync ──
  try {
    const platform = channel.type === 'instagram' ? 'instagram' : 'messenger';
    const testUrl = `https://graph.facebook.com/v19.0/${channel.page_id}?fields=name,picture.type(large)&access_token=${effectiveToken}`;
    const testRes = await fetch(testUrl);
    const testData = await testRes.json();
    if (testData.error) {
      console.error(`[sync] Token validation failed for ${channel.name}: ${testData.error.message}`);
      return res.status(400).json({ error: `Facebook API token invalid: ${testData.error.message}` });
    }
    if (testData.name) {
      const avatarUrl = testData.picture?.data?.url || null;
      db.prepare("UPDATE channels SET name = ?, avatar_url = ? WHERE id = ?").run(testData.name, avatarUrl, channel.id);
    }
  } catch (e) {
    console.error(`[sync] Token validation network error for ${channel.name}:`, e.message);
    return res.status(400).json({ error: `Could not validate Facebook token: ${e.message}` });
  }

  // Respond NOW — everything below runs in the background.
  activeSyncs.add(channel.id);
  res.json({ ok: true, started: true, channel: channel.name });

  syncChannelMessages(channel.id, months)
    .catch(e => console.error('[sync] Background sync failed:', e.message))
    .finally(() => activeSyncs.delete(channel.id));
});

router.get('/conversations', (req, res) => {
    const db = getDb();
  const { status, channel_type, channel_id, assigned_to, search, page=1, limit=30 } = req.query;
  const where=[]; const params={};
  if (status && status !== 'all') { where.push("conversations.status=@status"); params.status=status; }
  if (channel_type && channel_type !== 'all') { where.push("conversations.channel_type=@channel_type"); params.channel_type=channel_type; }
  if (channel_id && channel_id !== 'all') { where.push("conversations.channel_id=@channel_id"); params.channel_id=channel_id; }
  if (assigned_to && assigned_to !== 'all') { where.push("conversations.assigned_to=@assigned_to"); params.assigned_to=assigned_to; }
  if (search && search !== 'undefined' && search !== 'null') { where.push("(contacts.name LIKE @search OR contacts.phone LIKE @search)"); params.search=`%${search}%`; }

  // RBAC Access Filter: role-based rules merged with phone-number matching
  const user = req.user;
  if (!isFullAdmin(user) && !canViewAllConversations(user)) {
    const loggedInUser = db.prepare("SELECT * FROM users WHERE id=?").get(user.id);
    const meConsultant = (loggedInUser?.consultant_name || '').trim();
    
    const employee = loggedInUser?.emp_id
      ? db.prepare("SELECT phone FROM employees WHERE emp_id=?").get(loggedInUser.emp_id)
      : null;
    const empPhone = employee?.phone ? String(employee.phone).replace(/\D/g, '') : '';

    // Load all active channels to determine accessibility
    const allChannels = db.prepare("SELECT id, type, name, phone_number_id, consultant FROM channels WHERE active = 1").all();
    const accessibleChannelIds = [];

    for (const ch of allChannels) {
      if (ch.type !== 'whatsapp' && ch.type !== 'waba') {
        // Non-WhatsApp: full access for consultants
        accessibleChannelIds.push(ch.id);
      } else {
        // WhatsApp/WABA: check consultant name, or access in channel_access, or phone matching
        const matchConsultant = ch.consultant && meConsultant &&
          ch.consultant.trim().toLowerCase() === meConsultant.toLowerCase();
          
        let matchPhone = false;
        if (empPhone && empPhone.length >= 6) {
          const cleanName = String(ch.name || '').replace(/\D/g, '');
          const cleanPhoneId = String(ch.phone_number_id || '').replace(/\D/g, '');
          matchPhone = (cleanName && (cleanName.endsWith(empPhone) || empPhone.endsWith(cleanName))) ||
                       (cleanPhoneId && (cleanPhoneId.endsWith(empPhone) || empPhone.endsWith(cleanPhoneId)));
        }
        
        // Check if explicitly granted access in channel_access table
        const hasExplicitAccess = db.prepare("SELECT 1 FROM channel_access WHERE channel_id=? AND user_id=?").get(ch.id, user.id);

        if (matchConsultant || matchPhone || hasExplicitAccess) {
          accessibleChannelIds.push(ch.id);
        }
      }
    }

    if (accessibleChannelIds.length > 0) {
      where.push(`(conversations.channel_id IN (${accessibleChannelIds.join(',')}) OR conversations.assigned_to = @user_id)`);
    } else {
      where.push("conversations.assigned_to = @user_id");
    }
    params.user_id = user.id;
  }
  
  // China data isolation: exclude conversations linked to China leads for unauthorized users
  if (!canViewChinaData(req.user)) {
    where.push("(leads.destination != 'China' OR leads.destination IS NULL) AND (leads.source != 'China' OR leads.source IS NULL)");
  }

  // Investors: no conversation access at all
  if (isInvestor(user) && !isFullAdmin(user)) {
    return res.json({ conversations: [], total: 0, page: 1, pages: 0 });
  }

  const ws = where.length ? 'WHERE '+where.join(' AND ') : '';
  const total = db.prepare(`SELECT COUNT(*) as c FROM conversations LEFT JOIN contacts ON contacts.id=conversations.contact_id LEFT JOIN channels ON channels.id=conversations.channel_id LEFT JOIN leads ON leads.id = conversations.lead_id ${ws}`).get(params).c;
  const convs = db.prepare(`${CONV_SELECT} ${ws} ORDER BY conversations.last_message_at DESC LIMIT ${limit} OFFSET ${(page-1)*limit}`).all(params);

  // Compute SLA status and priority per conversation
  const now = Date.now();
  const priorityTagIds = db.prepare("SELECT id FROM contact_tags WHERE LOWER(name)='priority'").all().map(r => r.id);
  const convWithMeta = convs.map(c => {
    const lastAt = c.last_message_at ? new Date(c.last_message_at).getTime() : 0;
    const minsSince = lastAt ? (now - lastAt) / 60000 : Infinity;
    let sla_status;
    if (!lastAt || c.last_message_direction !== 'out') {
      sla_status = 'red';
    } else if (minsSince < 30) {
      sla_status = 'green';
    } else if (minsSince < 120) {
      sla_status = 'yellow';
    } else {
      sla_status = 'red';
    }
    // Priority: has 'priority' tag OR new lead without any outbound response
    let priority = 0;
    if (priorityTagIds.length) {
      const hasTag = db.prepare("SELECT 1 FROM conversation_tags WHERE conversation_id=? AND tag_id IN (" + priorityTagIds.map(() => '?').join(',') + ") LIMIT 1").get(c.id, ...priorityTagIds);
      if (hasTag) priority = 1;
    }
    if (!priority && c.lead_id && c.outbound_count === 0) priority = 1;
    return { ...c, sla_status, priority };
  });

  // Sort by priority first, then by last_message_at desc
  convWithMeta.sort((a, b) => {
    if (b.priority !== a.priority) return b.priority - a.priority;
    return (b.last_message_at || '').localeCompare(a.last_message_at || '');
  });

  res.json({ conversations: convWithMeta, total, page: parseInt(page), pages: Math.ceil(total/limit) });
});

router.get('/conversations/:id', (req, res) => {
    const db = getDb();
  const conv = db.prepare(`${CONV_SELECT} WHERE conversations.id=?`).get(req.params.id);
  if (!conv) return res.status(404).json({ error:'Not found' });

  // RBAC check
  if (!userHasAccessToConversation(req.user, req.params.id)) {
    return res.status(403).json({ error: 'Access denied' });
  }

  res.json(conv);
});

router.post('/conversations/:id/convert-lead', (req, res) => {
    const db = getDb();
  try {
    if (!userHasAccessToConversation(req.user, req.params.id)) return res.status(403).json({ error: 'Access denied' });
    const { lead_id, destination, phone, degree, client_name } = req.body;
    if (!userHasAccessToConversation(req.user, req.params.id)) {
      return res.status(403).json({ error: 'Access denied' });
    }
    const conv = db.prepare("SELECT * FROM conversations WHERE id=?").get(req.params.id);
    if (!conv) return res.status(404).json({ error: 'Conversation not found' });

    let lead = null;
    if (lead_id) {
      // Link to existing lead
      lead = db.prepare("SELECT * FROM leads WHERE id=?").get(lead_id);
      if (!lead) return res.status(404).json({ error: 'Selected lead not found' });

      db.prepare("UPDATE contacts SET lead_id=? WHERE id=?").run(lead.id, conv.contact_id);
      db.prepare("UPDATE conversations SET lead_id=? WHERE id=?").run(lead.id, conv.id);

      // If lead does not have assigned consultant, assign the channel's consultant
      if (!lead.assigned_consultant || lead.assigned_consultant.trim() === '') {
        const channel = db.prepare("SELECT consultant FROM channels WHERE id=?").get(conv.channel_id);
        const consultant = channel?.consultant || 'Abdullah Al Rakib';
        db.prepare("UPDATE leads SET assigned_consultant=? WHERE id=?").run(consultant, lead.id);
        lead.assigned_consultant = consultant;
      }
    } else {
      // Create new lead
      lead = createLeadFromContact(conv.contact_id, conv.channel_type, conv.last_message, req.user, {
        destination, phone, degree, client_name
      });
      if (!lead) return res.status(500).json({ error: 'Failed to create lead' });
    }

    res.json({
      success: true,
      lead_id: lead.id,
      lead,
      conversation: db.prepare(`${CONV_SELECT} WHERE conversations.id=?`).get(conv.id)
    });
  } catch (err) {
    console.error('Convert lead error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Quick Convert to Lead from conversation (manual override with provided data)
router.post('/conversations/:id/convert-to-lead', (req, res) => {
  try {
    const { client_name, phone, email, destination, source, notes } = req.body || {};
    const conv = db.prepare("SELECT * FROM conversations WHERE id=?").get(req.params.id);
    if (!conv) return res.status(404).json({ error: 'Conversation not found' });

    const contact = db.prepare("SELECT * FROM contacts WHERE id=?").get(conv.contact_id);
    if (!contact) return res.status(404).json({ error: 'Contact not found' });

    const channel = db.prepare("SELECT * FROM channels WHERE id=?").get(conv.channel_id);
    const assigned_consultant = channel?.consultant || null;

    const leadSourceMap = {
      whatsapp: 'WhatsApp',
      messenger: 'Messenger',
      instagram: 'Instagram',
      tiktok: 'TikTok'
    };
    const lead_id = nextLeadId();
    const params = leadParams({
      client_name: client_name || contact.name || 'Unknown',
      phone: phone || contact.phone || null,
      email: email || contact.email || null,
      destination: destination || 'Bangladesh',
      source: source || 'In-House',
      lead_source: leadSourceMap[conv.channel_type] || 'Chat',
      lead_status: 'New Lead',
      assigned_consultant,
      notes: notes || null,
    }, lead_id, 0);

    const info = db.prepare(LEAD_INSERT_SQL).run(params);
    const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(info.lastInsertRowid);

    db.prepare("UPDATE contacts SET lead_id=? WHERE id=?").run(lead.id, contact.id);
    db.prepare("UPDATE conversations SET lead_id=? WHERE id=?").run(lead.id, conv.id);

    sendCAPIEvent('Lead', lead).catch(() => {});
    logActivity({ type: 'lead_created', actor: req.user, lead, details: { source: lead.lead_source, destination: lead.destination, assigned_consultant: lead.assigned_consultant, note: 'Converted from conversation' } });
    broadcast('new_lead', { lead });

    res.json({ success: true, lead_id: lead.id, lead });
  } catch (err) {
    console.error('Convert to lead error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Move a lead to application pipeline (convert to application)

router.put('/conversations/:id', (req, res) => {
  if (!userHasAccessToConversation(req.user, req.params.id)) return res.status(403).json({ error: 'Access denied' });
  const { status, assigned_to, lead_id } = req.body;
  db.prepare("UPDATE conversations SET status=COALESCE(@status,status), assigned_to=COALESCE(@assigned_to,assigned_to), lead_id=COALESCE(@lead_id,lead_id), unread_count=CASE WHEN @status='open' THEN unread_count ELSE 0 END WHERE id=@id")
    .run({ status: status||null, assigned_to: assigned_to||null, lead_id: lead_id||null, id: req.params.id });

  if (lead_id) {
    const conv = db.prepare("SELECT channel_id FROM conversations WHERE id=?").get(req.params.id);
    if (conv) {
      const channel = db.prepare("SELECT consultant FROM channels WHERE id=?").get(conv.channel_id);
      const lead = db.prepare("SELECT assigned_consultant FROM leads WHERE id=?").get(lead_id);
      if (lead && (!lead.assigned_consultant || lead.assigned_consultant.trim() === '')) {
        db.prepare("UPDATE leads SET assigned_consultant=? WHERE id=?").run(channel?.consultant || 'Abdullah Al Rakib', lead_id);
      }
    }
  }

  res.json(db.prepare(`${CONV_SELECT} WHERE conversations.id=?`).get(req.params.id));
});

// Create outbound conversation manually
router.post('/conversations', (req, res) => {
  try {
    const { channel_id, phone, name, lead_id } = req.body;
    if (!channel_id || !phone) return res.status(400).json({ error: 'channel_id and phone required' });
    const channel = db.prepare("SELECT * FROM channels WHERE id=?").get(channel_id);
    if (!channel) return res.status(404).json({ error: 'Channel not found' });
    // RBAC: check if user can access this channel
    if (!userHasAccessToConversation(req.user, { channel_id, channel_type: channel.type })) {
      return res.status(403).json({ error: 'Access denied to this channel' });
    }
    const contact = upsertContact({ name: name || phone, phone, wa_id: channel.type === 'whatsapp' ? phone : null });
    
    // Link contact and conversation to lead if lead_id is provided
    let resolvedLeadId = lead_id;
    if (!resolvedLeadId && phone) {
      // Find lead by matching phone exactly
      let matchedLead = db.prepare("SELECT id FROM leads WHERE phone=?").get(phone);
      if (!matchedLead) {
        // Try cleaning the input phone to check if any lead phone matches when cleaned
        const cleanPhone = phone.replace(/\D/g, '');
        if (cleanPhone.length >= 8) {
          // Find all leads and look for one with matching digits
          const allLeads = db.prepare("SELECT id, phone FROM leads WHERE phone IS NOT NULL").all();
          matchedLead = allLeads.find(l => {
            const lp = l.phone.replace(/\D/g, '');
            return lp === cleanPhone || lp.endsWith(cleanPhone) || cleanPhone.endsWith(lp);
          });
        }
      }
      if (matchedLead) {
        resolvedLeadId = matchedLead.id;
      }
    }
    
    if (resolvedLeadId) {
      db.prepare("UPDATE contacts SET lead_id=? WHERE id=?").run(resolvedLeadId, contact.id);
    }
    
    const conversation = upsertConversation(contact.id, channel_id, channel.type);
    
    // Make sure conversation lead_id is set
    if (resolvedLeadId) {
      db.prepare("UPDATE conversations SET lead_id=? WHERE id=?").run(resolvedLeadId, conversation.id);
      // Auto-assign consultant to the lead if not set
      const lead = db.prepare("SELECT assigned_consultant FROM leads WHERE id=?").get(resolvedLeadId);
      if (lead && (!lead.assigned_consultant || lead.assigned_consultant.trim() === '')) {
        db.prepare("UPDATE leads SET assigned_consultant=? WHERE id=?").run(channel.consultant || 'Abdullah Al Rakib', resolvedLeadId);
      }
    }

    const conv = db.prepare(`${CONV_SELECT} WHERE conversations.id=?`).get(conversation.id);
    res.json(conv);
  } catch(e) {
    console.error('createConversation error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

// Mark conversation read
router.post('/conversations/:id/read', (req, res) => {
  if (!userHasAccessToConversation(req.user, req.params.id)) {
    return res.status(403).json({ error: 'Access denied' });
  }
  db.prepare("UPDATE conversations SET unread_count=0 WHERE id=?").run(req.params.id);
  res.json({ ok:true });
});

// Mark conversation unread
router.post('/conversations/:id/unread', (req, res) => {
  if (!userHasAccessToConversation(req.user, req.params.id)) {
    return res.status(403).json({ error: 'Access denied' });
  }
  db.prepare("UPDATE conversations SET unread_count=1 WHERE id=?").run(req.params.id);
  res.json({ ok:true });
});

// Delete an entire conversation (and its messages)
router.delete('/conversations/:id', (req, res) => {
  try {
    if (!userHasAccessToConversation(req.user, req.params.id)) return res.status(403).json({ error: 'Access denied' });
    const conv = db.prepare("SELECT * FROM conversations WHERE id=?").get(req.params.id);
    if (conv) {
      db.prepare("DELETE FROM messages WHERE conversation_id=?").run(req.params.id);
      db.prepare("DELETE FROM conversations WHERE id=?").run(req.params.id);
      broadcast('conversation_deleted', { conversation_id: parseInt(req.params.id) }, (u) => {
        if (!u) return false;
        return userHasAccessToConversation(u, req.params.id);
      });
    }
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Delete a single message
router.delete('/messages/:id', (req, res) => {
  try {
    const msg = db.prepare("SELECT * FROM messages WHERE id=?").get(req.params.id);
    db.prepare("DELETE FROM messages WHERE id=?").run(req.params.id);
    if (msg) {
      // Refresh conversation's last_message preview
      const last = db.prepare("SELECT content, type, created_at FROM messages WHERE conversation_id=? ORDER BY id DESC LIMIT 1").get(msg.conversation_id);
      db.prepare("UPDATE conversations SET last_message=?, last_message_at=? WHERE id=?")
        .run(last?.content || (last ? `[${last.type}]` : ''), last?.created_at || null, msg.conversation_id);
      broadcast('message_deleted', { conversation_id: msg.conversation_id, message_id: parseInt(req.params.id) });
    }
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/conversations/:id/messages', (req, res) => {
    const db = getDb();
  if (!userHasAccessToConversation(req.user, req.params.id)) {
    return res.status(403).json({ error: 'Access denied' });
  }
  const { before, limit=500 } = req.query;
  // Order CHRONOLOGICALLY by timestamp (not insert id) — synced messages are
  // inserted newest-first, so id order ≠ time order. Grab the most-recent N,
  // then flip to ascending so the chat reads oldest→newest top-to-bottom.
  const beforeClause = before ? 'AND id < @before' : '';
  const msgParams = { conv_id: req.params.id, before: before ? parseInt(before) : undefined, lim: Math.min(parseInt(limit) || 500, 2000) };
  const msgs = db.prepare(
    `SELECT * FROM (
       SELECT * FROM messages
       WHERE conversation_id=@conv_id ${beforeClause}
       ORDER BY created_at DESC, id DESC
       LIMIT @lim
     ) ORDER BY created_at ASC, id ASC`
  ).all(msgParams);
  res.json(msgs);
});

router.post('/conversations/:id/messages', async (req, res) => {
    const db = getDb();
  try {
    if (!userHasAccessToConversation(req.user, req.params.id)) return res.status(403).json({ error: 'Access denied' });
    const { content, type='text', sent_by='Admin', media_url } = req.body;
    if (!content && !media_url) return res.status(400).json({ error: 'content is required' });

    const conv = db.prepare(`${CONV_SELECT} WHERE conversations.id=?`).get(req.params.id);
    if (!conv) return res.status(404).json({ error:'Conversation not found' });

    // Get full channel (with token), fallback to active channel of same type if not found
    let channel = db.prepare("SELECT * FROM channels WHERE id=?").get(conv.channel_id);
    if (!channel) {
      channel = db.prepare("SELECT * FROM channels WHERE type=? AND status='active'").get(conv.channel_type);
      if (channel) {
        db.prepare("UPDATE conversations SET channel_id=? WHERE id=?").run(channel.id, req.params.id);
      }
    }
    if (!channel) return res.status(400).json({ error:'Channel not found' });

    let apiResult = null;
    try {
      if (channel.type === 'whatsapp') {
        const to = conv.wa_id || conv.contact_phone;
        if (!to) throw new Error('No recipient phone number found');
        apiResult = await sendWhatsApp(channel, to, content, type, media_url);
      } else if (channel.type === 'messenger') {
        apiResult = await sendMessenger(channel, conv.messenger_id, content, type, media_url);
      } else if (channel.type === 'instagram') {
        apiResult = await sendMessenger({ ...channel, page_id: channel.ig_account_id || channel.page_id }, conv.instagram_id || conv.messenger_id, content, type, media_url);
      }
    } catch (e) {
      console.error('Send API error:', e.message);
      apiResult = { error: { message: e.message } };
    }

    const waId = apiResult?.messages?.[0]?.id || apiResult?.message_id || null;
    const status = apiResult?.error ? 'failed' : 'sent';
    const errMsg = apiResult?.error ? (apiResult.error.message || JSON.stringify(apiResult.error)) : null;
    const info = db.prepare(`INSERT INTO messages (conversation_id,direction,type,content,media_url,wa_message_id,status,sent_by,error_msg) VALUES (?,?,?,?,?,?,?,?,?)`)
      .run(req.params.id, 'out', type, content, media_url||null, waId, status, sent_by, errMsg);
    const msg = db.prepare("SELECT * FROM messages WHERE id=?").get(info.lastInsertRowid);

    db.prepare("UPDATE conversations SET last_message=?, last_message_at=datetime('now'), status='open' WHERE id=?").run(content || (type === 'image' ? '📷 Image' : '📎 Document'), req.params.id);
    broadcast('new_message', { ...msg, conversation_id: parseInt(req.params.id), direction: 'outbound' }, (u) => userHasAccessToConversation(u, req.params.id));
    res.json({ message: msg, apiResult });
  } catch(e) {
    console.error('sendMessage error:', e.message, e.stack);
    res.status(500).json({ error: e.message });
  }
});

router.get('/automation/rules', (req, res) => requireManagerOrAdmin(req, res, () => {
  const rows = db.prepare("SELECT * FROM automation_rules ORDER BY priority DESC, id DESC").all();
  res.json(rows.map(r => ({
    ...r,
    is_active: r.active === 1,
    trigger_config: r.trigger_config ? JSON.parse(r.trigger_config) : {},
    action_config: r.action_config ? JSON.parse(r.action_config) : {}
  })));
}));

router.post('/automation/rules', (req, res) => requireAdmin(req, res, () => {
  const { name, trigger_type, trigger_config, action_type, action_config, priority, active, is_active } = req.body || {};
  if (!name || !trigger_type || !action_type) return res.status(400).json({ error: 'name, trigger_type, and action_type are required' });
  const effectiveActive = is_active !== undefined ? (is_active ? 1 : 0) : (active !== undefined ? (active ? 1 : 0) : 1);
  const info = db.prepare(`INSERT INTO automation_rules (name, trigger_type, trigger_config, action_type, action_config, priority, active)
    VALUES (?,?,?,?,?,?,?)`).run(name, trigger_type, trigger_config ? JSON.stringify(trigger_config) : null, action_type, action_config ? JSON.stringify(action_config) : null, priority ?? 0, effectiveActive);
  const r = db.prepare("SELECT * FROM automation_rules WHERE id=?").get(info.lastInsertRowid);
  res.json({
    ...r,
    is_active: r.active === 1,
    trigger_config: r.trigger_config ? JSON.parse(r.trigger_config) : {},
    action_config: r.action_config ? JSON.parse(r.action_config) : {}
  });
}));

router.put('/automation/rules/:id', (req, res) => requireAdmin(req, res, () => {
  const { name, trigger_type, trigger_config, action_type, action_config, priority, active, is_active } = req.body || {};
  const cur = db.prepare("SELECT * FROM automation_rules WHERE id=?").get(req.params.id);
  if (!cur) return res.status(404).json({ error: 'Not found' });
  const effectiveActive = is_active !== undefined ? (is_active ? 1 : 0) : (active !== undefined ? (active ? 1 : 0) : null);
  db.prepare(`UPDATE automation_rules SET name=COALESCE(?,name), trigger_type=COALESCE(?,trigger_type), trigger_config=COALESCE(?,trigger_config), action_type=COALESCE(?,action_type), action_config=COALESCE(?,action_config), priority=COALESCE(?,priority), active=COALESCE(?,active) WHERE id=?`)
    .run(name ?? null, trigger_type ?? null, trigger_config ? JSON.stringify(trigger_config) : null, action_type ?? null, action_config ? JSON.stringify(action_config) : null, priority ?? null, effectiveActive, req.params.id);
  const r = db.prepare("SELECT * FROM automation_rules WHERE id=?").get(req.params.id);
  res.json({
    ...r,
    is_active: r.active === 1,
    trigger_config: r.trigger_config ? JSON.parse(r.trigger_config) : {},
    action_config: r.action_config ? JSON.parse(r.action_config) : {}
  });
}));

router.delete('/automation/rules/:id', (req, res) => requireAdmin(req, res, () => {
  db.prepare("DELETE FROM automation_rules WHERE id=?").run(req.params.id);
  res.json({ ok: true });
}));

router.post('/automation/rules/:id/test', (req, res) => requireAdmin(req, res, () => {
  const rule = db.prepare("SELECT * FROM automation_rules WHERE id=?").get(req.params.id);
  if (!rule) return res.status(404).json({ error: 'Rule not found' });
  res.json({ ok: true, message: 'Rule test would be triggered here' });
}));

router.get('/conversations/:id/notes', (req, res) => {
    const db = getDb();
  if (!userHasAccessToConversation(req.user, req.params.id)) return res.status(403).json({ error: 'Access denied' });
  const rows = db.prepare("SELECT * FROM conversation_notes WHERE conversation_id=? ORDER BY id DESC").all(req.params.id);
  res.json(rows);
});

router.post('/conversations/:id/notes', (req, res) => {
    const db = getDb();
  if (!userHasAccessToConversation(req.user, req.params.id)) return res.status(403).json({ error: 'Access denied' });
  const { note, is_internal } = req.body || {};
  if (!note || !note.trim()) return res.status(400).json({ error: 'note is required' });
  const info = db.prepare(`INSERT INTO conversation_notes (conversation_id, note, author_id, author_name, is_internal)
    VALUES (?,?,?,?,?)`).run(req.params.id, note.trim(), req.user?.id || null, req.user?.name || null, is_internal == null ? 1 : (is_internal ? 1 : 0));
  res.json(db.prepare("SELECT * FROM conversation_notes WHERE id=?").get(info.lastInsertRowid));
});

router.post('/conversations/:id/tags', (req, res) => {
    const db = getDb();
  if (!userHasAccessToConversation(req.user, req.params.id)) return res.status(403).json({ error: 'Access denied' });
  const { tag_id } = req.body || {};
  if (!tag_id) return res.status(400).json({ error: 'tag_id is required' });
  const tag = db.prepare("SELECT * FROM contact_tags WHERE id=?").get(tag_id);
  if (!tag) return res.status(404).json({ error: 'Tag not found' });
  db.prepare("INSERT OR IGNORE INTO conversation_tags (conversation_id, tag_id) VALUES (?,?)").run(req.params.id, tag_id);
  res.json({ ok: true });
});

router.delete('/conversations/:id/tags', (req, res) => {
    const db = getDb();
  if (!userHasAccessToConversation(req.user, req.params.id)) return res.status(403).json({ error: 'Access denied' });
  const { tag_id } = req.body || {};
  if (!tag_id) return res.status(400).json({ error: 'tag_id is required' });
  db.prepare("DELETE FROM conversation_tags WHERE conversation_id=? AND tag_id=?").run(req.params.id, tag_id);
  res.json({ ok: true });
});

router.get('/broadcast-campaigns', (req, res) => requireManagerOrAdmin(req, res, () => {
  const rows = db.prepare("SELECT * FROM broadcast_campaigns ORDER BY id DESC").all();
  res.json(rows);
}));

router.post('/broadcast-campaigns', (req, res) => requireAdmin(req, res, () => {
  const { name, segment_type, segment_config, segment_value, template_id, content, scheduled_at } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name is required' });
  let finalConfig = segment_config || {};
  if (segment_value) {
    if (segment_type === 'by_tag' || segment_type === 'tag') {
      finalConfig.tag_ids = [parseInt(segment_value)];
    } else if (segment_type === 'by_status' || segment_type === 'status') {
      finalConfig.lead_statuses = [segment_value];
    } else if (segment_type === 'by_channel' || segment_type === 'channel') {
      finalConfig.channel_types = [segment_value];
    }
  }
  const info = db.prepare(`INSERT INTO broadcast_campaigns (name, segment_type, segment_config, template_id, content, scheduled_at, created_by)
    VALUES (?,?,?,?,?,?,?)`).run(name, segment_type || null, JSON.stringify(finalConfig), template_id || null, content || null, scheduled_at || null, req.user?.name || req.user?.email || null);
  res.json(db.prepare("SELECT * FROM broadcast_campaigns WHERE id=?").get(info.lastInsertRowid));
}));

router.post('/broadcast-campaigns/:id/send', (req, res) => requireAdmin(req, res, async () => {
  const result = await sendBroadcast(req.params.id);
  if (result.error) return res.status(400).json({ error: result.error });
  res.json(result);
}));

router.delete('/broadcast-campaigns/:id', (req, res) => requireAdmin(req, res, () => {
  db.prepare("DELETE FROM broadcast_recipients WHERE campaign_id=?").run(req.params.id);
  db.prepare("DELETE FROM broadcast_campaigns WHERE id=?").run(req.params.id);
  res.json({ ok: true });
}));

router.post('/broadcast-campaigns/:id/pause', (req, res) => requireAdmin(req, res, () => {
  db.prepare("UPDATE broadcast_campaigns SET status='paused' WHERE id=?").run(req.params.id);
  res.json({ ok: true });
}));

router.post('/broadcast-campaigns/:id/resume', (req, res) => requireAdmin(req, res, () => {
  db.prepare("UPDATE broadcast_campaigns SET status='sending' WHERE id=?").run(req.params.id);
  res.json({ ok: true });
}));

router.get('/automation/stats', (req, res) => requireManagerOrAdmin(req, res, () => {
  const today = new Date().toISOString().slice(0, 10);
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

  const totalTriggered = db.prepare("SELECT COUNT(*) as c FROM automation_analytics WHERE event_type='triggered'").get().c;
  const totalExecuted = db.prepare("SELECT COUNT(*) as c FROM automation_analytics WHERE event_type='executed'").get().c;
  const totalFailed = db.prepare("SELECT COUNT(*) as c FROM automation_analytics WHERE event_type='failed'").get().c;
  const rulesTriggeredToday = db.prepare("SELECT COUNT(*) as c FROM automation_analytics WHERE event_type='triggered' AND date(created_at)=?").get(today).c;
  const messagesSentToday = db.prepare("SELECT COUNT(*) as c FROM messages WHERE direction='out' AND date(created_at)=? AND sent_by='auto'").get(today).c;
  const templatesUsedToday = db.prepare("SELECT COUNT(*) as c FROM message_templates WHERE usage_count > 0").get().c;
  const activeConversations = db.prepare("SELECT COUNT(*) as c FROM conversations WHERE status='open' AND last_message_at >= ?").get(sevenDaysAgo).c;

  const messagesPerChannel = db.prepare(`
    SELECT c.name, COUNT(*) as count
    FROM messages m
    JOIN conversations conv ON conv.id = m.conversation_id
    JOIN channels c ON c.id = conv.channel_id
    WHERE m.created_at >= ? AND m.direction='in'
    GROUP BY c.id
    ORDER BY count DESC
  `).all(sevenDaysAgo);

  const triggersOverTime = db.prepare(`
    SELECT date(created_at) as date, COUNT(*) as count
    FROM automation_analytics
    WHERE event_type='triggered' AND created_at >= ?
    GROUP BY date(created_at)
    ORDER BY date
  `).all(sevenDaysAgo);

  const topRules = db.prepare(`
    SELECT r.id, r.name, COUNT(*) as count
    FROM automation_analytics a
    JOIN automation_rules r ON r.id = a.rule_id
    WHERE a.event_type='executed' AND a.created_at >= ?
    GROUP BY r.id
    ORDER BY count DESC
    LIMIT 10
  `).all(sevenDaysAgo);

  // Average response time: time between first inbound and first outbound reply
  const avgResponse = db.prepare(`
    SELECT AVG(
      (julianday(first_out.created_at) - julianday(first_in.created_at)) * 24 * 60
    ) as avg_minutes
    FROM (
      SELECT conversation_id, MIN(created_at) as created_at
      FROM messages
      WHERE direction='in' AND created_at >= ?
      GROUP BY conversation_id
    ) first_in
    JOIN (
      SELECT conversation_id, MIN(created_at) as created_at
      FROM messages
      WHERE direction='out' AND is_internal_note=0
      GROUP BY conversation_id
    ) first_out ON first_in.conversation_id = first_out.conversation_id
    WHERE first_out.created_at > first_in.created_at
  `).get(sevenDaysAgo);

  const totalConversations = db.prepare("SELECT COUNT(*) as c FROM conversations WHERE last_message_at >= ?").get(sevenDaysAgo).c;
  const archivedConversations = db.prepare("SELECT COUNT(*) as c FROM conversations WHERE status='archived' AND last_message_at >= ?").get(sevenDaysAgo).c;
  const resolutionRate = totalConversations > 0 ? Math.round((archivedConversations / totalConversations) * 100) : 0;

  const recent = db.prepare("SELECT * FROM automation_analytics ORDER BY id DESC LIMIT 50").all();

  res.json({
    totalTriggered,
    totalExecuted,
    totalFailed,
    rules_triggered_today: rulesTriggeredToday,
    messages_sent_today: messagesSentToday,
    templates_used_today: templatesUsedToday,
    active_conversations: activeConversations,
    messages_per_channel: messagesPerChannel,
    triggers_over_time: triggersOverTime,
    top_rules: topRules,
    avg_response_time_minutes: Math.round(avgResponse?.avg_minutes || 0),
    resolution_rate: resolutionRate,
    byRule: db.prepare("SELECT rule_id, event_type, COUNT(*) as c FROM automation_analytics GROUP BY rule_id, event_type").all(),
    recent,
  });
}));

  return router;
}
