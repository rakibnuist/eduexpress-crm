import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import crypto from 'crypto';
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, copyFileSync, unlinkSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join, resolve } from 'path';
import { createRequire } from 'module';
import { initDatabase, isDead } from './sqldb.js';
import authRouter from './routes/auth.js';
import usersRouter from './routes/users.js';
import leadsRouter from './routes/leads.js';
import messagingRouter from './routes/messaging.js';
import activityRouter from './routes/activity.js';
import marketingRouter from './routes/marketing.js';
import financeRouter from './routes/finance.js';
import settingsRouter from './routes/settings.js';

const require = createRequire(import.meta.url);

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || process.env.LSNODE_SOCKET || 3001;

const PERSISTENT_HOME = '/home/u898266115';
const LOCAL_DB_PATH = join(__dirname, 'crm.db');
let DB_PATH = process.env.DB_PATH;
import https from 'https';
import fs from 'fs';

if (!DB_PATH) {
  if (process.platform === 'linux' && existsSync(PERSISTENT_HOME)) {
    const dataDir = join(PERSISTENT_HOME, 'crm-data');
    if (!existsSync(dataDir)) {
      mkdirSync(dataDir, { recursive: true });
    }
    DB_PATH = join(dataDir, 'crm.db');
    
    // 1. If we deployed the DB with the archive, copy it over!
    if (existsSync(LOCAL_DB_PATH) && fs.statSync(LOCAL_DB_PATH).size > 1000) {
       copyFileSync(LOCAL_DB_PATH, DB_PATH);
       console.log(`[database] Copied LOCAL_DB_PATH to Persistent Volume: ${DB_PATH}`);
    } 
    // 2. Otherwise, download it using native Node https
    else if (!existsSync(DB_PATH) || fs.statSync(DB_PATH).size < 1000) {
       console.log(`[database] Downloading backup natively...`);
       try {
         const file = fs.createWriteStream(DB_PATH);
         https.get("https://raw.githubusercontent.com/rakibnuist/eduexpress-crm/main/crm.db", (response) => {
            response.pipe(file);
            file.on('finish', () => file.close());
         });
       } catch (e) {
         console.error(`[database] Download failed:`, e.message);
       }
    }
  } else {
    DB_PATH = LOCAL_DB_PATH;
  }
}

const DB_DIR = dirname(DB_PATH);

// Override console logging to log to a persistent file for diagnostics
const LOG_PATH = join(DB_DIR, 'server.log');
function logToFile(msg) {
  try {
    const time = new Date().toISOString();
    appendFileSync(LOG_PATH, `[${time}] ${msg}\n`);
  } catch {}
}
import { appendFileSync } from 'fs';
const originalLog = console.log;
const originalError = console.error;
console.log = (...args) => {
  originalLog(...args);
  logToFile(args.map(a => typeof a === 'object' ? JSON.stringify(a) : a).join(' '));
};
console.error = (...args) => {
  originalError(...args);
  logToFile('[ERROR] ' + args.map(a => typeof a === 'object' ? JSON.stringify(a) : a).join(' '));
};

console.log('[startup] Port detected:', PORT, 'type:', typeof PORT);
console.log('[startup] Env keys:', Object.keys(process.env).join(', '));
const app = express();
app.set('trust proxy', 1); // Trust first proxy (e.g. Hostinger's reverse proxy)
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Rate limiting — prevent brute-force and abuse
const standardLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10000, // limit each IP to 10000 requests per windowMs (essential since entire office shares a single IP)
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please try again later.' },
});
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 500, // increased for office-wide deployments sharing one IP
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many login attempts, please try again later.' },
});
const uploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 200, 
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Upload quota exceeded, please try again later.' },
});
app.use(standardLimiter);
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/logout', authLimiter);
app.use('/api/upload', uploadLimiter);

const PERSISTENT_UPLOADS_DIR = join(PERSISTENT_HOME, 'uploads');
const LOCAL_UPLOADS_DIR = join(__dirname, 'uploads');
let UPLOADS_DIR;

if (process.platform === 'linux' && existsSync(PERSISTENT_HOME)) {
  UPLOADS_DIR = PERSISTENT_UPLOADS_DIR;
  if (!existsSync(PERSISTENT_UPLOADS_DIR)) {
    mkdirSync(PERSISTENT_UPLOADS_DIR, { recursive: true });
    // Migrate existing uploads if any
    if (existsSync(LOCAL_UPLOADS_DIR)) {
      try {
        const files = readdirSync(LOCAL_UPLOADS_DIR);
        files.forEach(file => {
          copyFileSync(join(LOCAL_UPLOADS_DIR, file), join(PERSISTENT_UPLOADS_DIR, file));
        });
        console.log(`[uploads] Auto-migrated ${files.length} uploads to persistent path.`);
      } catch (err) {
        console.error(`[uploads] Uploads migration failed:`, err.message);
      }
    }
  }
} else {
  UPLOADS_DIR = LOCAL_UPLOADS_DIR;
  if (!existsSync(UPLOADS_DIR)) {
    mkdirSync(UPLOADS_DIR, { recursive: true });
  }
}
app.use('/uploads', express.static(UPLOADS_DIR));

// ─── AUTH primitives ───────────────────────────────────────────────────────
// Get or create persistent stable JWT_SECRET if process.env.JWT_SECRET is not set
let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  const secretPath = join(DB_DIR, '.jwt_secret');
  try {
    if (!existsSync(DB_DIR)) {
      mkdirSync(DB_DIR, { recursive: true });
    }
    if (existsSync(secretPath)) {
      JWT_SECRET = readFileSync(secretPath, 'utf8').trim();
    } else {
      JWT_SECRET = 'edu-' + crypto.randomBytes(32).toString('hex');
      writeFileSync(secretPath, JWT_SECRET, 'utf8');
    }
  } catch (err) {
    console.warn('[startup] Failed to read/write persistent JWT secret, falling back to dynamic:', err.message);
    JWT_SECRET = 'dev-' + crypto.randomBytes(32).toString('hex');
  }
}
const AUTH_COOKIE = 'eduexpress_auth';
const SESSION_DAYS = 30;

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  const test = crypto.scryptSync(String(password), salt, 64).toString('hex');
  try { return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(test, 'hex')); }
  catch { return false; }
}
function signToken(payload) {
  const body = Buffer.from(JSON.stringify({ ...payload, exp: Math.floor(Date.now()/1000) + SESSION_DAYS*86400 })).toString('base64url');
  const sig  = crypto.createHmac('sha256', JWT_SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}
function verifyToken(token) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [body, sig] = token.split('.');
  const expected = crypto.createHmac('sha256', JWT_SECRET).update(body).digest('base64url');
  let a, b;
  try { a = Buffer.from(sig, 'base64url'); b = Buffer.from(expected, 'base64url'); } catch { return null; }
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (payload.exp && payload.exp < Date.now()/1000) return null;
    return payload;
  } catch { return null; }
}
function getCookie(req, name) {
  const c = req.headers.cookie || '';
  const m = c.match(new RegExp(`(?:^|; )${name}=([^;]*)`));
  return m ? decodeURIComponent(m[1]) : null;
}
function setAuthCookie(res, token) {
  const parts = [`${AUTH_COOKIE}=${encodeURIComponent(token)}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${SESSION_DAYS*86400}`];
  if (process.env.NODE_ENV === 'production') parts.push('Secure');
  res.setHeader('Set-Cookie', parts.join('; '));
}
function clearAuthCookie(res) {
  res.setHeader('Set-Cookie', `${AUTH_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
}

// Serve React build in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(join(__dirname, 'dist')));
}

// ── DB state — routes use `db` by reference ────────────────
let db = null;
let dbReady = false;

// Health check — always responds (lets Hostinger know we're alive)
app.get('/health', (_req, res) => {
  if (isDead()) return res.status(503).json({ status: 'restarting', reason: 'DB OOM — process is being recycled' });
  res.json({ status: dbReady ? 'ready' : 'starting' });
});

app.get('/diagnose-db', (req, res) => {
  try {
    const fs = require('fs');
    const size = existsSync(DB_PATH) ? fs.statSync(DB_PATH).size : 0;
    const integrity = db.prepare("PRAGMA integrity_check").get();
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(t => t.name);
    res.json({ db_path: DB_PATH, size, integrity, tables_count: tables.length, tables });
  } catch (err) {
    res.status(500).json({ error: err.message, stack: err.stack });
  }
});

// Block all API calls until DB is ready, and return 503 cleanly if the WASM
// instance died from OOM (the process is restarting itself in the background).
app.use((req, res, next) => {
  console.log('[request]', req.method, req.path);
  if (req.path.startsWith('/api')) {
    if (isDead()) {
      return res.status(503).json({ error: 'Server is restarting — please retry in a few seconds.' });
    }
    if (!dbReady) {
      return res.status(503).json({ error: 'Server is starting up, please retry in a few seconds.' });
    }
  }
  next();
});

// ─── AUTH ENDPOINTS (must precede the auth-required middleware) ─────────────
app.use('/api/auth', authRouter({
  getDb: () => db, verifyPassword, isFullAdmin, getConfig, haversineMeters, signToken, setAuthCookie, autoCheckIn, clearAuthCookie, verifyToken, getCookie, AUTH_COOKIE
}));

app.use('/api/users', usersRouter({
  getDb: () => db, requireAdmin, hashPassword, logActivity
}));
const LEAD_INSERT_SQL = `INSERT INTO leads (
  lead_id, date_added, client_name, phone, email, destination, last_education, gpa,
  english_score, program, lead_source, lead_status, assigned_consultant, assigned_employee_id,
  service_fee, paid, balance, payment_status, next_followup, notes,
  meta_lead_id, meta_form_id, meta_ad_id, meta_campaign,
  source, referrer, nationality, passport, degree, major, intake_term, university,
  drive_link, deposit, blood_group, date_of_birth, medical_notes, emergency_contact,
  application_stage
) VALUES (
  @lead_id, @date_added, @client_name, @phone, @email, @destination, @last_education, @gpa,
  @english_score, @program, @lead_source, @lead_status, @assigned_consultant, @assigned_employee_id,
  @service_fee, @paid, @balance, @payment_status, @next_followup, @notes,
  @meta_lead_id, @meta_form_id, @meta_ad_id, @meta_campaign,
  @source, @referrer, @nationality, @passport, @degree, @major, @intake_term, @university,
  @drive_link, @deposit, @blood_group, @date_of_birth, @medical_notes, @emergency_contact,
  @application_stage
)`;
const LEAD_UPDATE_SQL = `UPDATE leads SET
  client_name=@client_name, phone=@phone, email=@email, destination=@destination,
  last_education=@last_education, gpa=@gpa, english_score=@english_score, program=@program,
  lead_source=@lead_source, lead_status=@lead_status, assigned_consultant=@assigned_consultant, assigned_employee_id=@assigned_employee_id,
  service_fee=@service_fee, paid=@paid, balance=@balance, payment_status=@payment_status,
  next_followup=@next_followup, notes=@notes,
  source=@source, referrer=@referrer, nationality=@nationality, passport=@passport,
  degree=@degree, major=@major, intake_term=@intake_term, university=@university,
  drive_link=@drive_link, deposit=@deposit,
  blood_group=@blood_group, date_of_birth=@date_of_birth, medical_notes=@medical_notes,
  emergency_contact=@emergency_contact,
  application_stage=@application_stage
WHERE id=@id`;

app.use('/api/leads', leadsRouter({
  getDb: () => db, requireAdmin, requireManagerOrAdmin, userHasRole, isFullAdmin, canViewOwnLeadsOnly, isChinaBlockedForUser, leadIsVisibleTo, logActivity, sendCAPIEvent, uploadLimiter, getConfig, PERSISTENT_HOME, nextChinaLeadId, nextLeadId, leadParams, LEAD_INSERT_SQL, LEAD_UPDATE_SQL
}));

app.use('/api', messagingRouter({
  getDb: () => db, requireAdmin, requireManagerOrAdmin, userHasRole, isFullAdmin, canViewOwnLeadsOnly, isChinaBlockedForUser, leadIsVisibleTo, logActivity, sendCAPIEvent, uploadLimiter, getConfig, PERSISTENT_HOME, nextChinaLeadId, nextLeadId, leadParams, LEAD_INSERT_SQL, LEAD_UPDATE_SQL, haversineMeters, signToken, setAuthCookie, autoCheckIn, clearAuthCookie, verifyToken, getCookie, AUTH_COOKIE, hashPassword, requireMarketing
}));
app.get('/api/admin/logs', (req, res) => {
app.use('/api', activityRouter({ getDb: () => db, requireAdmin, requireManagerOrAdmin, userHasRole, canViewOwnLeadsOnly, isFullAdmin }));
app.use('/api', settingsRouter({ getDb: () => db, requireAdmin }));
  const apiKey = req.headers['x-api-key'] || req.query.key;
  const cookie = getCookie(req, AUTH_COOKIE);
app.use('/api', marketingRouter({
  getDb: () => db, requireAdmin, requireManagerOrAdmin, userHasRole, isFullAdmin, canViewOwnLeadsOnly, isChinaBlockedForUser, leadIsVisibleTo, logActivity, sendCAPIEvent, uploadLimiter, getConfig, PERSISTENT_HOME, nextChinaLeadId, nextLeadId, leadParams, LEAD_INSERT_SQL, LEAD_UPDATE_SQL, requireMarketing
}));
  let payload = null;
app.use('/api', financeRouter({
  getDb: () => db, requireAdmin, requireManagerOrAdmin, requireFinanceOrAdmin
}));
  try { payload = verifyToken(cookie); } catch {}
  const isAdmin = payload && payload.role === 'admin';
  if (apiKey !== 'eduexpress-n8n-2024' && !isAdmin) {
    return res.status(401).send('Unauthorized');
  }
  try {
    if (!existsSync(LOG_PATH)) return res.send('Log file is empty.');
    const content = readFileSync(LOG_PATH, 'utf8');
    const lines = content.split('\n').slice(-300).join('\n');
    res.setHeader('Content-Type', 'text/plain');
    res.send(lines);
  } catch (err) {
    res.status(500).send('Error reading log file: ' + err.message);
  }
});


// ─── REQUIRE AUTH on every /api/* below (except whitelisted paths) ──────────
const AUTH_FREE = ['/api/auth/login', '/api/auth/logout', '/api/auth/me', '/api/events', '/api/webhook/website-lead'];
const AUTH_FREE_PREFIX = ['/api/public/']; // student portal endpoints
// Internal API key for trusted services (n8n, automation scripts)
const INTERNAL_API_KEY = 'eduexpress-n8n-2024';

app.use((req, res, next) => {
  if (!req.path.startsWith('/api/')) return next();
  if (AUTH_FREE.includes(req.path)) return next();
  if (AUTH_FREE_PREFIX.some(p => req.path.startsWith(p))) return next();
  // Service-account bypass: trusted internal key (no location restriction)
  if (req.headers['x-api-key'] === INTERNAL_API_KEY) {
    req.user = { id: 0, role: 'super_admin', roles: ['founder_ceo'], name: 'n8n Bot', email: 'bot@eduexpress.internal' };
    return next();
  }
  const payload = verifyToken(getCookie(req, AUTH_COOKIE));
  if (!payload) return res.status(401).json({ error: 'Unauthorized' });
  // Ensure roles array is present (fallback for legacy tokens)
  if (!payload.roles || !Array.isArray(payload.roles)) {
    const roleMap = { admin: 'founder_ceo', manager: 'application_manager', consultant: 'consultant' };
    payload.roles = [roleMap[payload.role] || payload.role || 'consultant'];
  }
  req.user = payload;
  next();
});

// ─── RBAC Helpers ──────────────────────────────────────────────────────────
function userHasRole(user, role) {
  if (!user?.roles || !Array.isArray(user.roles)) return false;
  return user.roles.includes(role);
}
function userHasAnyRole(user, ...roles) {
  if (!user?.roles || !Array.isArray(user.roles)) return false;
  return roles.some(r => user.roles.includes(r));
}
function isFullAdmin(user) {
  if (!user) return false;
  if (user.role === 'admin') return true; // Legacy
  return userHasAnyRole(user, 'founder_ceo', 'managing_director');
}
function isInvestor(user) {
  return userHasRole(user, 'investor');
}
function canManageApplications(user) {
  return isFullAdmin(user) || userHasAnyRole(user, 'application_manager');
}
function canManageMarketing(user) {
  return isFullAdmin(user) || userHasAnyRole(user, 'marketing_manager');
}
function canViewReports(user) {
  return isFullAdmin(user) || isInvestor(user) || userHasAnyRole(user, 'application_manager', 'marketing_manager');
}
function canViewFinance(user) {
  return isFullAdmin(user) || isInvestor(user);
}
function canViewHR(user) {
  return isFullAdmin(user);
}
function canViewSettings(user) {
  return isFullAdmin(user);
}
function canViewAutomation(user) {
  return isFullAdmin(user) || userHasRole(user, 'marketing_manager');
}
function canViewAllLeads(user) {
  return isFullAdmin(user) || isInvestor(user) || userHasAnyRole(user, 'application_manager', 'marketing_manager');
}
function canViewOwnLeadsOnly(user) {
  return userHasRole(user, 'consultant') && !canViewAllLeads(user);
}
function canViewAllConversations(user) {
  // Full admins (Founder & CEO, Managing Director, legacy Admin) + any role with explicit all-conversations permission
  if (isFullAdmin(user)) return true;
  if (userHasAnyRole(user, 'application_manager', 'marketing_manager')) return true;
  // Future-proof: any role granted VIEW_ALL_CONVERSATIONS permission will have full inbox access
  return false;
}
function canViewOwnConversations(user) {
  return userHasRole(user, 'consultant');
}

function canViewChinaData(user) {
  return userHasAnyRole(user, 'founder_ceo', 'application_manager');
}

// Admin-only guard helper
function requireAdmin(req, res, next) {
  if (!isFullAdmin(req.user)) return res.status(403).json({ error: 'Admin only' });
  next();
}

// Finance access guard helper (Founder & CEO, Managing Director, and Investors)
function requireFinance(req, res, next) {
  if (!isFullAdmin(req.user) && !isInvestor(req.user)) {
    return res.status(403).json({ error: 'Finance access only' });
  }
  next();
}

// Manager-or-admin guard — Application Managers, Marketing Managers, and full admins
function requireManagerOrAdmin(req, res, next) {
  if (!isFullAdmin(req.user) && !userHasAnyRole(req.user, 'application_manager', 'marketing_manager')) {
    return res.status(403).json({ error: 'Manager or admin only' });
  }
  next();
}

// Application-manager guard
function requireApplicationManager(req, res, next) {
  if (!isFullAdmin(req.user) && !userHasRole(req.user, 'application_manager')) {
    return res.status(403).json({ error: 'Application manager only' });
  }
  next();
}

// Marketing-manager guard
function requireMarketingManager(req, res, next) {
  if (!isFullAdmin(req.user) && !userHasRole(req.user, 'marketing_manager')) {
    return res.status(403).json({ error: 'Marketing manager only' });
  }
  next();
}

// Check if a user has access to a specific conversation
function userHasAccessToConversation(user, conversationId) {
  if (!user) return false;
  if (isFullAdmin(user)) return true;
  if (canViewAllConversations(user)) return true; // App Manager, Marketing Manager
  // Consultant: own channels only for WhatsApp, all other channels
  if (canViewOwnConversations(user)) {
    let c;
    if (conversationId && typeof conversationId === 'object' && conversationId.channel_id !== undefined) {
      c = db.prepare(`
        SELECT channels.type AS channel_type, channels.name, channels.phone_number_id, channels.consultant, NULL AS assigned_to, channel_access.access_type
        FROM channels
        LEFT JOIN channel_access ON channel_access.channel_id = channels.id AND channel_access.user_id = @userId
        WHERE channels.id = @channelId
      `).get({ userId: user.id, channelId: conversationId.channel_id });
    } else {
      c = db.prepare(`
        SELECT channels.type AS channel_type, channels.name, channels.phone_number_id, channels.consultant, conversations.assigned_to, channel_access.access_type
        FROM conversations
        LEFT JOIN channels ON channels.id = conversations.channel_id
        LEFT JOIN channel_access ON channel_access.channel_id = conversations.channel_id AND channel_access.user_id = @userId
        WHERE conversations.id = @convId
      `).get({ userId: user.id, convId: conversationId });
    }
    if (!c) return false;
    // For WhatsApp: own account only (via channel consultant or assigned_to)
    if (c.channel_type === 'whatsapp') {
      const meUser = db.prepare("SELECT consultant_name, emp_id FROM users WHERE id=?").get(user.id);
      const matchConsultant = c.consultant && meUser?.consultant_name &&
        c.consultant.trim().toLowerCase() === meUser.consultant_name.trim().toLowerCase();
      
      let matchPhone = false;
      if (meUser && meUser.emp_id) {
        const employee = db.prepare("SELECT phone FROM employees WHERE emp_id=?").get(meUser.emp_id);
        if (employee && employee.phone) {
          const cleanEmp = String(employee.phone).replace(/\D/g, '');
          if (cleanEmp.length >= 6) {
            const cleanName = String(c.name || '').replace(/\D/g, '');
            const cleanPhoneId = String(c.phone_number_id || '').replace(/\D/g, '');
            matchPhone = (cleanName && (cleanName.endsWith(cleanEmp) || cleanEmp.endsWith(cleanName))) ||
                         (cleanPhoneId && (cleanPhoneId.endsWith(cleanEmp) || cleanEmp.endsWith(cleanPhoneId)));
          }
        }
      }

      return matchConsultant || c.assigned_to === user.id || c.access_type || matchPhone;
    }
    // All other channels: full access
    return true;
  }
  return false;
}

// Random URL-safe token for the student portal share link.
function generatePublicToken() {
  return crypto.randomBytes(9).toString('base64url'); // 12 char URL-safe
}

// ─── USER MANAGEMENT (admin only) ───────────────────────────────────────────

// ─── OFFICE CONFIG (open/close hours + geofence) ────────────────────────────
const OFFICE_KEYS = ['office_open_time', 'office_close_time', 'office_lat', 'office_lng', 'office_radius_m', 'office_wifi_ssid', 'office_allowed_ssids'];

// ─── APPLICATION PIPELINE ──────────────────────────────────────────────────
// Aligned with EduExpress workflow (File Updates 2026.xlsx).
// 8 stages from File Open → Arrived. Per-university tracker captures
// returned/rejected at each individual university.
function getApplicationStages() {
  const getList = (key, defaults) => {
    const val = getConfig(key);
    try { if (val) return JSON.parse(val); } catch {}
    return defaults;
  };
  const list = getList('settings_fileStages', [
    'Documents Collecting',
    'Documents Ready',
    'Applied to University',
    'Interview',
    'Pre-Admission',
    'Deposit',
    'Admission/JW Received',
    'Visa Applied',
    'Visa Approved',
    'Visa Rejected',
    'Enrolled',
    'Cancelled',
    'Withdraw'
  ]);
  return list.map((label, order) => {
    let key = label.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    if (key === 'documents_collecting') key = 'documents';
    if (key === 'documents_ready') key = 'ready';
    if (key === 'applied_to_university') key = 'submitted';
    if (key === 'admission_jw_received' || key === 'admission_notice_received') key = 'admitted';
    return { key, label, order };
  });
}

// Per-university application status values.
const UNI_APP_STATUSES = [
  'ready', 'submitted', 'pending', 'processing', 'initial_review_pass',
  'interview', 'pre_admission', 'admitted', 'returned', 'rejected'
];

// Default document checklists per destination. Used when an application opens.
// Each entry has a `required` array of doc types. Easy to edit later.
const DOC_TEMPLATES = {
  China:   ['Passport', 'SSC Certificate', 'HSC Certificate', 'SSC Marksheet', 'HSC Marksheet',
            'Passport-size Photo', 'NID/Birth Certificate', 'English Medium Certificate (MOI)',
            'CV', 'Statement of Purpose', 'Police Clearance', 'Medical Check-up', 'Bank Statement'],
  Malta:   ['Passport', 'SSC Certificate', 'HSC Certificate', 'Marksheets', 'IELTS Score',
            'Passport-size Photo', 'CV', 'Statement of Purpose', 'Bank Statement',
            'Accommodation Proof', 'Sponsorship Letter'],
  Hungary: ['Passport', 'SSC Certificate', 'HSC Certificate', 'Marksheets', 'IELTS Score',
            'Passport-size Photo', 'CV', 'Statement of Purpose', 'Recommendation Letters',
            'Bank Statement', 'Health Insurance'],
  Greece:  ['Passport', 'SSC Certificate', 'HSC Certificate', 'Marksheets', 'IELTS Score',
            'Passport-size Photo', 'CV', 'Statement of Purpose', 'Bank Statement'],
  Estonia: ['Passport', 'SSC Certificate', 'HSC Certificate', 'Marksheets', 'IELTS Score',
            'Passport-size Photo', 'CV', 'Statement of Purpose', 'Bank Statement',
            'Motivation Letter'],
};
const DEFAULT_DOCS = ['Passport', 'SSC Certificate', 'HSC Certificate', 'Marksheets',
                      'Passport-size Photo', 'CV', 'Statement of Purpose', 'Bank Statement'];

function templateFor(destination) {
  // Read from settings first, fall back to hardcoded defaults
  const fromSettings = getConfig('settings_docTemplates');
  if (fromSettings) {
    try {
      const parsed = JSON.parse(fromSettings);
      if (parsed[destination]) return parsed[destination];
    } catch {}
  }
  return DOC_TEMPLATES[destination] || DEFAULT_DOCS;
}

function leadIsVisibleTo(lead, user) {
  if (canViewAllLeads(user)) return true;
  const me = user?.consultant_name || user?.name || '';
  if (!me) return false;

  const meC = me.toLowerCase().trim();
  const meClean = meC.split(' ')[0];

  // 1. Check if user is the assigned consultant
  if (lead.assigned_consultant) {
    const leadC = lead.assigned_consultant.toLowerCase().trim();
    const nameMatch = leadC === meC || meClean === leadC || meC.includes(leadC) || leadC.includes(meClean);
    if (nameMatch) return true;
  }

  // 2. Check if user is the client/student themselves (by name)
  if (lead.client_name) {
    const clientC = lead.client_name.toLowerCase().trim();
    if (clientC === meC || meC.includes(clientC) || clientC.includes(meC)) return true;
  }

  // 3. Check if user is the client/student themselves (by email match)
  if (lead.email && user.email) {
    if (lead.email.toLowerCase().trim() === user.email.toLowerCase().trim()) return true;
  }

  // 4. Check employee_id match if both are linked
  if (lead.assigned_employee_id && user.emp_id) {
    const emp = db.prepare("SELECT emp_id FROM employees WHERE id=?").get(lead.assigned_employee_id);
    if (emp && emp.emp_id === user.emp_id) return true;
  }

  return false;
}
function leadIsChina(lead) {
  return lead?.destination === 'China' || lead?.source === 'China';
}
function isChinaBlockedForUser(lead, user) {
  if (!leadIsChina(lead)) return false;
  if (canViewChinaData(user)) return false;
  return !leadIsVisibleTo(lead, user);
}

// Reference: list of stages + doc templates (for the UI).
app.get('/api/application/meta', (req, res) => {
  const getList = (key, defaults) => {
    const val = getConfig(key);
    try { if (val) return JSON.parse(val); } catch {}
    return defaults;
  };
  const destinations = getList('settings_destinations', ['China', 'Malta', 'Hungary', 'Greece', 'Estonia', 'Georgia', 'Malaysia', 'Thailand']);
  const allSources = getList('settings_leadSources', ['In-House', 'B2B', 'China', 'Agent', 'Meta Lead Ad', 'WhatsApp', 'Referral']);
  // Source markets align with business model (China = collect FROM China; Bangladesh = collect FROM Bangladesh)
  const sourceMarkets = [
    { key: 'all', label: 'All Markets' },
    { key: 'china', label: 'China', restricted: true },
    { key: 'bangladesh', label: 'Bangladesh' }
  ];
  // Bangladesh channels
  const bdChannels = [
    { key: 'office', label: 'Office (In-House)', sourceMatch: ['In-House'] },
    { key: 'b2b', label: 'B2B / Agent', sourceMatch: ['B2B', 'Agent'] }
  ];
  res.json({ 
    stages: getApplicationStages(), 
    docTemplates: DOC_TEMPLATES, 
    defaultDocs: DEFAULT_DOCS,
    destinations,
    sourceMarkets,
    bdChannels,
    sources: allSources.map(s => ({ key: s, label: s }))
  });
});

// All leads currently in the application pipeline (i.e. that have a stage set,
// or are 'Enrolled'/'File Opened'). Returns one card-friendly row each.
// NEW: supports source_market (china|bangladesh|all), bd_channel (office|b2b|all),
// and destination (any configured destination). China data is isolated.
app.get('/api/applications', (req, res) => {
  const where = [
    "(l.application_stage IS NOT NULL OR l.lead_status IN ('Enrolled','File Opened'))",
  ];
  const params = {};
  if (canViewOwnLeadsOnly(req.user)) { // full admins + managers see all
    const meName = req.user.consultant_name || req.user.name || '';
    const meClean = meName.split(' ')[0];
    where.push("(TRIM(LOWER(l.assigned_consultant)) = TRIM(LOWER(@me)) OR TRIM(LOWER(l.assigned_consultant)) = TRIM(LOWER(@meClean)) OR TRIM(LOWER(@me)) LIKE '%' || TRIM(LOWER(l.assigned_consultant)) || '%' OR TRIM(LOWER(l.assigned_consultant)) LIKE '%' || TRIM(LOWER(@meClean)) || '%')");
    params.me = meName;
    params.meClean = meClean;
  }

  // ── Source Market filter (business model: China vs Bangladesh) ──
  const sourceMarket = req.query.source_market || 'all';
  
  // China data isolation: block unauthorized users from explicitly requesting China market
  if (sourceMarket === 'china' && !canViewChinaData(req.user)) {
    return res.status(403).json({ error: 'Access denied to China applications' });
  }
  
  if (sourceMarket === 'china') {
    // China market = leads whose source is 'China' (students collected FROM China)
    where.push("l.source = 'China'");
  } else if (sourceMarket === 'bangladesh') {
    // Bangladesh market = all leads whose source is NOT 'China'
    where.push("(l.source != 'China' OR l.source IS NULL OR l.source = '')");
  }
  
  // Bangladesh channel filter (only meaningful when source_market is bangladesh or all)
  const bdChannel = req.query.bd_channel || 'all';
  if (bdChannel === 'office') {
    where.push("(l.source = 'In-House' OR l.source IS NULL OR l.source = '')");
  } else if (bdChannel === 'b2b') {
    where.push("(l.source = 'B2B' OR l.source = 'Agent')");
  }
  
  // ── Destination filter (where the student GOES TO: Malaysia, Thailand, China, etc.) ──
  const destination = req.query.destination || 'all';
  if (destination !== 'all') {
    where.push("l.destination = @destination");
    params.destination = destination;
  }
  
  // Legacy: support old 'region' param for backward compatibility (maps to source_market)
  const region = req.query.region || 'all';
  if (region !== 'all' && sourceMarket === 'all') {
    // Old behavior: region matched either destination or source
    where.push("(LOWER(l.destination) = LOWER(@region) OR LOWER(l.source) = LOWER(@region))");
    params.region = region;
  }
  // Legacy: old 'destination' param (singular) also accepted
  const destinationParam = req.query.destination;
  if (destinationParam && destination === 'all') { 
    where.push("l.destination = @destination"); 
    params.destination = destinationParam; 
  }
  
  // China data isolation: exclude China leads for unauthorized users when viewing all or other markets
  if (!canViewChinaData(req.user) && sourceMarket !== 'china') {
    where.push("(l.source != 'China')");
  }
  
  // Source filtering (explicit source value)
  const source = req.query.source || 'all';
  if (source !== 'all') {
    where.push("l.source = @source");
    params.source = source;
  }
  
  if (req.query.consultant)  { where.push("l.assigned_consultant = @consultant"); params.consultant = req.query.consultant; }
  if (req.query.referrer)    { where.push("l.referrer = @referrer"); params.referrer = req.query.referrer; }
  const ws2 = 'WHERE ' + where.join(' AND ');

  const rows = db.prepare(`
    SELECT l.id, l.lead_id, l.client_name, l.phone, l.email, l.destination, l.university,
           l.lead_status, l.application_stage, l.visa_deadline, l.departure_date,
           l.intake_term, l.assigned_consultant, l.assigned_employee_id, l.service_fee, l.paid, l.balance,
           l.source, l.referrer, l.nationality, l.passport, l.degree, l.major,
           l.drive_link, l.deposit,
           e.name as employee_name, e.emp_id as employee_emp_id, e.role as employee_role,
           (SELECT COUNT(*) FROM lead_documents d WHERE d.lead_id=l.id) AS docs_total,
           (SELECT COUNT(*) FROM lead_documents d WHERE d.lead_id=l.id AND d.status IN ('received','verified')) AS docs_received,
           (SELECT COUNT(*) FROM lead_university_applications u WHERE u.lead_id=l.id) AS uni_total,
           (SELECT COUNT(*) FROM lead_university_applications u WHERE u.lead_id=l.id AND u.status='admitted') AS uni_admitted,
           (SELECT GROUP_CONCAT(university, ', ') FROM lead_university_applications u WHERE u.lead_id=l.id) AS uni_list
    FROM leads l
    LEFT JOIN employees e ON l.assigned_employee_id = e.id
    ${ws2}
    ORDER BY l.id DESC`).all(params);

  const stages = getApplicationStages();
  const defaultStageKey = stages[0]?.key || 'documents';
  // Sort rows dynamically in memory based on the order of stages from Settings list
  rows.sort((a, b) => {
    const stageA = a.application_stage || defaultStageKey;
    const stageB = b.application_stage || defaultStageKey;
    const orderA = stages.find(s => s.key === stageA)?.order ?? 0;
    const orderB = stages.find(s => s.key === stageB)?.order ?? 0;
    if (orderA !== orderB) return orderA - orderB;
    return b.id - a.id;
  });

  res.json({ stages, rows });
});

// Move a lead to a different application stage + edit Excel-aligned fields.

// ─── Per-university application tracker (mirrors NJTech/SUES/SXU columns) ──


app.put('/api/university-applications/:id', (req, res) => {
  const row = db.prepare("SELECT * FROM lead_university_applications WHERE id=?").get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found' });
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(row.lead_id);
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });
  const { university, program, status, application_id, submitted_on, decision_on, notes } = req.body || {};
  if (status && !UNI_APP_STATUSES.includes(status)) return res.status(400).json({ error: 'Bad status' });

  // Auto-stamp submitted_on/decision_on when the status flips into the right phase.
  const sOn = status === 'submitted' && !row.submitted_on ? (submitted_on || new Date().toISOString().slice(0,10)) : (submitted_on ?? row.submitted_on);
  const dOn = ['admitted','rejected','returned'].includes(status) && !row.decision_on ? (decision_on || new Date().toISOString().slice(0,10)) : (decision_on ?? row.decision_on);

  db.prepare(`UPDATE lead_university_applications SET
    university    = COALESCE(?, university),
    program       = COALESCE(?, program),
    status        = COALESCE(?, status),
    application_id= COALESCE(?, application_id),
    submitted_on  = ?,
    decision_on   = ?,
    notes         = COALESCE(?, notes),
    updated_by    = ?,
    updated_at    = datetime('now')
    WHERE id=?`).run(
      university ?? null, program ?? null, status ?? null, application_id ?? null,
      sOn, dOn, notes ?? null,
      req.user?.name || req.user?.email || null, req.params.id);
  const fresh = db.prepare("SELECT * FROM lead_university_applications WHERE id=?").get(req.params.id);

  // If this university just got admitted/rejected, log it for the owner feed.
  if (status && row.status !== status) {
    logActivity({ type: 'uni_app_status', actor: req.user, lead, from: row.status, to: status, details: { university: fresh.university } });
  }
  res.json(fresh);
});

app.delete('/api/university-applications/:id', (req, res) => {
  const row = db.prepare("SELECT * FROM lead_university_applications WHERE id=?").get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found' });
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(row.lead_id);
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });
  db.prepare("DELETE FROM lead_university_applications WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

// Documents for one lead — list + ensure-template helpers.


app.put('/api/documents/:id', (req, res) => {
  const doc = db.prepare("SELECT * FROM lead_documents WHERE id=?").get(req.params.id);
  if (!doc) return res.status(404).json({ error: 'Not found' });
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(doc.lead_id);
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });

  const { status, notes, file_url, received_on, requested_by_student } = req.body || {};
  const finalReceived = status && ['received', 'verified'].includes(status) && !doc.received_on
    ? (received_on || new Date().toISOString().slice(0, 10))
    : (received_on ?? doc.received_on);
  db.prepare(`UPDATE lead_documents SET status=COALESCE(?,status), notes=COALESCE(?,notes),
              file_url=COALESCE(?,file_url), received_on=?,
              requested_by_student=COALESCE(?,requested_by_student),
              updated_by=?, updated_at=datetime('now')
              WHERE id=?`)
    .run(status ?? null, notes ?? null, file_url ?? null, finalReceived,
         requested_by_student == null ? null : (requested_by_student ? 1 : 0),
         req.user?.name || req.user?.email || null, req.params.id);
  res.json(db.prepare("SELECT * FROM lead_documents WHERE id=?").get(req.params.id));
});

app.delete('/api/documents/:id', (req, res) => {
  const doc = db.prepare("SELECT * FROM lead_documents WHERE id=?").get(req.params.id);
  if (!doc) return res.status(404).json({ error: 'Not found' });
  const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(doc.lead_id);
  // China data isolation: block unauthorized access to China leads
  if (isChinaBlockedForUser(lead, req.user)) {
    return res.status(403).json({ error: 'Access denied to China lead records' });
  }
  if (!leadIsVisibleTo(lead, req.user)) return res.status(403).json({ error: 'Not your lead' });
  db.prepare("DELETE FROM lead_documents WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

// ─── OWNER'S COCKPIT ────────────────────────────────────────────────────────
// Build a daily summary block for a given YYYY-MM-DD date.
function buildDaySummary(date) {
  const activeEmployees = db.prepare("SELECT emp_id, name FROM employees WHERE active='Yes'").all();
  const attendance = db.prepare("SELECT emp_id, name, check_in, check_out, status, hours_worked, source FROM attendance WHERE date=?").all(date);
  const present = attendance.map(a => a.emp_id);
  const missing = activeEmployees.filter(e => !present.includes(e.emp_id));

  const newLeads     = db.prepare("SELECT COUNT(*) as n FROM leads WHERE date_added=? OR substr(created_at,1,10)=?").get(date, date).n;
  const conversions  = db.prepare("SELECT COUNT(*) as n FROM activity_log WHERE type='lead_status_changed' AND to_value='Enrolled' AND substr(created_at,1,10)=?").get(date).n;
  const paymentsRow  = db.prepare("SELECT COUNT(*) as n, COALESCE(SUM(amount),0) as s FROM income WHERE date=? AND (exclude_from_cash IS NULL OR exclude_from_cash = 0)").get(date);
  const expensesRow  = db.prepare("SELECT COUNT(*) as n, COALESCE(SUM(amount),0) as s FROM expenses WHERE date=?").get(date);

  return {
    date,
    attendance: { checkedIn: attendance, missing, totalActive: activeEmployees.length },
    stats: {
      newLeads,
      conversions,
      paymentsCount: paymentsRow.n,
      paymentsAmount: paymentsRow.s,
      expensesCount: expensesRow.n,
      expensesAmount: expensesRow.s,
      netCash: (paymentsRow.s || 0) - (expensesRow.s || 0),
    },
  };
}

// Find leads that need attention — what a remote owner cares about.
function buildAlerts() {
  const now = new Date();
  const today = now.toISOString().slice(0, 10);
  const fiveDaysAgo = new Date(now.getTime() - 5 * 86400000).toISOString().slice(0, 10);
  const thirtyDaysAhead = new Date(now.getTime() + 30 * 86400000).toISOString().slice(0, 10);

  // Open, not-terminal-status leads with no activity in the last 5 days
  const idleLeads = db.prepare(`
    SELECT l.id, l.lead_id, l.client_name, l.phone, l.destination, l.lead_status, l.assigned_consultant,
           COALESCE(l.date_added, substr(l.created_at,1,10)) as last_touch
    FROM leads l
    WHERE l.lead_status NOT IN ('Enrolled','Not Interested')
      AND COALESCE(l.date_added, substr(l.created_at,1,10)) <= ?
      AND NOT EXISTS (SELECT 1 FROM activity_log a WHERE a.lead_id = l.id AND a.created_at >= ?)
    ORDER BY last_touch ASC
    LIMIT 50`).all(fiveDaysAgo, fiveDaysAgo);

  // No consultant assigned
  const unassigned = db.prepare(`
    SELECT id, lead_id, client_name, phone, destination, lead_status, date_added
    FROM leads
    WHERE (assigned_consultant IS NULL OR assigned_consultant = '')
      AND lead_status NOT IN ('Enrolled','Not Interested')
    ORDER BY id DESC LIMIT 50`).all();

  // Follow-up date is past
  const overdueFollowups = db.prepare(`
    SELECT id, lead_id, client_name, phone, destination, lead_status, assigned_consultant, next_followup
    FROM leads
    WHERE next_followup IS NOT NULL AND next_followup != ''
      AND next_followup < ?
      AND lead_status NOT IN ('Enrolled','Not Interested')
    ORDER BY next_followup ASC LIMIT 50`).all(today);

  // Outstanding balance (paid less than fee, lead at later stages)
  const outstandingBalance = db.prepare(`
    SELECT id, lead_id, client_name, phone, destination, lead_status, assigned_consultant,
           service_fee, paid, balance
    FROM leads
    WHERE balance > 0 AND lead_status IN ('File Opened','Office Visited','Positive','Enrolled')
    ORDER BY balance DESC LIMIT 50`).all();

  // Visa deadlines within the next 30 days
  const visaDeadlines = db.prepare(`
    SELECT id, lead_id, client_name, destination, university, application_stage,
           assigned_consultant, visa_deadline
    FROM leads
    WHERE visa_deadline IS NOT NULL AND visa_deadline != ''
      AND visa_deadline <= ?
      AND (application_stage IS NULL OR application_stage NOT IN ('visa_approved','departed','arrived'))
    ORDER BY visa_deadline ASC LIMIT 50`).all(thirtyDaysAhead);

  return { idleLeads, unassigned, overdueFollowups, outstandingBalance, visaDeadlines };
}

app.get('/api/cockpit', (req, res) => requireManagerOrAdmin(req, res, () => {
  const todayStr = new Date().toISOString().slice(0, 10);
  const yStr = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const today = buildDaySummary(todayStr);
  const yesterday = buildDaySummary(yStr);
  const alerts = buildAlerts();

  const feed = db.prepare(`SELECT * FROM activity_log ORDER BY id DESC LIMIT 100`).all();

  // Weekly trend: new leads + revenue per day for the last 7 days
  const trend = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
    trend.push({
      date: d,
      newLeads: db.prepare("SELECT COUNT(*) as n FROM leads WHERE date_added=? OR substr(created_at,1,10)=?").get(d, d).n,
      revenue:  db.prepare("SELECT COALESCE(SUM(amount),0) as s FROM income WHERE date=? AND (exclude_from_cash IS NULL OR exclude_from_cash = 0)").get(d).s,
    });
  }

  res.json({ today, yesterday, alerts, feed, trend });
}));


// Start HTTP server IMMEDIATELY so Hostinger health check passes
app.listen(PORT, () => console.log(`🚀 CRM + Messaging API → http://localhost:${PORT}`));

// ── Init DB async in background ────────────────────────────
(async () => {
  try {
    console.log('[startup] Loading database...');
    db = await initDatabase(DB_PATH);
    db.pauseSave(); // Pause disk writes during schema check and migrations to prevent RSS memory spike OOM
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
    setupSchema();
    runMigrations();

    // Self-heal: verify every critical table actually exists. If any are missing
    // (e.g. after a crash/corruption), rebuild the schema before serving traffic.
    const REQUIRED = ['leads','channels','contacts','conversations','messages','quick_replies','users','payroll','activity_log','lead_documents','lead_university_applications','broadcasts','broadcast_dismissals','daily_logs','user_roles','channel_access'];
    let existing = db.tableNames ? db.tableNames() : [];
    let missing = REQUIRED.filter(t => !existing.includes(t));
    if (missing.length) {
      console.warn('[startup] ⚠️  Missing tables:', missing.join(', '), '— rebuilding schema');
      setupSchema();
      runMigrations();
      existing = db.tableNames ? db.tableNames() : [];
      missing = REQUIRED.filter(t => !existing.includes(t));
      if (missing.length) throw new Error(`Schema rebuild failed, still missing: ${missing.join(', ')}`);
    }

    db.resumeSave(); // Resume and perform a single batched save
    // seedData(); // disabled — production environment, no dummy data
    dbReady = true;
    console.log('[startup] Database ready ✅ — tables:', (db.tableNames ? db.tableNames().length : '?'));

    /*
    // Trigger historical sync on startup in background for all active channels sequentially
    setTimeout(async () => {
      try {
        const activeChannels = db.prepare("SELECT id, name, type FROM channels WHERE active = 1").all();
        for (const chan of activeChannels) {
          console.log(`[startup-sync] Syncing metadata for channel: ${chan.name} (ID: ${chan.id})`);
          try {
            await syncChannelMetadata(chan.id);
            if (chan.type === 'messenger' || chan.type === 'instagram') {
              console.log(`[startup-sync] Triggering sequential background sync (1 month) for channel: ${chan.name}`);
              const res = await syncChannelMessages(chan.id, 1);
              console.log(`[startup-sync] Completed background sync for ${chan.name}: Imported ${res.imported} messages.`);
            }
          } catch (e) {
            console.error(`[startup-sync] Background sync failed for ${chan.name}:`, e.message);
          }
          // Sleep 3 seconds between channels to allow the engine/GC to stabilize
          await new Promise(r => setTimeout(r, 3000));
        }
      } catch (err) {
        console.error('[startup-sync] Error checking active channels for startup sync:', err.message);
      }
    }, 10000); // delay 10s to not interfere with main startup requests
    */
  } catch (e) {
    console.error('[startup] DB init failed:', e.message);
    process.exit(1);
  }
})();

// Graceful shutdown — flush DB before exit
process.on('SIGTERM', () => { if (db) db.flush(); process.exit(0); });
process.on('SIGINT',  () => { if (db) db.flush(); process.exit(0); });

// ─────────────────────────────────────────────────────────
// SCHEMA / MIGRATIONS / SEED  (called after DB ready)
// ─────────────────────────────────────────────────────────
function setupSchema() { db.exec(`
  CREATE TABLE IF NOT EXISTS leads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id TEXT UNIQUE,
    date_added TEXT,
    client_name TEXT,
    phone TEXT,
    email TEXT,
    destination TEXT,
    last_education TEXT,
    gpa REAL,
    english_score TEXT,
    program TEXT,
    lead_source TEXT,
    lead_status TEXT DEFAULT 'New Lead',
    assigned_consultant TEXT,
    assigned_employee_id INTEGER,
    service_fee REAL DEFAULT 0,
    paid REAL DEFAULT 0,
    balance REAL DEFAULT 0,
    payment_status TEXT,
    next_followup TEXT,
    notes TEXT,
    meta_lead_id TEXT,
    meta_form_id TEXT,
    meta_ad_id TEXT,
    meta_campaign TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS income (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT, month TEXT, category TEXT, lead_id TEXT,
    client_name TEXT, reference TEXT, amount REAL DEFAULT 0, notes TEXT,
    employee_id INTEGER,
    exclude_from_cash INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT, month TEXT, category TEXT, paid_to TEXT,
    reference TEXT, amount REAL DEFAULT 0, notes TEXT,
    employee_id INTEGER
  );

  CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT, name TEXT, role TEXT, email TEXT, phone TEXT,
    device_id TEXT, salary REAL DEFAULT 0, active TEXT DEFAULT 'Yes',
    join_date TEXT
  );

  CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT, name TEXT, date TEXT,
    check_in TEXT, check_out TEXT, hours_worked REAL,
    status TEXT DEFAULT 'Present', device_id TEXT, ssid TEXT,
    source TEXT DEFAULT 'manual', notes TEXT
  );

  CREATE TABLE IF NOT EXISTS kpi_targets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    consultant TEXT NOT NULL, month TEXT NOT NULL,
    target_leads INTEGER DEFAULT 0,
    target_enrolled INTEGER DEFAULT 0,
    target_revenue REAL DEFAULT 0,
    UNIQUE(consultant, month)
  );

  CREATE TABLE IF NOT EXISTS meta_config (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT UNIQUE, value TEXT
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    name TEXT,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'consultant',
    consultant_name TEXT,
    active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now')),
    last_login TEXT
  );

  -- RBAC: Multi-role support (one employee can have 2-3 roles)
  CREATE TABLE IF NOT EXISTS user_roles (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    PRIMARY KEY (user_id, role)
  );
  CREATE INDEX IF NOT EXISTS idx_user_roles_user ON user_roles(user_id);

  -- RBAC: Channel access per user (many-to-many, for consultants)
  CREATE TABLE IF NOT EXISTS channel_access (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    access_type TEXT DEFAULT 'reply', -- reply | view_only | admin
    created_at TEXT DEFAULT (datetime('now')),
    UNIQUE(channel_id, user_id)
  );
  CREATE INDEX IF NOT EXISTS idx_channel_access_user ON channel_access(user_id);
  CREATE INDEX IF NOT EXISTS idx_channel_access_channel ON channel_access(channel_id);

  CREATE TABLE IF NOT EXISTS daily_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT NOT NULL,
    user_id INTEGER,
    date TEXT NOT NULL,
    accomplishments TEXT,
    challenges TEXT,
    tomorrow_plan TEXT,
    metrics_json TEXT,
    submitted_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    UNIQUE(emp_id, date)
  );
  CREATE INDEX IF NOT EXISTS idx_daily_logs_emp_date ON daily_logs(emp_id, date);

  CREATE TABLE IF NOT EXISTS broadcasts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message TEXT NOT NULL,
    author_id INTEGER,
    author_name TEXT,
    color TEXT DEFAULT 'amber',
    pinned INTEGER DEFAULT 1,
    expires_at TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS broadcast_dismissals (
    broadcast_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    dismissed_at TEXT DEFAULT (datetime('now')),
    PRIMARY KEY (broadcast_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS lead_university_applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    university TEXT NOT NULL,
    program TEXT,
    status TEXT NOT NULL DEFAULT 'documents', -- documents | ready | submitted | admitted | returned | rejected
    application_id TEXT,         -- university's reference / file number
    submitted_on TEXT,
    decision_on TEXT,
    notes TEXT,
    updated_by TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_uniapp_lead ON lead_university_applications(lead_id);

  CREATE TABLE IF NOT EXISTS lead_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    doc_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',  -- pending | received | verified | rejected | not_required
    notes TEXT,
    file_url TEXT,
    received_on TEXT,
    updated_by TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_docs_lead ON lead_documents(lead_id);

  CREATE TABLE IF NOT EXISTS activity_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    actor_user_id INTEGER,
    actor_name TEXT,
    lead_id INTEGER,
    lead_name TEXT,
    amount REAL,
    from_value TEXT,
    to_value TEXT,
    details TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_log(created_at);
  CREATE INDEX IF NOT EXISTS idx_activity_lead    ON activity_log(lead_id);
  CREATE INDEX IF NOT EXISTS idx_activity_actor   ON activity_log(actor_user_id);

  CREATE TABLE IF NOT EXISTS payroll (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    month TEXT NOT NULL,                  -- YYYY-MM
    emp_id TEXT NOT NULL,
    name TEXT,
    base_salary REAL DEFAULT 0,
    days_worked INTEGER DEFAULT 0,
    working_days INTEGER DEFAULT 0,
    bonus REAL DEFAULT 0,
    deductions REAL DEFAULT 0,
    net_pay REAL DEFAULT 0,
    paid_on TEXT,
    status TEXT DEFAULT 'pending',
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    UNIQUE(month, emp_id, name)
  );

  -- ── MESSAGING ──────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    name TEXT NOT NULL,
    phone_number_id TEXT,
    waba_id TEXT,
    page_id TEXT,
    ig_account_id TEXT,
    access_token TEXT,
    webhook_verify_token TEXT DEFAULT 'eduexpress_verify_2024',
    status TEXT DEFAULT 'active',
    color TEXT DEFAULT '#3b82f6',
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    phone TEXT,
    email TEXT,
    wa_id TEXT UNIQUE,
    messenger_id TEXT,
    instagram_id TEXT,
    tiktok_id TEXT,
    lead_id INTEGER REFERENCES leads(id) ON DELETE SET NULL,
    avatar_url TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_id INTEGER REFERENCES contacts(id),
    channel_id INTEGER REFERENCES channels(id),
    channel_type TEXT,
    status TEXT DEFAULT 'open',
    assigned_to TEXT,
    unread_count INTEGER DEFAULT 0,
    last_message TEXT,
    last_message_at TEXT,
    lead_id INTEGER REFERENCES leads(id) ON DELETE SET NULL,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER REFERENCES conversations(id) ON DELETE CASCADE,
    direction TEXT NOT NULL,
    type TEXT DEFAULT 'text',
    content TEXT,
    media_url TEXT,
    media_mime TEXT,
    caption TEXT,
    wa_message_id TEXT UNIQUE,
    status TEXT DEFAULT 'sent',
    sent_by TEXT,
    error_msg TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS quick_replies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    category TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_leads_status       ON leads(lead_status);
  CREATE INDEX IF NOT EXISTS idx_leads_consultant   ON leads(assigned_consultant);
  CREATE INDEX IF NOT EXISTS idx_attendance_emp     ON attendance(emp_id, date);
  CREATE INDEX IF NOT EXISTS idx_messages_conv      ON messages(conversation_id, created_at);
  CREATE INDEX IF NOT EXISTS idx_conv_contact       ON conversations(contact_id);
  CREATE INDEX IF NOT EXISTS idx_conv_status        ON conversations(status, last_message_at);

  -- ── MARKETING / SOCIAL AUTOMATION ──────────────────────
  CREATE TABLE IF NOT EXISTS content_posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    week TEXT,
    post_date TEXT,
    slot_time TEXT,
    page TEXT,                              -- china | bd | instagram | tiktok
    pillar TEXT,
    format TEXT,
    hook TEXT,
    body TEXT,
    hashtags TEXT,
    brief TEXT,
    asset_url TEXT,
    status TEXT DEFAULT 'drafted',          -- drafted|approved|edit|rejected|asset_ready|scheduled|published
    rejection_reason TEXT,
    published_url TEXT,
    reach INTEGER,
    engagement INTEGER,
    source TEXT DEFAULT 'n8n',              -- n8n | manual | evergreen
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_content_week ON content_posts(week, page);
  CREATE INDEX IF NOT EXISTS idx_content_status ON content_posts(status);

  CREATE TABLE IF NOT EXISTS evergreen_bank (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    page_pool TEXT, pillar TEXT, body TEXT, hashtags TEXT, asset_url TEXT,
    status TEXT DEFAULT 'approved',
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS competitor_intel (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    log_date TEXT, competitor TEXT, channel TEXT, observation TEXT,
    link TEXT, our_angle TEXT, added_by TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS kb_universities (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, country TEXT, city TEXT,
    programs TEXT, intakes TEXT, tuition TEXT, lang_req TEXT,
    admission_url TEXT, brochure_url TEXT, partner INTEGER DEFAULT 0,
    notes TEXT, last_verified TEXT
  );

  CREATE TABLE IF NOT EXISTS kb_scholarships (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, country TEXT, type TEXT,
    coverage TEXT, eligibility TEXT, deadline TEXT, source_url TEXT,
    status TEXT DEFAULT 'Open', last_verified TEXT, notes TEXT
  );

  CREATE TABLE IF NOT EXISTS kb_sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT, topic TEXT, url TEXT, source_type TEXT,
    use_for TEXT, date_added TEXT, notes TEXT
  );

  CREATE TABLE IF NOT EXISTS kb_docs (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, type TEXT, destination TEXT,
    drive_url TEXT, version TEXT, owner TEXT, updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS brain_api_pool (
    id INTEGER PRIMARY KEY AUTOINCREMENT, priority INTEGER, provider TEXT, model TEXT,
    cred_label TEXT, req_min INTEGER, req_day INTEGER,
    used_today INTEGER DEFAULT 0, status TEXT DEFAULT 'active',
    cooldown_until TEXT, notes TEXT
  );

  -- ── SOCIAL MEDIA ENGINE v2.0 ────────────────────────────
  CREATE TABLE IF NOT EXISTS research_intelligence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic TEXT NOT NULL,
    category TEXT CHECK(category IN ('competitor_move','market_gap','viral_signal','policy_change','psych_insight','offer_alert','trending_topic')),
    urgency TEXT CHECK(urgency IN ('critical','high','normal','low')),
    competitor TEXT,
    source_url TEXT,
    source_type TEXT CHECK(source_type IN ('meta_ad_library','fb_scrape','competitor_page','news','gov_notice','trend_platform','internal')),
    insight_summary TEXT,
    recommended_angle TEXT,
    evidence TEXT,
    status TEXT CHECK(status IN ('new','reviewed','used','archived')) DEFAULT 'new',
    used_in_post_id INTEGER,
    research_date TEXT DEFAULT (datetime('now')),
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_research_urgency ON research_intelligence(urgency, status);
  CREATE INDEX IF NOT EXISTS idx_research_competitor ON research_intelligence(competitor, research_date);

  CREATE TABLE IF NOT EXISTS viral_topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic TEXT NOT NULL,
    platform TEXT CHECK(platform IN ('facebook','instagram','tiktok','youtube','twitter')),
    hashtag TEXT,
    relevance_score INTEGER CHECK(relevance_score BETWEEN 0 AND 100),
    engagement_velocity REAL,
    reach_estimate INTEGER,
    sentiment TEXT CHECK(sentiment IN ('positive','neutral','negative','mixed')),
    why_viral TEXT,
    recommended_hook TEXT,
    recommended_cta TEXT,
    recommended_pillar TEXT,
    status TEXT CHECK(status IN ('new','approved','used','declined')) DEFAULT 'new',
    used_in_post_id INTEGER,
    discovered_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_viral_relevance ON viral_topics(relevance_score, status);

  CREATE TABLE IF NOT EXISTS psychology_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    segment TEXT NOT NULL,
    pain_points TEXT,
    aspirations TEXT,
    fears TEXT,
    trusted_sources TEXT,
    decision_factors TEXT,
    content_preferences TEXT,
    peak_hours TEXT,
    language_preference TEXT CHECK(language_preference IN ('bangla','english','banglish')),
    voice_tone TEXT CHECK(voice_tone IN ('empathetic_brother','expert_consultant','success_story','peer_friend')),
    primary_platform TEXT,
    secondary_platform TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS content_scripts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    script_name TEXT NOT NULL,
    category TEXT CHECK(category IN ('hook','video_script','carousel_copy','story','ad_copy','dm_script','reel_script','tiktok_script')),
    destination TEXT,
    pillar TEXT,
    format TEXT CHECK(format IN ('Reel','Carousel','Single image','Story','TikTok','Live')),
    hook TEXT,
    body TEXT,
    cta TEXT,
    duration_seconds INTEGER,
    shot_list TEXT,
    on_screen_text TEXT,
    psychology_target TEXT,
    avg_score REAL,
    usage_count INTEGER DEFAULT 0,
    status TEXT CHECK(status IN ('draft','approved','archived','winner')) DEFAULT 'draft',
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_scripts_status ON content_scripts(status, category);

  CREATE TABLE IF NOT EXISTS content_hooks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hook_text TEXT NOT NULL,
    hook_type TEXT CHECK(hook_type IN ('pain_point','curiosity','number','myth_bust','urgency','story','challenge','social_proof','fomo','trust')),
    destination TEXT,
    pillar TEXT,
    format TEXT,
    psychology_target TEXT,
    usage_count INTEGER DEFAULT 0,
    avg_reach INTEGER,
    avg_engagement INTEGER,
    conversion_rate REAL,
    status TEXT CHECK(status IN ('new','winner','tested','declined')) DEFAULT 'new',
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_hooks_status ON content_hooks(status, hook_type);

  CREATE TABLE IF NOT EXISTS ab_tests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    test_name TEXT NOT NULL,
    variable TEXT CHECK(variable IN ('hook','body','cta','image','time_slot','hashtag_set','platform')),
    variant_a TEXT,
    variant_b TEXT,
    variant_c TEXT,
    page TEXT CHECK(page IN ('china','bd','instagram','tiktok')),
    start_date TEXT,
    end_date TEXT,
    status TEXT CHECK(status IN ('planned','running','completed','cancelled')) DEFAULT 'planned',
    a_reach INTEGER, a_engagement INTEGER, a_leads INTEGER,
    b_reach INTEGER, b_engagement INTEGER, b_leads INTEGER,
    c_reach INTEGER, c_engagement INTEGER, c_leads INTEGER,
    winner TEXT CHECK(winner IN ('a','b','c','inconclusive')),
    winner_confidence INTEGER,
    insights TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS scale_up_recommendations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recommendation_type TEXT CHECK(recommendation_type IN ('content_pillar','platform','hook_style','time_slot','campaign','budget','destination','format','audience_segment')),
    title TEXT NOT NULL,
    description TEXT,
    expected_impact TEXT CHECK(expected_impact IN ('high','medium','low')),
    expected_lead_lift REAL,
    confidence_score INTEGER,
    based_on_data TEXT,
    action_items TEXT,
    status TEXT CHECK(status IN ('pending','approved','implemented','rejected','testing')) DEFAULT 'pending',
    approved_by TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS publishing_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER,
    page TEXT,
    platform TEXT,
    scheduled_at TEXT,
    published_at TEXT,
    status TEXT CHECK(status IN ('queued','published','failed','retry')) DEFAULT 'queued',
    error_message TEXT,
    platform_post_id TEXT,
    platform_post_url TEXT,
    reach INTEGER,
    engagement INTEGER,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_publishing_status ON publishing_queue(status, scheduled_at);

  CREATE TABLE IF NOT EXISTS creative_guidelines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guideline_name TEXT NOT NULL,
    category TEXT CHECK(category IN ('color','typography','imagery','tone','format_spec','brand_voice','asset_size','video_spec')),
    platform TEXT CHECK(platform IN ('facebook','instagram','tiktok','all')),
    specification TEXT,
    examples TEXT,
    do_s TEXT,
    dont_s TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  -- ═══════════════════════════════════════════════════════════
  --  PROFESSIONAL SMM PIPELINE v3.0 — Campaigns, Assets, Comments, Performance
  -- ═══════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS campaigns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    status TEXT CHECK(status IN ('draft','active','paused','completed','archived')) DEFAULT 'draft',
    page TEXT CHECK(page IN ('china','bd','instagram','tiktok','all')) DEFAULT 'china',
    pillar TEXT CHECK(pillar IN ('scholarship','trust','career','urgency','university','cost','success_story','trending','brand','festival')),
    start_date TEXT,
    end_date TEXT,
    budget TEXT,
    target_audience TEXT,
    goals TEXT,
    color TEXT DEFAULT '#3B82F6',
    created_by TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_campaigns_status ON campaigns(status, start_date);

  CREATE TABLE IF NOT EXISTS content_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    pillar TEXT CHECK(pillar IN ('scholarship','trust','career','urgency','university','cost','success_story','trending','brand','festival')),
    page TEXT CHECK(page IN ('china','bd','instagram','tiktok','all')) DEFAULT 'china',
    format TEXT CHECK(format IN ('Carousel','Reel','Single image','Story','Video','Live','Text')) DEFAULT 'Carousel',
    language TEXT CHECK(language IN ('bangla','english','mixed')) DEFAULT 'bangla',
    platform TEXT CHECK(platform IN ('facebook','instagram','tiktok')) DEFAULT 'facebook',
    tone TEXT CHECK(tone IN ('expert_consultant','empathetic_brother','success_story','peer_friend')) DEFAULT 'expert_consultant',
    hook_template TEXT,
    body_template TEXT,
    hashtags_template TEXT,
    cta_template TEXT,
    brief_template TEXT,
    variables TEXT, -- JSON: { "university_name": "string", "stipend_range": "string" }
    is_active INTEGER DEFAULT 1,
    usage_count INTEGER DEFAULT 0,
    created_by TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS content_calendar_slots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slot_date TEXT NOT NULL, -- YYYY-MM-DD
    slot_time TEXT, -- HH:MM
    page TEXT,
    pillar TEXT,
    post_id INTEGER,
    status TEXT CHECK(status IN ('empty','planned','writing','review','approved','scheduled','published','skipped')) DEFAULT 'empty',
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_calendar_slots_date ON content_calendar_slots(slot_date, page, status);
  CREATE INDEX IF NOT EXISTS idx_calendar_slots_post ON content_calendar_slots(post_id);

  CREATE TABLE IF NOT EXISTS publishing_schedule (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER NOT NULL,
    page TEXT,
    platform TEXT,
    scheduled_date TEXT,
    scheduled_time TEXT,
    timezone TEXT DEFAULT 'Asia/Dhaka',
    status TEXT CHECK(status IN ('pending','queued','published','failed','cancelled')) DEFAULT 'pending',
    published_at TEXT,
    platform_post_id TEXT,
    platform_post_url TEXT,
    error_message TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_publish_schedule ON publishing_schedule(status, scheduled_date, scheduled_time);

  CREATE TABLE IF NOT EXISTS best_time_slots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    page TEXT,
    platform TEXT,
    day_of_week INTEGER, -- 0=Sunday, 6=Saturday
    time_slot TEXT, -- HH:MM
    engagement_score REAL DEFAULT 0,
    based_on_posts INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    UNIQUE(page, platform, day_of_week, time_slot)
  );

  CREATE TABLE IF NOT EXISTS post_comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER NOT NULL,
    user_name TEXT,
    user_role TEXT,
    comment TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_post_comments_post ON post_comments(post_id);

  CREATE TABLE IF NOT EXISTS post_performance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER NOT NULL,
    platform TEXT,
    impressions INTEGER DEFAULT 0,
    reach INTEGER DEFAULT 0,
    engagement INTEGER DEFAULT 0,
    likes INTEGER DEFAULT 0,
    comments INTEGER DEFAULT 0,
    shares INTEGER DEFAULT 0,
    clicks INTEGER DEFAULT 0,
    cta_clicks INTEGER DEFAULT 0,
    video_views INTEGER DEFAULT 0,
    saves INTEGER DEFAULT 0,
    cost_per_result TEXT,
    recorded_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_post_perf_post ON post_performance(post_id);

  CREATE TABLE IF NOT EXISTS content_assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER,
    campaign_id INTEGER,
    asset_type TEXT CHECK(asset_type IN ('image','video','carousel','reel','story','thumbnail','raw')),
    asset_url TEXT,
    thumbnail_url TEXT,
    file_name TEXT,
    file_size TEXT,
    status TEXT CHECK(status IN ('pending','in_progress','review','approved','rejected','archived')) DEFAULT 'pending',
    uploaded_by TEXT,
    feedback TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_assets_post ON content_assets(post_id);

  CREATE TABLE IF NOT EXISTS content_briefs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id INTEGER,
    title TEXT NOT NULL,
    description TEXT,
    target_platforms TEXT,
    target_audience TEXT,
    key_messages TEXT,
    tone TEXT,
    reference_links TEXT,
    due_date TEXT,
    status TEXT CHECK(status IN ('pending','approved','in_progress','completed','cancelled')) DEFAULT 'pending',
    assigned_to TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS pipeline_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER,
    from_status TEXT,
    to_status TEXT,
    actor TEXT,
    note TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_pipeline_logs_post ON pipeline_logs(post_id);

  CREATE TABLE IF NOT EXISTS lead_attribution (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER,
    first_touch_at TEXT DEFAULT (datetime('now')),
    first_touch_source TEXT,
    first_touch_campaign TEXT,
    utm_source TEXT,
    utm_medium TEXT,
    utm_campaign TEXT,
    utm_content TEXT,
    utm_term TEXT,
    meta_campaign_id TEXT,
    meta_adset_id TEXT,
    meta_ad_id TEXT,
    meta_form_id TEXT,
    meta_is_organic INTEGER DEFAULT 0,
    content_post_id INTEGER,
    enrollment_value REAL,
    enrolled_at TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_attr_lead ON lead_attribution(lead_id);
  CREATE INDEX IF NOT EXISTS idx_attr_post ON lead_attribution(content_post_id);

  CREATE TABLE IF NOT EXISTS campaign_spend (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id TEXT,
    campaign_name TEXT,
    date TEXT,
    spend REAL,
    channel TEXT,
    platform TEXT,
    destination TEXT,
    impressions INTEGER,
    clicks INTEGER,
    leads INTEGER,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_campaign_spend_date ON campaign_spend(date, campaign_id);

  CREATE TABLE IF NOT EXISTS designer_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER,
    designer_id TEXT,
    brief TEXT,
    priority TEXT CHECK(priority IN ('urgent','normal','low')) DEFAULT 'normal',
    deadline TEXT,
    status TEXT CHECK(status IN ('assigned','in_progress','review','completed','rejected')) DEFAULT 'assigned',
    draft_asset_url TEXT,
    final_asset_url TEXT,
    feedback TEXT,
    assigned_at TEXT DEFAULT (datetime('now')),
    completed_at TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_designer_status ON designer_queue(status, designer_id);

  CREATE TABLE IF NOT EXISTS offer_sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    url TEXT,
    source_type TEXT CHECK(source_type IN ('government','university','competitor','internal','news','drive')),
    description TEXT,
    drive_folder_url TEXT,
    is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
  );


  -- ── AUTOMATION HUB ──────────────────────────────────────
  CREATE TABLE IF NOT EXISTS automation_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    trigger_type TEXT NOT NULL,
    trigger_config TEXT,
    action_type TEXT NOT NULL,
    action_config TEXT,
    priority INTEGER DEFAULT 0,
    active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS message_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT DEFAULT 'general',
    language TEXT DEFAULT 'en',
    content TEXT NOT NULL,
    variables TEXT,
    approved INTEGER DEFAULT 0,
    usage_count INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS contact_tags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    color TEXT DEFAULT '#3b82f6',
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS contact_tag_assignments (
    contact_id INTEGER NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
    tag_id INTEGER NOT NULL REFERENCES contact_tags(id) ON DELETE CASCADE,
    assigned_by TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    PRIMARY KEY (contact_id, tag_id)
  );

  CREATE TABLE IF NOT EXISTS conversation_notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    note TEXT NOT NULL,
    author_id INTEGER,
    author_name TEXT,
    is_internal INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS conversation_tags (
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    tag_id INTEGER NOT NULL REFERENCES contact_tags(id) ON DELETE CASCADE,
    PRIMARY KEY (conversation_id, tag_id)
  );

  CREATE TABLE IF NOT EXISTS broadcast_campaigns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    segment_type TEXT,
    segment_config TEXT,
    template_id INTEGER REFERENCES message_templates(id),
    content TEXT,
    status TEXT DEFAULT 'draft',
    scheduled_at TEXT,
    sent_count INTEGER DEFAULT 0,
    delivered_count INTEGER DEFAULT 0,
    failed_count INTEGER DEFAULT 0,
    created_by TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS broadcast_recipients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id INTEGER NOT NULL REFERENCES broadcast_campaigns(id) ON DELETE CASCADE,
    contact_id INTEGER NOT NULL REFERENCES contacts(id),
    status TEXT DEFAULT 'pending',
    sent_at TEXT,
    error TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS automation_analytics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_id INTEGER REFERENCES automation_rules(id),
    event_type TEXT NOT NULL,
    conversation_id INTEGER,
    details TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_automation_rules_active ON automation_rules(active, trigger_type);
  CREATE INDEX IF NOT EXISTS idx_conversation_notes_conv ON conversation_notes(conversation_id);
  CREATE INDEX IF NOT EXISTS idx_broadcast_recipients_campaign ON broadcast_recipients(campaign_id);
  CREATE INDEX IF NOT EXISTS idx_broadcast_recipients_contact ON broadcast_recipients(contact_id);
  CREATE INDEX IF NOT EXISTS idx_automation_analytics_rule ON automation_analytics(rule_id, created_at);
`); }

function runMigrations() {
  const migrations = [
    `ALTER TABLE attendance ADD COLUMN check_in TEXT`,
    `ALTER TABLE attendance ADD COLUMN check_out TEXT`,
    `ALTER TABLE attendance ADD COLUMN hours_worked REAL`,
    `ALTER TABLE attendance ADD COLUMN source TEXT DEFAULT 'manual'`,
    `ALTER TABLE attendance ADD COLUMN notes TEXT`,
    `ALTER TABLE employees  ADD COLUMN join_date TEXT`,
    `ALTER TABLE leads      ADD COLUMN meta_lead_id TEXT`,
    `ALTER TABLE leads      ADD COLUMN meta_form_id TEXT`,
    `ALTER TABLE leads      ADD COLUMN meta_ad_id TEXT`,
    `ALTER TABLE leads      ADD COLUMN meta_campaign TEXT`,
    `ALTER TABLE channels   ADD COLUMN active INTEGER DEFAULT 1`,
    `ALTER TABLE channels   ADD COLUMN consultant TEXT`,
    `ALTER TABLE channels   ADD COLUMN avatar_url TEXT`,
    `ALTER TABLE users      ADD COLUMN emp_id TEXT`,
    `ALTER TABLE leads      ADD COLUMN application_stage TEXT`,
    `ALTER TABLE leads      ADD COLUMN visa_deadline TEXT`,
    `ALTER TABLE leads      ADD COLUMN departure_date TEXT`,
    `ALTER TABLE leads      ADD COLUMN intake_term TEXT`,
    `ALTER TABLE leads      ADD COLUMN university TEXT`,
    `ALTER TABLE leads      ADD COLUMN application_notes TEXT`,
    // Excel-aligned fields (from File Updates 2026.xlsx)
    `ALTER TABLE leads      ADD COLUMN source TEXT`,
    `ALTER TABLE leads      ADD COLUMN referrer TEXT`,
    `ALTER TABLE leads      ADD COLUMN nationality TEXT`,
    `ALTER TABLE leads      ADD COLUMN passport TEXT`,
    `ALTER TABLE leads      ADD COLUMN degree TEXT`,
    `ALTER TABLE leads      ADD COLUMN major TEXT`,
    `ALTER TABLE leads      ADD COLUMN drive_link TEXT`,
    `ALTER TABLE leads      ADD COLUMN deposit REAL DEFAULT 0`,
    // Student portal + medical
    `ALTER TABLE leads      ADD COLUMN public_token TEXT`,
    `ALTER TABLE leads      ADD COLUMN public_enabled INTEGER DEFAULT 1`,
    `ALTER TABLE leads      ADD COLUMN blood_group TEXT`,
    `ALTER TABLE leads      ADD COLUMN date_of_birth TEXT`,
    `ALTER TABLE leads      ADD COLUMN medical_notes TEXT`,
    `ALTER TABLE leads      ADD COLUMN emergency_contact TEXT`,
    // Student-facing document requests
    `ALTER TABLE lead_documents ADD COLUMN requested_by_student INTEGER DEFAULT 0`,
    `ALTER TABLE lead_documents ADD COLUMN student_uploaded_url TEXT`,
    `ALTER TABLE lead_documents ADD COLUMN student_uploaded_at TEXT`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_leads_public_token ON leads(public_token)`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_messages_wa_id ON messages(wa_message_id)`,
    `ALTER TABLE income ADD COLUMN exclude_from_cash INTEGER DEFAULT 0`,
    `ALTER TABLE contacts ADD COLUMN tiktok_id TEXT`,
    `ALTER TABLE leads ADD COLUMN assigned_employee_id INTEGER`,
    `ALTER TABLE income ADD COLUMN employee_id INTEGER`,
    `ALTER TABLE expenses ADD COLUMN employee_id INTEGER`,
    // ── Social Media Engine v2.0 migrations ──
    `ALTER TABLE content_posts ADD COLUMN quality_score INTEGER`,
    `ALTER TABLE content_posts ADD COLUMN quality_checks TEXT`,
    `ALTER TABLE content_posts ADD COLUMN asset_type TEXT`,
    `ALTER TABLE content_posts ADD COLUMN asset_uploaded_by TEXT`,
    `ALTER TABLE content_posts ADD COLUMN asset_uploaded_at TEXT`,
    `ALTER TABLE content_posts ADD COLUMN utm_source TEXT`,
    `ALTER TABLE content_posts ADD COLUMN utm_medium TEXT`,
    `ALTER TABLE content_posts ADD COLUMN utm_campaign TEXT`,
    `ALTER TABLE content_posts ADD COLUMN utm_content TEXT`,
    `ALTER TABLE content_posts ADD COLUMN short_link TEXT`,
    `ALTER TABLE content_posts ADD COLUMN redraft_count INTEGER DEFAULT 0`,
    `ALTER TABLE content_posts ADD COLUMN research_intel_id INTEGER`,
    `ALTER TABLE content_posts ADD COLUMN shares INTEGER`,
    `ALTER TABLE content_posts ADD COLUMN comments INTEGER`,
    `ALTER TABLE content_posts ADD COLUMN saves INTEGER`,
    `ALTER TABLE content_posts ADD COLUMN video_views INTEGER`,
    `ALTER TABLE content_posts ADD COLUMN leads INTEGER`,
    `ALTER TABLE content_posts ADD COLUMN published_at TEXT`,
    `ALTER TABLE content_posts ADD COLUMN published_by TEXT`,
    `ALTER TABLE content_posts ADD COLUMN language TEXT DEFAULT 'bangla'`,
    // ── Publishing Queue migrations ──
    `ALTER TABLE publishing_queue ADD COLUMN page TEXT`,
    `ALTER TABLE publishing_queue ADD COLUMN platform_post_id TEXT`,
    `ALTER TABLE publishing_queue ADD COLUMN platform_post_url TEXT`,
    `ALTER TABLE publishing_queue ADD COLUMN error_message TEXT`,
    `ALTER TABLE publishing_queue ADD COLUMN reach INTEGER`,
    `ALTER TABLE publishing_queue ADD COLUMN engagement INTEGER`,
    `ALTER TABLE publishing_queue ADD COLUMN created_at TEXT`,
    `UPDATE publishing_queue SET created_at = datetime('now') WHERE created_at IS NULL`,
    // ── Professional SMM Pipeline v3.0 migrations ──
    `ALTER TABLE content_posts ADD COLUMN campaign_id INTEGER`,
    `ALTER TABLE content_posts ADD COLUMN assigned_to TEXT`,
    `ALTER TABLE content_posts ADD COLUMN reviewed_by TEXT`,
    `ALTER TABLE content_posts ADD COLUMN reviewed_at TEXT`,
    `ALTER TABLE content_posts ADD COLUMN rejection_reason TEXT`,
    `ALTER TABLE content_posts ADD COLUMN due_date TEXT`,
    `ALTER TABLE content_posts ADD COLUMN priority TEXT CHECK(priority IN ('low','normal','high','urgent')) DEFAULT 'normal'`,
    `ALTER TABLE content_posts ADD COLUMN notes TEXT`,
    `ALTER TABLE content_posts ADD COLUMN tags TEXT`,
    `ALTER TABLE conversations ADD COLUMN assigned_to_id INTEGER`,
    `DELETE FROM conversations WHERE id NOT IN (SELECT MAX(id) FROM conversations GROUP BY contact_id, channel_id)`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_conversations_contact_channel ON conversations(contact_id, channel_id)`,
  ];
  migrations.forEach(m => { try { db.exec(m); } catch {} });

  // ── RBAC Migration: create user_roles and channel_access tables, migrate old roles ──
  try {
    db.exec(`
      CREATE TABLE IF NOT EXISTS user_roles (
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        role TEXT NOT NULL,
        PRIMARY KEY (user_id, role)
      );
      CREATE INDEX IF NOT EXISTS idx_user_roles_user ON user_roles(user_id);

      CREATE TABLE IF NOT EXISTS channel_access (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        access_type TEXT DEFAULT 'reply',
        created_at TEXT DEFAULT (datetime('now')),
        UNIQUE(channel_id, user_id)
      );
      CREATE INDEX IF NOT EXISTS idx_channel_access_user ON channel_access(user_id);
      CREATE INDEX IF NOT EXISTS idx_channel_access_channel ON channel_access(channel_id);
    `);

    // Migrate legacy single-role users to user_roles junction table
    const legacyUsers = db.prepare(`SELECT id, role FROM users WHERE id NOT IN (SELECT user_id FROM user_roles)`).all();
    const roleMap = {
      admin: 'founder_ceo',
      manager: 'application_manager',
      consultant: 'consultant'
    };
    const insertRole = db.prepare(`INSERT OR IGNORE INTO user_roles (user_id, role) VALUES (?, ?)`);
    for (const u of legacyUsers) {
      const newRole = roleMap[u.role] || 'consultant';
      insertRole.run(u.id, newRole);
    }
    if (legacyUsers.length) {
      console.log(`[migration] Migrated ${legacyUsers.length} legacy users to user_roles table`);
    }
  } catch (e) {
    console.error('[migration] RBAC migration failed:', e.message);
  }

  // Custom migration for payroll UNIQUE constraint
  try {
    const sql = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='payroll'").get()?.sql || "";
    if (sql.includes("UNIQUE(month, emp_id)") && !sql.includes("UNIQUE(month, emp_id, name)")) {
      console.log("[migration] Updating payroll unique constraint to UNIQUE(month, emp_id, name)...");
      db.exec(`
        CREATE TABLE payroll_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          month TEXT NOT NULL,
          emp_id TEXT NOT NULL,
          name TEXT,
          base_salary REAL DEFAULT 0,
          days_worked INTEGER DEFAULT 0,
          working_days INTEGER DEFAULT 0,
          bonus REAL DEFAULT 0,
          deductions REAL DEFAULT 0,
          net_pay REAL DEFAULT 0,
          paid_on TEXT,
          status TEXT DEFAULT 'pending',
          notes TEXT,
          created_at TEXT DEFAULT (datetime('now')),
          UNIQUE(month, emp_id, name)
        );
        INSERT INTO payroll_new (id, month, emp_id, name, base_salary, days_worked, working_days, bonus, deductions, net_pay, paid_on, status, notes, created_at)
        SELECT id, month, emp_id, name, base_salary, days_worked, working_days, bonus, deductions, net_pay, paid_on, status, notes, created_at FROM payroll;
        DROP TABLE payroll;
        ALTER TABLE payroll_new RENAME TO payroll;
      `);
      console.log("[migration] Payroll unique constraint updated successfully!");
    }
  } catch (e) {
    console.error("[migration] Payroll update failed:", e.message);
  }

  // Dynamic self-healing migration to reset and force file stages config to the updated user pipeline
  try {
    const newStages = [
      'Documents Collecting',
      'Documents Ready',
      'Applied to University',
      'Interview',
      'Pre-Admission',
      'Deposit',
      'Admission/JW Received',
      'Visa Applied',
      'Visa Approved',
      'Visa Rejected',
      'Enrolled',
      'Cancelled',
      'Withdraw'
    ];
    db.prepare("INSERT OR REPLACE INTO meta_config (key, value) VALUES ('settings_fileStages', ?)").run(JSON.stringify(newStages));
    console.log("[migration] Updated settings_fileStages in database to user requested default flow.");

    // Migrate any existing legacy application stages in leads table to their closest new counterparts
    db.prepare("UPDATE leads SET application_stage = 'submitted' WHERE application_stage = 'in_review'").run();
    db.prepare("UPDATE leads SET application_stage = 'admitted' WHERE application_stage = 'jw202'").run();
    db.prepare("UPDATE leads SET application_stage = 'submitted' WHERE application_stage = 'rejected'").run();
    db.prepare("UPDATE leads SET application_stage = 'visa_approved' WHERE application_stage = 'payment_complete'").run();
    console.log("[migration] Successfully remapped legacy lead stages.");
  } catch (e) {
    console.error("[migration] settings_fileStages reset/remap failed:", e.message);
  }

  // Self-healing migration to rename legacy source names in existing leads
  try {
    db.prepare("UPDATE leads SET source = 'China' WHERE source = 'China Agent'").run();
    db.prepare("UPDATE leads SET source = 'B2B' WHERE source = 'Agent'").run();
    db.prepare("UPDATE leads SET source = 'In-House' WHERE source = 'In-house'").run();
    console.log("[migration] Migrated existing source names to China, B2B, and In-House.");
  } catch (e) {
    console.error("[migration] Remap source names failed:", e.message);
  }

  // Self-healing migration to seed pre-June 2026 partner investments
  try {
    // Delete duplicate cumulative entries if they exist
    db.prepare("DELETE FROM income WHERE notes LIKE 'Pre-June 2026 %'").run();

    db.prepare("UPDATE income SET client_name = 'Sakib Al Jubaer' WHERE category='Investment' AND client_name IN ('Sakib', 'Sakib Al Jubaer')").run();

    const investments = [
      { name: 'Abdullah Al Rakib', date: '2024-09-01', month: '2024-09', ref: 'Capital Injection 2024', val: 281800 },
      { name: 'Abdullah Al Rakib', date: '2025-09-01', month: '2025-09', ref: 'Capital Injection 2025', val: 387915 },
      { name: 'Sakib Al Jubaer',    date: '2025-09-01', month: '2025-09', ref: 'Capital Injection 2025', val: 37000 },
      { name: 'Tahmid Imam',        date: '2024-09-01', month: '2024-09', ref: 'Capital Injection 2024', val: 100100 },
      { name: 'Tahmid Imam',        date: '2025-09-01', month: '2025-09', ref: 'Capital Injection 2025', val: 70000 },
      { name: 'Tahmid Imam',        date: '2026-01-15', month: '2026-01', ref: 'Capital Injection 2026', val: 96521 }
    ];

    const check = db.prepare("SELECT COUNT(*) as c FROM income WHERE category='Investment' AND client_name=? AND reference=?");
    const insert = db.prepare(`INSERT INTO income (date, month, category, client_name, reference, amount, notes)
                               VALUES (?, ?, 'Investment', ?, ?, ?, 'Consolidated capital injection pre-data')`);
    
    investments.forEach(inv => {
      if (check.get(inv.name, inv.ref).c === 0) {
        insert.run(inv.date, inv.month, inv.name, inv.ref, inv.val);
        console.log(`[migration] Seeded investment for ${inv.name}: ${inv.val} BDT`);
      }
    });

    // Exclude prior investments from cash calculations (except Sakib's last 100k)
    db.prepare(`
      UPDATE income 
      SET exclude_from_cash = 1 
      WHERE category = 'Investment' 
        AND date < '2026-06-01'
        AND NOT (client_name = 'Sakib Al Jubaer' AND amount = 100000 AND date = '2026-05-15')
    `).run();

    // Ensure newer investments (June 2026 onwards) are included in cash calculations
    db.prepare(`
      UPDATE income 
      SET exclude_from_cash = 0 
      WHERE category = 'Investment' 
        AND date >= '2026-06-01'
    `).run();

    console.log("[migration] Partner investments self-healing checks complete.");
  } catch (e) {
    console.error("[migration] Seeding partner investments failed:", e.message);
  }

  // Self-healing migration to set the WhatsApp channel consultant to "Abdullah Al Rakib"
  try {
    const info = db.prepare("UPDATE channels SET consultant = 'Abdullah Al Rakib' WHERE type = 'whatsapp'").run();
    if (info.changes > 0) {
      console.log(`[migration] Updated ${info.changes} WhatsApp channels consultant to Abdullah Al Rakib.`);
    }
  } catch (e) {
    console.error("[migration] Failed to set WhatsApp channel consultant:", e.message);
  }

  // Self-healing migration to assign "Abdullah Al Rakib" to any existing unassigned WhatsApp leads
  try {
    const info = db.prepare(`
      UPDATE leads 
      SET assigned_consultant = 'Abdullah Al Rakib' 
      WHERE (assigned_consultant IS NULL OR assigned_consultant = '') 
        AND (lead_source = 'WhatsApp' OR id IN (
          SELECT DISTINCT lead_id FROM conversations WHERE channel_type = 'whatsapp' AND lead_id IS NOT NULL
        ))
    `).run();
    if (info.changes > 0) {
      console.log(`[migration] Updated ${info.changes} unassigned WhatsApp leads to consultant Abdullah Al Rakib.`);
    }
  } catch (e) {
    console.error("[migration] Failed to set WhatsApp leads consultant:", e.message);
  }

  // Self-healing migration to ensure all conversations have status set
  try {
    const info = db.prepare("UPDATE conversations SET status = 'open' WHERE status IS NULL OR status = ''").run();
    if (info.changes > 0) {
      console.log(`[migration] Self-healed ${info.changes} conversations with NULL/empty status to 'open'.`);
    }
  } catch (e) {
    console.error("[migration] Failed to self-heal conversations status:", e.message);
  }

  // Self-healing migration to automatically update all channels and meta_config to use the new valid System User token if empty
  try {
    const newToken = 'EAAVoF1AFCwoBR1ZAIqUN6mXMlFpaXhpzMgFlCP1KplZBNSY0FPagOD6iJBKeamBTvaCZAPo6YEw9YO1IZCT63BqzrtqBzZBSDGZCG4mtlPZAKQF4ZBmXGlowYXoSIzgZCB1j102Klcx4gMbOjeJwAUtroyJ9D95CnQ3C7j5tZA6OfItn22siqZAyzVXL1gI4KI7NoPstAZDZD';
    const oldToken = 'EAAVoF1AFCwoBRl9hbdnnxIUj5nFoaIEOj0doThSY3p159jABiZApMlSQTr4IguvIBNpyC1bsHewaq1jkr57Dkn349tyd458NpwGbZBhcw3NGv3d41TVj1VnLz5SKcNFNGHZBOL091vEIBJEQyH9DLyXz3JlSeVGxKGS9ZB4WWs0VwE3W9yfLGwQMr16BsBRGBgZDZD';
    
    // Update channels still using old or empty tokens
    const info = db.prepare("UPDATE channels SET access_token = ? WHERE access_token IS NULL OR access_token = '' OR access_token = ?").run(newToken, oldToken);
    
    // Always force update the global configs to the active token
    db.prepare("INSERT OR REPLACE INTO meta_config (key, value) VALUES ('page_access_token', ?)").run(newToken);
    db.prepare("INSERT OR REPLACE INTO meta_config (key, value) VALUES ('capi_token', ?)").run(newToken);
    
    if (info.changes > 0) {
      console.log(`[migration] Self-healed ${info.changes} channels with updated Global Access Token.`);
    }
  } catch (e) {
    console.error("[migration] Failed to apply new System User token:", e.message);
  }
  // Self-healing migration to assign lead L-00003 and others to Afsana Meme
  try {
    const afsanaEmp = db.prepare("SELECT id FROM employees WHERE name LIKE '%Afsana%'").get();
    if (afsanaEmp) {
      const info = db.prepare("UPDATE leads SET assigned_consultant = 'Afsana Meme', assigned_employee_id = ? WHERE lead_id = 'L-00003' OR client_name LIKE 'Sumi Iftin%'").run(afsanaEmp.id);
      if (info.changes > 0) {
        console.log(`[migration] Self-healed ${info.changes} leads and assigned them to Afsana Meme.`);
      }
    }
    // Self-heal users table mapping for Afsana Meme and Tahmid Imam
    db.prepare("UPDATE users SET emp_id = 'E-04', consultant_name = 'Afsana Meme' WHERE email LIKE '%afsana@eduexpressint.com%' OR name = 'Afsana'").run();
    db.prepare("UPDATE users SET emp_id = 'E-03' WHERE email LIKE '%tahmidrazi%' OR name LIKE '%Tahmid Imam%'").run();
    console.log(`[migration] Self-healed users table mappings for Afsana and Tahmid.`);
  } catch (e) {
    console.error("[migration] Failed to self-heal Afsana lead assignment:", e.message);
  }

    // Seed best time slots for Bangladesh market (EDT optimized)
    try {
      const bestTimeCheck = db.prepare("SELECT COUNT(*) as c FROM best_time_slots").get();
      if (bestTimeCheck.c === 0) {
        const defaultTimes = [
          // China page - Facebook - best engagement times (BD time)
          { page: 'china', platform: 'facebook', day: 0, time: '19:00', score: 85 },
          { page: 'china', platform: 'facebook', day: 0, time: '21:00', score: 78 },
          { page: 'china', platform: 'facebook', day: 1, time: '19:30', score: 82 },
          { page: 'china', platform: 'facebook', day: 1, time: '21:00', score: 75 },
          { page: 'china', platform: 'facebook', day: 2, time: '19:00', score: 88 },
          { page: 'china', platform: 'facebook', day: 2, time: '20:30', score: 80 },
          { page: 'china', platform: 'facebook', day: 3, time: '19:00', score: 86 },
          { page: 'china', platform: 'facebook', day: 3, time: '21:00', score: 79 },
          { page: 'china', platform: 'facebook', day: 4, time: '19:00', score: 90 },
          { page: 'china', platform: 'facebook', day: 4, time: '20:00', score: 84 },
          { page: 'china', platform: 'facebook', day: 5, time: '18:00', score: 92 },
          { page: 'china', platform: 'facebook', day: 5, time: '20:00', score: 88 },
          { page: 'china', platform: 'facebook', day: 6, time: '18:00', score: 89 },
          { page: 'china', platform: 'facebook', day: 6, time: '20:00', score: 85 },
          // BD page - Facebook
          { page: 'bd', platform: 'facebook', day: 0, time: '19:00', score: 87 },
          { page: 'bd', platform: 'facebook', day: 0, time: '21:00', score: 80 },
          { page: 'bd', platform: 'facebook', day: 1, time: '19:00', score: 85 },
          { page: 'bd', platform: 'facebook', day: 1, time: '20:30', score: 78 },
          { page: 'bd', platform: 'facebook', day: 2, time: '19:00', score: 89 },
          { page: 'bd', platform: 'facebook', day: 2, time: '21:00', score: 82 },
          { page: 'bd', platform: 'facebook', day: 3, time: '19:00', score: 86 },
          { page: 'bd', platform: 'facebook', day: 3, time: '20:30', score: 80 },
          { page: 'bd', platform: 'facebook', day: 4, time: '19:00', score: 91 },
          { page: 'bd', platform: 'facebook', day: 4, time: '20:00', score: 86 },
          { page: 'bd', platform: 'facebook', day: 5, time: '18:00', score: 93 },
          { page: 'bd', platform: 'facebook', day: 5, time: '20:00', score: 89 },
          { page: 'bd', platform: 'facebook', day: 6, time: '18:00', score: 90 },
          { page: 'bd', platform: 'facebook', day: 6, time: '20:00', score: 87 },
        ];
        const insertBestTime = db.prepare(`INSERT INTO best_time_slots (page, platform, day_of_week, time_slot, engagement_score) VALUES (?, ?, ?, ?, ?)`);
        for (const t of defaultTimes) {
          insertBestTime.run(t.page, t.platform, t.day, t.time, t.score);
        }
        console.log(`[migration] Seeded ${defaultTimes.length} best time slots for auto-scheduling.`);
      }
    } catch (e) {
      console.error('[migration] Best time seeding failed:', e.message);
    }

    // Seed default content templates
    try {
      const templateCheck = db.prepare("SELECT COUNT(*) as c FROM content_templates").get();
      if (templateCheck.c === 0) {
        const defaultTemplates = [
          {
            name: 'Scholarship Alert — China CSC',
            pillar: 'scholarship',
            page: 'china',
            format: 'Carousel',
            language: 'bangla',
            hook: 'CSC Scholarship 2026 — Full Ride! 🎓',
            body: 'Did you know? Chinese Government Scholarship (CSC) covers everything for Bangladesh students.\n\n✅ 100% Tuition Free\n✅ Monthly Stipend: ৳10,000-60,000\n✅ Free Accommodation\n✅ No IELTS (MOI Certificate)\n\nDeadline: {{deadline}}. Apply through EduExpress.',
            hashtags: '#CSCScholarship #StudyInChina #FullScholarship #EduExpressBD',
            cta: 'DM us for free consultation 📩',
            brief: 'Carousel with scholarship timeline, eligibility checklist, and EduExpress contact'
          },
          {
            name: 'Success Story — Visa Approved',
            pillar: 'success_story',
            page: 'china',
            format: 'Single image',
            language: 'mixed',
            hook: 'From Dhanmondi to Beijing! 🎓🇨🇳',
            body: 'Our student {{student_name}} just got their visa approved for {{university}}!\n\n✅ CSC Scholarship Winner\n✅ No CSCA Required\n✅ Started with zero preparation\n\n"I never thought I could study abroad. EduExpress made it possible."\n\nReady to be our next success story?',
            hashtags: '#SuccessStory #VisaApproved #EduExpressBD #StudyAbroad',
            cta: 'Apply Now — Limited Seats 🏃',
            brief: 'Single image with student photo (with permission), visa screenshot, university logo'
          },
          {
            name: 'Trust Builder — 8 Years of Excellence',
            pillar: 'trust',
            page: 'bd',
            format: 'Carousel',
            language: 'bangla',
            hook: '8 Years. 2,000+ Students. 98% Visa Success.',
            body: 'EduExpress International — Bangladesh\'s most trusted study abroad consultancy.\n\n📍 Dhanmondi, Dhaka\n✅ Payment After Visa Policy\n✅ 150+ Partner Universities\n✅ Dedicated Consultant Per Student\n\nWhy students choose us:\n→ Transparent process\n→ Real success stories\n→ Lifetime support\n\nYour dream university is one DM away.',
            hashtags: '#TrustedConsultancy #EduExpressBD #StudyAbroad #VisaSuccess',
            cta: 'Visit our Dhanmondi office 📍',
            brief: 'Carousel with team photos, office interior, student testimonials, partner university logos'
          },
          {
            name: 'Urgency — Intake Deadline Alert',
            pillar: 'urgency',
            page: 'china',
            format: 'Reel',
            language: 'bangla',
            hook: '⏰ Last 7 Days! September Intake Deadline',
            body: 'September 2026 intake applications closing soon!\n\n❌ Don\'t wait until last minute\n✅ Seats filling fast for top universities\n✅ Scholarship spots limited\n\nUniversities still accepting:\n→ {{university_1}}\n→ {{university_2}}\n→ {{university_3}}\n\nApply now or wait until 2027!',
            hashtags: '#DeadlineAlert #ApplyNow #SeptemberIntake #EduExpressBD',
            cta: 'WhatsApp: +8801983333566 📞',
            brief: 'Reel with countdown animation, university campus footage, deadline calendar'
          },
          {
            name: 'University Spotlight — Top Ranking',
            pillar: 'university',
            page: 'china',
            format: 'Carousel',
            language: 'english',
            hook: 'Top 500 Worldwide — {{university_name}} 🏫',
            body: 'Why choose {{university_name}}?\n\n🏆 QS Ranking: {{qs_rank}}\n📍 Location: {{city}}, China\n💰 Tuition: {{tuition}}\n🎓 Programs: {{programs}}\n📝 Entry: CSCA-Free for Bachelor\n\nCSC Scholarship available!\nMonthly stipend: ৳10,000-60,000\n\nApply through EduExpress for priority processing.',
            hashtags: '#TopUniversity #StudyInChina #EduExpressBD #Scholarship',
            cta: 'Click link in bio 🔗',
            brief: 'Carousel with university campus photos, ranking badge, program list, fee structure'
          }
        ];
        const insertTmpl = db.prepare(`INSERT INTO content_templates (name, description, pillar, page, format, language, platform, tone, hook_template, body_template, hashtags_template, cta_template, brief_template, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
        for (const t of defaultTemplates) {
          insertTmpl.run(t.name, '', t.pillar, t.page, t.format, t.language, 'facebook', 'expert_consultant', t.hook, t.body, t.hashtags, t.cta, t.brief, 'System');
        }
        console.log(`[migration] Seeded ${defaultTemplates.length} default content templates.`);
      }
    } catch (e) {
      console.error('[migration] Template seeding failed:', e.message);
    }

  // Seed pre-built data from external module (keeps server.js small)
  try {
    const seedData = require('./seed-data.cjs');

    // Seed templates
    const checkTmpl = db.prepare("SELECT COUNT(*) as c FROM message_templates");
    const insertTmpl = db.prepare(`INSERT OR IGNORE INTO message_templates (name, category, language, content, variables, approved, usage_count) VALUES (?, ?, ?, ?, ?, ?, 0)`);
    if (checkTmpl.get().c === 0) {
      for (const t of seedData.templates) {
        insertTmpl.run(t.name, t.category, t.language, t.content, t.variables, t.approved);
      }
      console.log(`[migration] Seeded ${seedData.templates.length} message templates.`);
    }

    // Seed tags
    const insertTag = db.prepare("INSERT OR IGNORE INTO contact_tags (name, color) VALUES (?, ?)");
    for (const t of seedData.tags) {
      insertTag.run(t.name, t.color);
    }
    console.log(`[migration] Seeded ${seedData.tags.length} contact tags.`);

    // Seed automation rules
    const checkRules = db.prepare("SELECT COUNT(*) as c FROM automation_rules");
    if (checkRules.get().c === 0) {
      const insertRule = db.prepare(`INSERT INTO automation_rules (name, trigger_type, trigger_config, action_type, action_config, priority, active, created_at) VALUES (?, ?, ?, ?, ?, ?, 1, datetime('now'))`);
      for (const r of seedData.defaultRules) {
        const tmpl = db.prepare("SELECT id FROM message_templates WHERE name=? LIMIT 1").get(r.action_template);
        insertRule.run(
          r.name,
          r.trigger_type,
          JSON.stringify(r.trigger_config),
          r.action_type,
          tmpl ? JSON.stringify({ template_id: tmpl.id }) : '{}',
          r.priority
        );
      }
      console.log(`[migration] Seeded ${seedData.defaultRules.length} automation rules.`);
    }
  } catch (e) {
    console.error('[migration] Seed data failed:', e.message);
  }  // ── Professional SMM Pipeline v3.0: Recreate content_posts with new status pipeline ──
  try {
    const sql = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='content_posts'").get()?.sql || "";
    // If the table still has the old CHECK constraint (with 'drafted' but not 'ideation'), recreate it
    if (sql.includes("drafted") && !sql.includes("ideation")) {
      console.log("[migration] Recreating content_posts table with new v3.0 pipeline statuses...");
      db.exec(`
        CREATE TABLE content_posts_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          week TEXT,
          page TEXT CHECK(page IN ('china','bd','instagram','tiktok')),
          pillar TEXT,
          format TEXT,
          hook TEXT,
          body TEXT,
          hashtags TEXT,
          cta TEXT,
          brief TEXT,
          post_date TEXT,
          post_time TEXT,
          asset_url TEXT,
          asset_type TEXT,
          asset_uploaded_by TEXT,
          asset_uploaded_at TEXT,
          status TEXT DEFAULT 'ideation',
          quality_score INTEGER,
          quality_checks TEXT,
          utm_source TEXT,
          utm_medium TEXT,
          utm_campaign TEXT,
          utm_content TEXT,
          short_link TEXT,
          redraft_count INTEGER DEFAULT 0,
          research_intel_id INTEGER,
          shares INTEGER,
          comments INTEGER,
          saves INTEGER,
          video_views INTEGER,
          leads INTEGER,
          published_at TEXT,
          published_by TEXT,
          language TEXT DEFAULT 'bangla',
          campaign_id INTEGER,
          assigned_to TEXT,
          reviewed_by TEXT,
          reviewed_at TEXT,
          rejection_reason TEXT,
          due_date TEXT,
          priority TEXT CHECK(priority IN ('low','normal','high','urgent')) DEFAULT 'normal',
          notes TEXT,
          tags TEXT,
          created_at TEXT DEFAULT (datetime('now')),
          updated_at TEXT DEFAULT (datetime('now'))
        );
        INSERT INTO content_posts_new SELECT * FROM content_posts;
        DROP TABLE content_posts;
        ALTER TABLE content_posts_new RENAME TO content_posts;
        CREATE INDEX IF NOT EXISTS idx_posts_status ON content_posts(status);
        CREATE INDEX IF NOT EXISTS idx_posts_page ON content_posts(page);
        CREATE INDEX IF NOT EXISTS idx_posts_campaign ON content_posts(campaign_id);
      `);
      // Map old statuses to new pipeline stages
      db.exec(`
        UPDATE content_posts SET status = CASE
          WHEN status = 'drafted' THEN 'writing'
          WHEN status = 'approved' THEN 'approved'
          WHEN status = 'scheduled' THEN 'scheduled'
          WHEN status = 'published' THEN 'published'
          WHEN status = 'asset_pending' THEN 'design'
          WHEN status = 'asset_ready' THEN 'design_review'
          ELSE 'ideation'
        END
      `);
      console.log("[migration] content_posts recreated with new pipeline stages.");
    }
  } catch (e) {
    console.error('[migration] content_posts recreation failed:', e.message);
  }

}


// ─────────────────────────────────────────────────────────
// SSE REAL-TIME BROADCAST
// ─────────────────────────────────────────────────────────
// Each SSE client = { res, user }. The user object lets us push only to admins,
// or only to the consultant who owns a specific lead.
const sseClients = new Map();
const longPollClients = new Set();



// Broadcast to every connected client. Optional `filter(user)` decides whether
// to send to a given client — used to scope notifications by role/consultant.
// IMPORTANT: We send `event: <type>` so browser EventSource named listeners fire.
function broadcast(type, data, filter = null) {
  const msg = `event: ${type}\ndata: ${JSON.stringify({ type, ...data })}\n\n`;
  sseClients.forEach((client, id) => {
    if (filter && !filter(client.user)) return;
    try {
      client.res.write(msg);
      if (typeof client.res.flush === 'function') client.res.flush();
    } catch {
      sseClients.delete(id);
    }
  });

  longPollClients.forEach(client => {
    if (filter && !filter(client.user)) return;
    try {
      client.send({ type, ...data });
    } catch {
      longPollClients.delete(client);
    }
  });
}

// Push a freshly-logged activity to the people who should see it.
// Admins see everything; consultants only see activities about their own leads.
function broadcastActivity(row) {
  if (!row) return;
  broadcast('activity', { activity: row }, (u) => {
    if (u?.role === 'admin') return true;
    if (!row.lead_id) return false;
    // Cheap consultant-scope check — does this user own this lead?
    const consultant = u?.consultant_name || u?.name;
    if (!consultant) return false;
    try {
      const lead = db.prepare("SELECT assigned_consultant FROM leads WHERE id=?").get(row.lead_id);
      return lead && lead.assigned_consultant === consultant;
    } catch { return false; }
  });
}

// ─────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────
function nextLeadId() {
  const row = db.prepare("SELECT lead_id FROM leads WHERE lead_id LIKE 'L-%' ORDER BY CAST(SUBSTR(lead_id,3) AS INTEGER) DESC LIMIT 1").get();
  return 'L-' + String(parseInt((row?.lead_id || 'L-00000').replace('L-', '')) + 1).padStart(5, '0');
}

function nextChinaLeadId() {
  const row = db.prepare("SELECT lead_id FROM leads WHERE lead_id LIKE 'C-%' ORDER BY CAST(SUBSTR(lead_id,3) AS INTEGER) DESC LIMIT 1").get();
  const nextNum = row ? parseInt(row.lead_id.replace('C-', '')) + 1 : 1;
  return 'C-' + String(nextNum).padStart(5, '0');
}

function getConfig(key) {
  return db.prepare("SELECT value FROM meta_config WHERE key=?").get(key)?.value || null;
}

/* Activity log — concise audit trail of the changes an owner actually cares
   about. Never throws (logging is best-effort), always returns synchronously.
   Types: lead_created, lead_status_changed, lead_assigned, lead_payment,
          payment_recorded, expense_recorded, user_created, attendance_in. */
function logActivity({ type, actor, lead, amount, from, to, details }) {
  try {
    const info = db.prepare(`INSERT INTO activity_log
        (type, actor_user_id, actor_name, lead_id, lead_name, amount, from_value, to_value, details)
        VALUES (?,?,?,?,?,?,?,?,?)`).run(
      type,
      actor?.id || null,
      actor?.name || actor?.email || 'System',
      lead?.id || null,
      lead?.client_name || lead?.lead_id || null,
      amount ?? null,
      from == null ? null : String(from),
      to   == null ? null : String(to),
      details ? (typeof details === 'string' ? details : JSON.stringify(details)) : null,
    );
    // Push to connected clients so the bell + Cockpit feed update instantly
    const row = db.prepare("SELECT * FROM activity_log WHERE id=?").get(info.lastInsertRowid);
    if (typeof broadcastActivity === 'function') broadcastActivity(row);
  } catch (e) { console.error('[activity]', e.message); }
}

function setConfig(key, value) {
  db.prepare(`INSERT INTO meta_config (key,value) VALUES (?,?)
              ON CONFLICT(key) DO UPDATE SET value=excluded.value`)
    .run(key, value == null ? null : String(value));
}

/* ─── Auto attendance helpers ─────────────────────────────────────────────
   - Find the employee record linked to a logged-in user (by emp_id or email)
   - Close any of their previous-day open check-ins to the configured close time
   - Auto check-in for today (optionally gated by a configured office geofence)
*/
function haversineMeters(lat1, lng1, lat2, lng2) {
  const R = 6371000;
  const toRad = (d) => d * Math.PI / 180;
  const dLat = toRad(lat2 - lat1), dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
function findEmployeeForUser(user) {
  if (!user) return null;
  // Match by email first (most precise, unique identifier)
  if (user.email) {
    const e = db.prepare("SELECT * FROM employees WHERE LOWER(email)=LOWER(?) AND active='Yes'").get(user.email);
    if (e) return e;
  }
  // If no email match, search by Employee ID and resolve duplicates by name
  if (user.emp_id) {
    const list = db.prepare("SELECT * FROM employees WHERE emp_id=? AND active='Yes'").all(user.emp_id);
    if (list.length === 1) return list[0];
    if (list.length > 1 && user.name) {
      const exact = list.find(e => 
        e.name.toLowerCase().includes(user.name.toLowerCase()) || 
        user.name.toLowerCase().includes(e.name.toLowerCase())
      );
      if (exact) return exact;
    }
    if (list.length > 0) return list[0];
  }
  return null;
}
function timeToHours(hhmm) {
  if (!hhmm || !/^\d{1,2}:\d{2}/.test(hhmm)) return null;
  const [h, m] = hhmm.split(':').map(Number);
  return h + m / 60;
}
function autoCloseStaleAttendance(emp, today) {
  const closeTime = getConfig('office_close_time') || '18:00';
  const stale = db.prepare("SELECT id, check_in, date FROM attendance WHERE emp_id=? AND check_out IS NULL AND date < ?").all(emp.emp_id, today);
  for (const s of stale) {
    const start = timeToHours(s.check_in) ?? 9.5;
    const end   = timeToHours(closeTime) ?? 18;
    const hours = Math.max(0, +(end - start).toFixed(2));
    db.prepare("UPDATE attendance SET check_out=?, hours_worked=?, source=COALESCE(source,'manual')||'+auto-close' WHERE id=?")
      .run(closeTime, hours, s.id);
  }
  return stale.length;
}
function autoCheckIn(user, opts = {}) {
  const emp = findEmployeeForUser(user);
  if (!emp) return { ok: false, reason: 'no_linked_employee' };

  const today = new Date().toISOString().slice(0, 10);
  autoCloseStaleAttendance(emp, today);

  // Office Wi-Fi SSID Verification (supports multi-SSID list)
  let _allowedSSIDs = [];
  try { _allowedSSIDs = JSON.parse(getConfig('office_allowed_ssids') || '[]'); } catch {}
  if (!Array.isArray(_allowedSSIDs) || _allowedSSIDs.length === 0) {
    const single = getConfig('office_wifi_ssid');
    if (single) _allowedSSIDs = [single];
  }
  const onOfficeWifi = opts.ssid && _allowedSSIDs.some(s =>
    String(s).toLowerCase().trim() === String(opts.ssid).toLowerCase().trim()
  );

  // Already checked in today?
  const existing = db.prepare("SELECT * FROM attendance WHERE emp_id=? AND date=?").get(emp.emp_id, today);
  
  if (existing) {
    if (onOfficeWifi && existing.source !== 'wifi') {
      db.prepare("UPDATE attendance SET source='wifi', ssid=? WHERE id=?").run(opts.ssid, existing.id);
    }
    return { ok: true, alreadyIn: true, id: existing.id };
  }

  // Geofence Check (bypass if they are verified on Office Wi-Fi)
  if (!onOfficeWifi) {
    const olat = parseFloat(getConfig('office_lat'));
    const olng = parseFloat(getConfig('office_lng'));
    const radius = parseInt(getConfig('office_radius_m')) || 200;
    if (Number.isFinite(olat) && Number.isFinite(olng)) {
      if (!Number.isFinite(opts.lat) || !Number.isFinite(opts.lng)) {
        return { ok: false, reason: 'no_location' };
      }
      const d = haversineMeters(olat, olng, opts.lat, opts.lng);
      if (d > radius) return { ok: false, reason: 'outside_office', distance: Math.round(d) };
    }
  }

  const now = new Date();
  const time = now.toTimeString().slice(0, 5);
  const openTime = timeToHours(getConfig('office_open_time') || '09:30');
  const lateAfter = openTime != null ? openTime + 0.25 : 9.75; // 15-min grace
  const status = timeToHours(time) > lateAfter ? 'Late' : 'Present';

  const source = onOfficeWifi ? 'wifi' : 'auto-login';
  const ssid = onOfficeWifi ? opts.ssid : '';

  const info = db.prepare("INSERT INTO attendance (emp_id, name, date, check_in, status, source, ssid) VALUES (?,?,?,?,?,?,?)")
    .run(emp.emp_id, emp.name, today, time, status, source, ssid);
    
  logActivity({ 
    type: 'attendance_in', 
    actor: { id: user.id, name: user.name || emp.name }, 
    to: time, 
    details: { emp_id: emp.emp_id, status, source, ssid } 
  });
  
  return { ok: true, created: info.lastInsertRowid, status, time, source, ssid };
}

function upsertContact({ name, phone, wa_id, messenger_id, instagram_id, tiktok_id, email, avatar_url }) {
  const existing = wa_id
    ? db.prepare("SELECT * FROM contacts WHERE wa_id=?").get(wa_id)
    : messenger_id
    ? db.prepare("SELECT * FROM contacts WHERE messenger_id=?").get(messenger_id)
    : instagram_id
    ? db.prepare("SELECT * FROM contacts WHERE instagram_id=?").get(instagram_id)
    : tiktok_id
    ? db.prepare("SELECT * FROM contacts WHERE tiktok_id=?").get(tiktok_id)
    : phone ? db.prepare("SELECT * FROM contacts WHERE phone=?").get(phone) : null;

  if (existing) {
    // Fill in a real name / avatar if we now have one and didn't before
    if (name && (!existing.name || existing.name === 'Unknown' || existing.name.endsWith(' User')))
      db.prepare("UPDATE contacts SET name=? WHERE id=?").run(name, existing.id);
    if (avatar_url && !existing.avatar_url)
      db.prepare("UPDATE contacts SET avatar_url=? WHERE id=?").run(avatar_url, existing.id);
    return existing;
  }
  const info = db.prepare(`INSERT INTO contacts (name,phone,email,wa_id,messenger_id,instagram_id,tiktok_id,avatar_url) VALUES (?,?,?,?,?,?,?,?)`)
    .run(name || 'Unknown', phone || null, email || null, wa_id || null, messenger_id || null, instagram_id || null, tiktok_id || null, avatar_url || null);
  return db.prepare("SELECT * FROM contacts WHERE id=?").get(info.lastInsertRowid);
}

function upsertConversation(contactId, channelId, channelType) {
  const existing = db.prepare("SELECT * FROM conversations WHERE contact_id=? AND channel_id=? AND status != 'resolved'").get(contactId, channelId);
  if (existing) {
    // If existing conversation is not assigned, but channel has a consultant, auto-assign it now
    if (!existing.assigned_to) {
      const chan = db.prepare("SELECT consultant FROM channels WHERE id=?").get(channelId);
      if (chan && chan.consultant) {
        const emp = db.prepare("SELECT id FROM employees WHERE LOWER(TRIM(name)) = LOWER(TRIM(?)) LIMIT 1").get(chan.consultant);
        try {
          db.prepare("UPDATE conversations SET assigned_to=?, assigned_to_id=? WHERE id=?").run(chan.consultant, emp ? emp.id : null, existing.id);
        } catch {
          try {
            db.prepare("UPDATE conversations SET assigned_to=? WHERE id=?").run(chan.consultant, existing.id);
          } catch (e) { console.error('Auto-assign update failed:', e.message); }
        }
        existing.assigned_to = chan.consultant;
        existing.assigned_to_id = emp ? emp.id : null;
      }
    }
    return existing;
  }
  
  // Look up channel's consultant
  const chan = db.prepare("SELECT consultant FROM channels WHERE id=?").get(channelId);
  let assigned_to = null;
  let assigned_to_id = null;
  if (chan && chan.consultant) {
    assigned_to = chan.consultant;
    const emp = db.prepare("SELECT id FROM employees WHERE LOWER(TRIM(name)) = LOWER(TRIM(?)) LIMIT 1").get(chan.consultant);
    if (emp) assigned_to_id = emp.id;
  }

  let info;
  try {
    info = db.prepare(`INSERT OR IGNORE INTO conversations (contact_id,channel_id,channel_type,status,assigned_to,assigned_to_id) VALUES (?,?,?, 'open', ?, ?)`)
      .run(contactId, channelId, channelType, assigned_to, assigned_to_id);
  } catch (err) {
    // Fallback: if assigned_to_id column is missing in production database
    try {
      info = db.prepare(`INSERT OR IGNORE INTO conversations (contact_id,channel_id,channel_type,status,assigned_to) VALUES (?,?,?, 'open', ?)`)
        .run(contactId, channelId, channelType, assigned_to);
    } catch (e2) {
      try {
        info = db.prepare(`INSERT OR IGNORE INTO conversations (contact_id,channel_id,channel_type,status) VALUES (?,?,?,'open')`)
          .run(contactId, channelId, channelType);
      } catch (e3) {}
    }
  }

  // If insert was ignored (meaning conversation already exists), fetch and return it
  if (!info || info.changes === 0) {
    return db.prepare("SELECT * FROM conversations WHERE contact_id=? AND channel_id=? AND status != 'resolved'").get(contactId, channelId);
  }
  return db.prepare("SELECT * FROM conversations WHERE id=?").get(info.lastInsertRowid);
}

function createLeadFromContact(contactId, source, initialMessage, creatorUser, options = {}) {
  try {
    const contact = db.prepare("SELECT * FROM contacts WHERE id=?").get(contactId);
    if (!contact || contact.lead_id) return null;

    const lead_id = nextLeadId();
    const sourceMap = {
      whatsapp: 'WhatsApp Inquiry',
      messenger: 'Messenger Inquiry',
      instagram: 'Instagram Inquiry',
      tiktok: 'TikTok Inquiry'
    };
    const client_name = options.client_name || contact.name || sourceMap[source] || 'Chat Inquiry';
    const phone = options.phone || contact.phone || null;
    const email = contact.email || null;
    const destination = options.destination || 'Bangladesh';
    const degree = options.degree || null;

    // Find the channel consultant or assign to the converting consultant user
    let assigned_consultant = null;
    let assigned_employee_id = null;

    if (creatorUser && creatorUser.roles?.includes('consultant')) {
      assigned_consultant = creatorUser.consultant_name || creatorUser.name;
      const emp = db.prepare("SELECT id FROM employees WHERE emp_id=?").get(creatorUser.emp_id);
      if (emp) assigned_employee_id = emp.id;
    } else {
      const lastConv = db.prepare("SELECT channel_id FROM conversations WHERE contact_id=? ORDER BY id DESC LIMIT 1").get(contactId);
      if (lastConv) {
        const chan = db.prepare("SELECT consultant FROM channels WHERE id=?").get(lastConv.channel_id);
        if (chan) {
          assigned_consultant = chan.consultant;
          const emp = db.prepare("SELECT id FROM employees WHERE LOWER(TRIM(name)) = LOWER(TRIM(?))").get(chan.consultant);
          if (emp) assigned_employee_id = emp.id;
        }
      }
    }

    const leadSourceMap = {
      whatsapp: 'WhatsApp',
      messenger: 'Messenger',
      instagram: 'Instagram',
      tiktok: 'TikTok'
    };

    const params = leadParams({
      client_name,
      phone,
      email,
      destination,
      degree,
      source: 'In-House',
      lead_source: leadSourceMap[source] || 'Chat',
      lead_status: 'New Lead',
      assigned_consultant,
      assigned_employee_id,
      notes: initialMessage ? `Initial Inquiry: "${initialMessage}"` : `Auto-created from ${source} chat integration.`
    }, lead_id, 0);

    const info = db.prepare(LEAD_INSERT_SQL).run(params);
    const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(info.lastInsertRowid);

    if (lead) {
      db.prepare("UPDATE contacts SET lead_id=? WHERE id=?").run(lead.id, contact.id);
      db.prepare("UPDATE conversations SET lead_id=? WHERE contact_id=?").run(lead.id, contact.id);
      
      logActivity({
        type: 'lead_created',
        actor: { name: 'Meta Automation' },
        lead,
        details: { source: lead.lead_source, note: 'Automatically created from chat integration' }
      });

      broadcast('new_lead', { lead });
      console.log(`✅ Auto-created Lead from ${source}: ${lead_id} — ${client_name}`);
      return lead;
    }
  } catch(e) {
    console.error('Error auto-creating lead from contact:', e.message);
  }
  return null;
}

function createLeadFromReferral({ contact, channel, referralData, sourcePlatform }) {
  try {
    if (contact.lead_id) return null; // Lead already exists

    const adId = referralData.ad_id || referralData.source_id;
    const campaignId = referralData.campaign_id || referralData.campaign_name;
    const adTitle = referralData.ad_title || referralData.headline || '';
    const bodyText = referralData.body || '';

    const lead_id = nextLeadId();
    let assigned_consultant = channel.consultant || null;
    let destination = 'Bangladesh';
    let source = 'In-House';

    // Routing rules
    const textToCheck = (adTitle + ' ' + bodyText).toLowerCase();
    if (textToCheck.includes('china') || textToCheck.includes('chinese') || textToCheck.includes('中国')) {
      destination = 'China';
      source = 'China';
      assigned_consultant = 'Abdullah Al Rakib';
    } else if (textToCheck.includes('b2b') || textToCheck.includes('agent')) {
      destination = 'Bangladesh';
      source = 'B2B';
      assigned_consultant = 'Tahmid Imam';
    } else if (textToCheck.includes('bangladesh') || textToCheck.includes('bd') || textToCheck.includes('office')) {
      destination = 'Bangladesh';
      source = 'In-House';
      assigned_consultant = 'Taj Ahmed';
    }

    const platformSourceMap = {
      whatsapp: 'WhatsApp Ad',
      messenger: 'Facebook Ad',
      instagram: 'Instagram Ad'
    };

    const noteText = adTitle 
      ? `Click-to-${sourcePlatform} Referral Ad: "${adTitle}" ${bodyText ? '- ' + bodyText : ''}`
      : `Auto-created from Click-to-${sourcePlatform} ad.`;

    const params = leadParams({
      client_name: contact.name || 'Chat Lead',
      phone: contact.phone || null,
      email: contact.email || null,
      destination,
      source,
      lead_source: platformSourceMap[sourcePlatform] || 'Facebook Ad',
      lead_status: 'New Lead',
      assigned_consultant,
      meta_ad_id: adId || null,
      meta_campaign: campaignId || null,
      notes: noteText
    }, lead_id, 0);

    const info = db.prepare(LEAD_INSERT_SQL).run(params);
    const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(info.lastInsertRowid);
    if (lead) {
      db.prepare("UPDATE contacts SET lead_id=? WHERE id=?").run(lead.id, contact.id);
      db.prepare("UPDATE conversations SET lead_id=? WHERE contact_id=?").run(lead.id, contact.id);
      
      broadcast('new_lead', { lead });
      logActivity({
        type: 'lead_created',
        actor: { name: 'Meta Ad Automation' },
        lead,
        details: { client_name: contact.name, source: platformSourceMap[sourcePlatform] || 'Facebook Ad' }
      });
      return lead;
    }
  } catch (err) {
    console.error('[referral-lead] Failed to create lead from referral:', err.message);
  }
  return null;
}



// ── n8n AI Welcome Bot Integration ───────────────────────────────────────────
// New messages are forwarded to n8n where Gemini generates a personalised reply.
const N8N_WELCOME_WEBHOOK = 'https://vibeacademy.cloud/webhook/eduexpress-welcome';

function forwardToN8N(data) {
  fetch(N8N_WELCOME_WEBHOOK, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).catch(e => console.log('[n8n] forward warn:', e.message));
  console.log(`[n8n] forwarded ${data.platform} conv:${data.conversationId} → AI welcome`);
}
// ─────────────────────────────────────────────────────────────────────────────

function saveInboundMessage(convId, content, type = 'text', waMessageId = null, mediaUrl = null, caption = null) {
  try {
    const info = db.prepare(`INSERT INTO messages (conversation_id,direction,type,content,wa_message_id,media_url,caption,status)
      VALUES (?,?,?,?,?,?,?,'delivered')`).run(convId, 'in', type, content, waMessageId, mediaUrl, caption);
    const msg = db.prepare("SELECT * FROM messages WHERE id=?").get(info.lastInsertRowid);
    db.prepare("UPDATE conversations SET last_message=?, last_message_at=datetime('now'), unread_count=unread_count+1 WHERE id=?").run(content || `[${type}]`, convId);
    const conv = db.prepare("SELECT conversations.*, contacts.name as contact_name, contacts.phone as contact_phone, channels.name as channel_name, channels.type as channel_type FROM conversations LEFT JOIN contacts ON contacts.id=conversations.contact_id LEFT JOIN channels ON channels.id=conversations.channel_id WHERE conversations.id=?").get(convId);
    broadcast('new_message', {
      ...msg,
      conversation_id: convId,
      direction: 'inbound',
      contact_name: conv?.contact_name,
      channel_type: conv?.channel_type,
    }, (u) => userHasAccessToConversation(u, convId));

    // Evaluate automation rules in background
    if (conv) {
      setImmediate(() => evaluateAutomationRules('keyword', conv, msg).catch(() => {}));
      const inCount = db.prepare("SELECT COUNT(*) as n FROM messages WHERE conversation_id=? AND direction='in'").get(convId).n;
      if (inCount === 1) {
        setImmediate(() => evaluateAutomationRules('new_conversation', conv, msg).catch(() => {}));
        // Send CAPI Contact event for new conversation
        sendCAPIEvent('Contact', {
          lead_id: `CONV-${conv.id}`,
          phone: conv?.contact_phone || undefined,
          event_source_url: undefined,
        }).catch(() => {});
      }
    }

    return msg;
  } catch (e) {
    if (!e.message.includes('UNIQUE')) console.error('saveInboundMessage:', e.message);
    return null;
  }
}

async function sendWhatsApp(channel, to, text, type = 'text', mediaUrl = null) {
  const cleanTo = to.replace(/\D/g, '');
  const url = `https://graph.facebook.com/v19.0/${channel.phone_number_id}/messages`;
  let bodyObj = { messaging_product: 'whatsapp', to: cleanTo };
  if (type === 'image' && mediaUrl) {
    bodyObj.type = 'image';
    bodyObj.image = { link: mediaUrl, caption: text || undefined };
  } else if (type === 'document' && mediaUrl) {
    bodyObj.type = 'document';
    bodyObj.document = { link: mediaUrl, filename: text || 'Document' };
  } else {
    bodyObj.type = 'text';
    bodyObj.text = { body: text };
  }
  const token = channel.access_token || getConfig('page_access_token');
  if (!token) {
    console.error('[sendWhatsApp] No access token for channel', channel.name || channel.id);
    return { error: { message: 'No access token configured' } };
  }
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(bodyObj)
  });
  return res.json();
}

async function sendMessenger(channel, recipientId, text, type = 'text', mediaUrl = null) {
  const url = `https://graph.facebook.com/v19.0/${channel.page_id}/messages`;
  let bodyObj = { recipient: { id: recipientId } };
  if (mediaUrl && (type === 'image' || type === 'document')) {
    bodyObj.message = {
      attachment: {
        type: type === 'image' ? 'image' : 'file',
        payload: { url: mediaUrl, is_reusable: true }
      }
    };
  } else {
    bodyObj.message = { text };
    bodyObj.messaging_type = 'RESPONSE';
  }
  let token = channel.access_token || getConfig('page_access_token');
  if (!token) {
    console.error('[sendMessenger] No access token for channel', channel.name || channel.id);
    return { error: { message: 'No access token configured' } };
  }
  token = await resolvePageAccessToken(channel.page_id, token);
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(bodyObj)
  });
  return res.json();
}

// ─── Automation Engine ────────────────────────────────────
// Executes active automation rules when an inbound message arrives.

function getBangladeshTime() {
  const now = new Date();
  const bangladesh = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Dhaka' }));
  return bangladesh;
}

function isWithinOfficeHours() {
  const bd = getBangladeshTime();
  const day = bd.getDay(); // 0=Sun, 1=Mon, ..., 6=Sat
  const hour = bd.getHours();
  // Bangladesh office: Sunday-Thursday, 9:00-18:00
  if (day === 5) return false; // Friday (closed)
  if (day === 6) return false; // Saturday (closed)
  if (hour < 9 || hour >= 18) return false;
  return true;
}

function substituteTemplateVars(content, vars) {
  return content.replace(/\{\{(\w+)\}\}/g, (match, key) => vars[key] !== undefined ? vars[key] : match);
}

async function executeAutomationRules({ conversation, message, channel, contact }) {
  if (!conversation || !message) return;

  const rules = db.prepare("SELECT * FROM automation_rules WHERE active=1 ORDER BY priority DESC, id DESC").all();
  if (!rules.length) return;

  const msgText = (message.content || '').toLowerCase();
  const isFirstInbound = db.prepare("SELECT COUNT(*) as n FROM messages WHERE conversation_id=? AND direction='in'").get(conversation.id).n <= 1;
  const hasAgentReply = db.prepare("SELECT COUNT(*) as n FROM messages WHERE conversation_id=? AND direction='out' AND is_internal_note=0").get(conversation.id).n > 0;
  const inOfficeHours = isWithinOfficeHours();
  const lastAgentReply = db.prepare("SELECT created_at FROM messages WHERE conversation_id=? AND direction='out' AND is_internal_note=0 ORDER BY created_at DESC LIMIT 1").get(conversation.id);
  const minutesSinceAgentReply = lastAgentReply ? (Date.now() - new Date(lastAgentReply.created_at).getTime()) / 60000 : Infinity;

  for (const rule of rules) {
    try {
      let triggered = false;
      const cfg = JSON.parse(rule.trigger_config || '{}');

      // ── Trigger evaluation ──
      switch (rule.trigger_type) {
        case 'keyword': {
          const keywords = (cfg.keywords || []).map(k => k.toLowerCase());
          const matchType = cfg.match_type || 'contains';
          if (matchType === 'exact') {
            triggered = keywords.includes(msgText.trim());
          } else {
            triggered = keywords.some(k => msgText.includes(k));
          }
          break;
        }
        case 'new_conversation': {
          triggered = isFirstInbound;
          break;
        }
        case 'no_response': {
          const delayMin = Number(cfg.delay) || 30;
          triggered = hasAgentReply && minutesSinceAgentReply >= delayMin;
          break;
        }
        case 'time_based': {
          // Time-based rules are checked separately via cron, not on message arrival
          triggered = false;
          break;
        }
        case 'lead_status_change': {
          // Handled separately via lead update hook
          triggered = false;
          break;
        }
      }

      if (!triggered) continue;

      // Log trigger
      db.prepare("INSERT INTO automation_analytics (rule_id, event_type, conversation_id, created_at) VALUES (?, 'triggered', ?, datetime('now'))").run(rule.id, conversation.id);

      // ── Action execution ──
      const actCfg = JSON.parse(rule.action_config || '{}');
      let executed = false;

      switch (rule.action_type) {
        case 'reply': {
          if (!actCfg.template_id) break;
          const template = db.prepare("SELECT * FROM message_templates WHERE id=?").get(actCfg.template_id);
          if (!template) { console.error(`[auto] Template ${actCfg.template_id} not found`); break; }

          // Check if we already sent an auto-reply recently (avoid spam)
          const lastAuto = db.prepare("SELECT created_at FROM messages WHERE conversation_id=? AND direction='out' AND sent_by='auto' ORDER BY created_at DESC LIMIT 1").get(conversation.id);
          if (lastAuto) {
            const minsSince = (Date.now() - new Date(lastAuto.created_at).getTime()) / 60000;
            if (minsSince < 5) { console.log(`[auto] Skipping rule ${rule.id} — auto-reply sent ${minsSince.toFixed(0)}m ago`); break; }
          }

          // Build variables
          const lead = conversation.lead_id ? db.prepare("SELECT * FROM leads WHERE id=?").get(conversation.lead_id) : null;
          const vars = {
            name: contact?.name || 'there',
            destination: lead?.destination || 'our university',
            program: lead?.program || 'your program',
            consultant: lead?.assigned_consultant || conversation.assigned_to || 'our team',
            phone: contact?.phone || '',
            email: contact?.email || '',
            channel: channel?.name || 'WhatsApp',
          };
          const replyText = substituteTemplateVars(template.content, vars);

          // Send
          let sent = null;
          if (channel?.type === 'whatsapp' && contact?.phone) {
            sent = await sendWhatsApp(channel, contact.phone, replyText);
          } else if (channel?.type === 'messenger' && contact?.messenger_id) {
            sent = await sendMessenger(channel, contact.messenger_id, replyText);
          }

          if (sent && !sent.error) {
            const waMsgId = sent.messages?.[0]?.id || null;
            db.prepare(`INSERT INTO messages (conversation_id, direction, type, content, wa_message_id, status, sent_by, created_at)
              VALUES (?, 'out', 'text', ?, ?, 'delivered', 'auto', datetime('now'))`).run(conversation.id, replyText, waMsgId);
            db.prepare("UPDATE message_templates SET usage_count = COALESCE(usage_count, 0) + 1 WHERE id=?").run(template.id);
            db.prepare("UPDATE conversations SET last_message=?, last_message_at=datetime('now'), last_message_direction='out' WHERE id=?").run(replyText, conversation.id);
            broadcast('new_message', { conversation_id: conversation.id, message: { content: replyText, direction: 'out', sent_by: 'auto', created_at: new Date().toISOString() } });
            executed = true;
            console.log(`[auto] Rule ${rule.id} → auto-reply sent: "${replyText.slice(0, 60)}..."`);
          } else if (sent?.error) {
            console.error(`[auto] Rule ${rule.id} send failed:`, sent.error.message || sent.error);
          }
          break;
        }

        case 'assign': {
          if (!actCfg.assignee) break;
          const emp = db.prepare("SELECT * FROM employees WHERE id=? OR name=? LIMIT 1").get(actCfg.assignee, actCfg.assignee);
          if (emp) {
            db.prepare("UPDATE conversations SET assigned_to=?, assigned_to_id=? WHERE id=?").run(emp.name, emp.id, conversation.id);
            broadcast('conversation_updated', { id: conversation.id, assigned_to: emp.name, assigned_to_id: emp.id });
            executed = true;
          }
          break;
        }

        case 'add_tag': {
          if (!actCfg.tag) break;
          const tag = db.prepare("SELECT * FROM contact_tags WHERE id=? OR name=? LIMIT 1").get(actCfg.tag, actCfg.tag);
          if (tag && contact) {
            db.prepare("INSERT OR IGNORE INTO contact_tag_assignments (contact_id, tag_id, assigned_by) VALUES (?, ?, 'auto')").run(contact.id, tag.id);
            executed = true;
          }
          break;
        }

        case 'create_lead': {
          if (!contact || conversation.lead_id) break;
          const leadId = nextLeadId();
          const src = channel?.name || channel?.type || 'Auto';
          db.prepare(`INSERT INTO leads (lead_id, client_name, phone, email, lead_source, lead_status, source, notes, date_added)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(leadId, contact.name || 'Unknown', contact.phone || null, contact.email || null, src, 'New Lead', 'Auto', 'Created by automation rule', new Date().toISOString().slice(0,10));
          const lead = db.prepare("SELECT * FROM leads WHERE lead_id=?").get(leadId);
          if (lead) {
            db.prepare("UPDATE conversations SET lead_id=? WHERE id=?").run(lead.id, conversation.id);
            db.prepare("UPDATE contacts SET lead_id=? WHERE id=?").run(lead.id, contact.id);
            broadcast('new_lead', { lead });
            executed = true;
          }
          break;
        }

        case 'send_webhook': {
          if (!actCfg.webhook_url) break;
          try {
            await fetch(actCfg.webhook_url, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                event: 'automation_rule_triggered',
                rule_id: rule.id,
                rule_name: rule.name,
                conversation_id: conversation.id,
                contact: { name: contact?.name, phone: contact?.phone },
                message: message.content,
                timestamp: new Date().toISOString()
              })
            });
            executed = true;
          } catch (e) { console.error('[auto] Webhook failed:', e.message); }
          break;
        }
      }

      if (executed) {
        db.prepare("INSERT INTO automation_analytics (rule_id, event_type, conversation_id, created_at) VALUES (?, 'executed', ?, datetime('now'))").run(rule.id, conversation.id);
      }

    } catch (e) {
      console.error(`[auto] Rule ${rule.id} error:`, e.message);
      try {
        db.prepare("INSERT INTO automation_analytics (rule_id, event_type, conversation_id, created_at) VALUES (?, 'failed', ?, datetime('now'))").run(rule.id, conversation.id);
      } catch {}
    }
  }
}

async function sendBroadcast(campaignId) {
  try {
    const campaign = db.prepare("SELECT * FROM broadcast_campaigns WHERE id=?").get(campaignId);
    if (!campaign) return { error: 'Campaign not found' };
    if (campaign.status === 'sending' || campaign.status === 'sent') return { error: 'Already sent or sending' };

    let contacts = [];
    const segmentConfig = campaign.segment_config ? JSON.parse(campaign.segment_config) : {};
    if (campaign.segment_type === 'all' || !campaign.segment_type) {
      contacts = db.prepare("SELECT * FROM contacts WHERE wa_id IS NOT NULL OR messenger_id IS NOT NULL OR instagram_id IS NOT NULL").all();
    } else if (campaign.segment_type === 'tag' || campaign.segment_type === 'by_tag') {
      const tagIds = segmentConfig.tag_ids || [];
      if (tagIds.length) {
        const placeholders = tagIds.map(() => '?').join(',');
        contacts = db.prepare(`SELECT contacts.* FROM contacts JOIN contact_tag_assignments ON contact_tag_assignments.contact_id = contacts.id WHERE contact_tag_assignments.tag_id IN (${placeholders}) GROUP BY contacts.id`).all(...tagIds);
      }
    } else if (campaign.segment_type === 'status' || campaign.segment_type === 'by_status') {
      const statuses = segmentConfig.lead_statuses || [];
      if (statuses.length) {
        const placeholders = statuses.map(() => '?').join(',');
        contacts = db.prepare(`SELECT contacts.* FROM contacts JOIN leads ON leads.id = contacts.lead_id WHERE leads.lead_status IN (${placeholders}) GROUP BY contacts.id`).all(...statuses);
      }
    } else if (campaign.segment_type === 'channel' || campaign.segment_type === 'by_channel') {
      const channelTypes = segmentConfig.channel_types || [];
      if (channelTypes.length) {
        const placeholders = channelTypes.map(() => '?').join(',');
        const isNumeric = channelTypes.every(v => !isNaN(parseInt(v)));
        if (isNumeric) {
          const channelIds = channelTypes.map(v => parseInt(v));
          contacts = db.prepare(`SELECT contacts.* FROM contacts JOIN conversations ON conversations.contact_id = contacts.id WHERE conversations.channel_id IN (${placeholders}) GROUP BY contacts.id`).all(...channelIds);
        } else {
          contacts = db.prepare(`SELECT contacts.* FROM contacts JOIN conversations ON conversations.contact_id = contacts.id WHERE conversations.channel_type IN (${placeholders}) GROUP BY contacts.id`).all(...channelTypes);
        }
      }
    }

    if (!contacts.length) {
      db.prepare("UPDATE broadcast_campaigns SET status='sent' WHERE id=?").run(campaignId);
      return { sent: 0 };
    }

    db.prepare("UPDATE broadcast_campaigns SET status='sending' WHERE id=?").run(campaignId);

    let template = null;
    if (campaign.template_id) {
      template = db.prepare("SELECT * FROM message_templates WHERE id=?").get(campaign.template_id);
    }

    let sent = 0, failed = 0;
    const insertRecipient = db.prepare("INSERT INTO broadcast_recipients (campaign_id, contact_id, status) VALUES (?,?,?)");

    for (const contact of contacts) {
      try {
        const recipientInfo = insertRecipient.run(campaignId, contact.id, 'pending');
        const recipientId = recipientInfo.lastInsertRowid;

        let messageText = campaign.content || '';
        if (template) {
          messageText = substituteTemplateVars(template.content, {
            name: contact.name || '',
            ...segmentConfig.variables
          });
        }

        let channel = null;
        if (contact.wa_id) {
          channel = db.prepare("SELECT * FROM channels WHERE type='whatsapp' AND active=1 LIMIT 1").get();
        } else if (contact.messenger_id) {
          channel = db.prepare("SELECT * FROM channels WHERE type='messenger' AND active=1 LIMIT 1").get();
        } else if (contact.instagram_id) {
          channel = db.prepare("SELECT * FROM channels WHERE type='instagram' AND active=1 LIMIT 1").get();
        }

        if (!channel || !messageText) {
          db.prepare("UPDATE broadcast_recipients SET status='failed', error=? WHERE id=?").run('No channel or message', recipientId);
          failed++;
          continue;
        }

        let apiResult = null;
        if (channel.type === 'whatsapp') {
          apiResult = await sendWhatsApp(channel, contact.wa_id || contact.phone, messageText);
        } else if (channel.type === 'messenger') {
          apiResult = await sendMessenger(channel, contact.messenger_id, messageText);
        } else if (channel.type === 'instagram') {
          apiResult = await sendMessenger({ ...channel, page_id: channel.ig_account_id || channel.page_id }, contact.instagram_id || contact.messenger_id, messageText);
        } else if (channel.type === 'tiktok') {
          apiResult = { error: { message: 'TikTok broadcast not yet supported' } };
        }

        if (apiResult?.error) {
          db.prepare("UPDATE broadcast_recipients SET status='failed', error=?, sent_at=datetime('now') WHERE id=?").run(apiResult.error.message || 'API error', recipientId);
          failed++;
        } else {
          db.prepare("UPDATE broadcast_recipients SET status='sent', sent_at=datetime('now') WHERE id=?").run(recipientId);
          sent++;
        }
      } catch (err) {
        console.error('[broadcast] send error for contact', contact.id, err.message);
        failed++;
      }
    }

    db.prepare("UPDATE broadcast_campaigns SET status='sent', sent_count=?, delivered_count=?, failed_count=? WHERE id=?").run(sent, sent, failed, campaignId);
    if (template) {
      db.prepare("UPDATE message_templates SET usage_count=usage_count+? WHERE id=?").run(sent, template.id);
    }
    return { sent, failed, total: contacts.length };
  } catch (e) {
    console.error('[broadcast] sendBroadcast error:', e.message);
    db.prepare("UPDATE broadcast_campaigns SET status='failed' WHERE id=?").run(campaignId);
    return { error: e.message };
  }
}

// SHA-256 hash helper required by Meta CAPI for all PII fields
const capiHash = (s) => s ? crypto.createHash('sha256').update(s.trim()).digest('hex') : undefined;

async function sendCAPIEvent(eventName, leadData) {
  const pixelId = getConfig('pixel_id');
  const accessToken = getConfig('capi_token') || getConfig('page_access_token');
  if (!accessToken) return { skipped: true, reason: 'no_token' };
  if (!pixelId) return { skipped: true, reason: 'no_pixel_id' };
  const normalizedPhone = leadData.phone ? leadData.phone.replace(/\D/g, '') : null;
  const normalizedEmail = leadData.email ? leadData.email.toLowerCase().trim() : null;
  const userData = {
    ph: normalizedPhone ? [capiHash(normalizedPhone)] : undefined,
    em: normalizedEmail ? [capiHash(normalizedEmail)] : undefined,
    country: ['bd'],
  };
  if (leadData.fbp) userData.fbp = leadData.fbp;
  if (leadData.fbc) userData.fbc = leadData.fbc;
  const payload = {
    data: [{
      event_name: eventName,
      event_time: Math.floor(Date.now() / 1000),
      event_id: `${leadData.lead_id || 'L'}-${eventName}-${Date.now()}`,
      action_source: 'system_generated',
      user_data: userData,
      custom_data: {
        lead_id: leadData.lead_id,
        destination: leadData.destination,
        event_source_url: leadData.event_source_url || undefined,
      },
    }],
  };
  const clean = o => {
    if (typeof o !== 'object' || !o) return o;
    if (Array.isArray(o)) return o.filter(v => v !== undefined).map(clean);
    return Object.fromEntries(Object.entries(o).filter(([,v]) => v !== undefined).map(([k,v]) => [k, clean(v)]));
  };
  try {
    const res = await fetch(`https://graph.facebook.com/v19.0/${pixelId}/events?access_token=${accessToken}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(clean(payload))
    });
    return res.json();
  } catch (e) { return { error: e.message }; }
}

function getWhatsAppChannelForConsultant(consultantName) {
  if (!consultantName) return null;
  const chan = db.prepare("SELECT * FROM channels WHERE type = 'whatsapp' AND LOWER(TRIM(consultant)) = LOWER(TRIM(?)) AND active = 1 LIMIT 1").get(consultantName);
  if (chan) return chan;
  // fallback: any active WhatsApp channel
  return db.prepare("SELECT * FROM channels WHERE type = 'whatsapp' AND active = 1 LIMIT 1").get();
}

// ─────────────────────────────────────────────────────────
// DASHBOARD
// ─────────────────────────────────────────────────────────
app.get('/api/dashboard', (req, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const user = req.user;
  const isAdmin = isFullAdmin(user) || isInvestor(user) || userHasAnyRole(user, 'application_manager', 'marketing_manager');
  const isConsultant = canViewOwnLeadsOnly(user);

  // Build WHERE clause for consultant scoping
  let leadWhere = '';
  let leadParams = [];
  if (isConsultant) {
    const meName = user.consultant_name || user.name || '';
    const meClean = meName.split(' ')[0];
    let empId = -1;
    if (user.emp_id) {
      const emp = db.prepare("SELECT id FROM employees WHERE emp_id=?").get(user.emp_id);
      if (emp) empId = emp.id;
    }
    leadWhere = `WHERE (assigned_employee_id = ? OR TRIM(LOWER(assigned_consultant)) = TRIM(LOWER(?)) OR TRIM(LOWER(assigned_consultant)) = TRIM(LOWER(?)) OR TRIM(LOWER(?)) LIKE '%' || TRIM(LOWER(assigned_consultant)) || '%' OR TRIM(LOWER(assigned_consultant)) LIKE '%' || TRIM(LOWER(?)) || '%')`;
    leadParams = [empId, meName, meClean, meName, meClean];
  }

  // China data isolation: exclude China leads from stats for unauthorized users
  const chinaExclusion = !canViewChinaData(user) ? " AND (destination != 'China' AND source != 'China')" : '';
  
  // When leadWhere is empty, we need a base WHERE clause so chinaExclusion (which starts with AND) works
  const baseWhere = leadWhere || 'WHERE 1=1';

  const scalars = db.prepare(`
    SELECT
      (SELECT COUNT(*) FROM leads ${baseWhere}${chinaExclusion}) AS total,
      (SELECT COUNT(*) FROM leads ${baseWhere} AND next_followup=?${chinaExclusion}) AS followup_today,
      (SELECT SUM(paid) FROM leads ${baseWhere}${chinaExclusion}) AS total_paid,
      (SELECT COUNT(*) FROM leads ${baseWhere} AND meta_lead_id IS NOT NULL${chinaExclusion}) AS meta_leads,
      (SELECT COUNT(*) FROM leads ${baseWhere} AND date_added=?${chinaExclusion}) AS new_today
  `).get(...leadParams, ...leadParams, today, ...leadParams, ...leadParams, ...leadParams, today);

  const convScalars = db.prepare(`
    SELECT
      (SELECT COUNT(*) FROM conversations WHERE status='open') AS open_convs,
      (SELECT SUM(unread_count) FROM conversations) AS unread_msgs
  `).get();

  const pipeline = db.prepare(`SELECT lead_status, COUNT(*) as count FROM leads ${baseWhere}${chinaExclusion} GROUP BY lead_status`).all(...leadParams);
  const recentLeads = db.prepare(`SELECT * FROM leads ${baseWhere}${chinaExclusion} ORDER BY id DESC LIMIT 5`).all(...leadParams);
  const by_source = db.prepare(`SELECT lead_source as k, COUNT(*) as n FROM leads WHERE lead_source IS NOT NULL AND lead_source!='' ${leadWhere ? 'AND ' + leadWhere.replace(/^WHERE /, '') : ''}${chinaExclusion} GROUP BY lead_source ORDER BY n DESC LIMIT 6`).all(...leadParams);
  const by_dest = db.prepare(`SELECT destination as k, COUNT(*) as n FROM leads WHERE destination IS NOT NULL AND destination!='' ${leadWhere ? 'AND ' + leadWhere.replace(/^WHERE /, '') : ''}${chinaExclusion} GROUP BY destination ORDER BY n DESC LIMIT 8`).all(...leadParams);

  res.json({
    pipeline,
    total: scalars.total,
    followupToday: scalars.followup_today,
    recentLeads,
    totalPaid: scalars.total_paid || 0,
    metaLeads: scalars.meta_leads,
    openConvs: convScalars.open_convs,
    unreadMsgs: convScalars.unread_msgs || 0,
    newToday: scalars.new_today,
    by_source,
    by_dest,
  });
});

// ─────────────────────────────────────────────────────────
// LEADS
// ─────────────────────────────────────────────────────────
// Build a uniform params object for the lead create/update statements.
// Whitelist exactly the columns we persist so unknown fields in req.body
// can't slip into the SQL.
function leadParams(d, lead_id, balance) {
  const num = v => v === '' || v == null ? 0 : Number(v);
  const txt = v => (v === '' || v == null) ? null : v;
  let assigned_employee_id = d.assigned_employee_id ? Number(d.assigned_employee_id) : null;
  let assigned_consultant = txt(d.assigned_consultant);
  // If employee_id is provided but consultant name is not, resolve from employees table
  if (assigned_employee_id && !assigned_consultant) {
    try {
      const emp = db.prepare("SELECT name FROM employees WHERE id=?").get(assigned_employee_id);
      if (emp?.name) assigned_consultant = emp.name;
    } catch {}
  }
  let phone = d.phone ? String(d.phone).trim() : null;
  if (phone) {
    const digits = phone.replace(/[^\d]/g, '');
    if (digits.startsWith('01') && digits.length === 11) {
      phone = '+88' + digits;
    } else if (digits.startsWith('8801') && digits.length === 13) {
      phone = '+' + digits;
    }
  }

  return {
    lead_id, balance,
    date_added: d.date_added || new Date().toISOString().slice(0,10),
    client_name: d.client_name,
    phone: phone, email: d.email,
    destination: txt(d.destination),
    last_education: txt(d.last_education),
    gpa: d.gpa === '' || d.gpa == null ? null : Number(d.gpa),
    english_score: txt(d.english_score),
    program: txt(d.program || d.major),
    lead_source: d.lead_source || 'Manual',
    lead_status: d.lead_status || 'New Lead',
    assigned_employee_id,
    assigned_consultant,
    service_fee: num(d.service_fee), paid: num(d.paid),
    payment_status: txt(d.payment_status),
    next_followup: txt(d.next_followup),
    notes: txt(d.notes),
    meta_lead_id: txt(d.meta_lead_id), meta_form_id: txt(d.meta_form_id),
    meta_ad_id: txt(d.meta_ad_id), meta_campaign: txt(d.meta_campaign),
    // Excel-aligned
    source: txt(d.source), referrer: txt(d.referrer),
    nationality: txt(d.nationality), passport: txt(d.passport),
    degree: txt(d.degree), major: txt(d.major),
    intake_term: txt(d.intake_term), university: txt(d.university),
    drive_link: txt(d.drive_link), deposit: num(d.deposit),
    // Medical
    blood_group: txt(d.blood_group), date_of_birth: txt(d.date_of_birth),
    medical_notes: txt(d.medical_notes), emergency_contact: txt(d.emergency_contact),
    // Active application stage
    application_stage: txt(d.application_stage),
  };
}






// ─── LEAD TIMELINE — full chronological story of one lead ──────────────────
// Merges activity_log entries for this lead with related income rows so the
// owner sees one single feed: created, status changes, reassignments, every
// payment (whether logged inline or as a separate income row), notes,
// university-application status flips, etc.

// Add a note to a lead — appears in the timeline.

// ─── BROADCASTS — owner's sticky-note for the whole team ───────────────────
app.get('/api/broadcasts', (req, res) => {
  const userId = req.user?.id;
  const rows = db.prepare(`SELECT b.*,
      EXISTS(SELECT 1 FROM broadcast_dismissals d WHERE d.broadcast_id=b.id AND d.user_id=?) AS dismissed
    FROM broadcasts b
    WHERE b.expires_at IS NULL OR b.expires_at > datetime('now')
    ORDER BY b.pinned DESC, b.id DESC`).all(userId || 0);
  res.json(rows);
});

app.post('/api/broadcasts', (req, res) => requireAdmin(req, res, () => {
  const { message, color = 'amber', pinned = 1, expires_at = null } = req.body || {};
  if (!message?.trim()) return res.status(400).json({ error: 'message is required' });
  const info = db.prepare(`INSERT INTO broadcasts (message, author_id, author_name, color, pinned, expires_at)
    VALUES (?,?,?,?,?,?)`).run(message.trim(), req.user.id, req.user.name || req.user.email, color, pinned ? 1 : 0, expires_at);
  broadcast('broadcast_new', { broadcast: db.prepare("SELECT * FROM broadcasts WHERE id=?").get(info.lastInsertRowid) });
  logActivity({ type: 'broadcast_posted', actor: req.user, details: message.trim().slice(0, 200) });
  res.json(db.prepare("SELECT * FROM broadcasts WHERE id=?").get(info.lastInsertRowid));
}));

app.delete('/api/broadcasts/:id', (req, res) => requireAdmin(req, res, () => {
  db.prepare("DELETE FROM broadcast_dismissals WHERE broadcast_id=?").run(req.params.id);
  db.prepare("DELETE FROM broadcasts WHERE id=?").run(req.params.id);
  res.json({ ok: true });
}));

app.post('/api/broadcasts/:id/dismiss', (req, res) => {
  if (!req.user?.id) return res.status(401).json({ error: 'auth required' });
  db.prepare(`INSERT OR IGNORE INTO broadcast_dismissals (broadcast_id, user_id) VALUES (?,?)`)
    .run(req.params.id, req.user.id);
  res.json({ ok: true });
});

// ─── DATA IMPORT — parsed rows come from the browser (SheetJS); the server
// just inserts what's already mapped, with idempotency by content key. ─────
function importCashflowRows(rows, actor) {
  let inserted = 0, skipped = 0;
  const insIn  = db.prepare(`INSERT INTO income   (date, month, category, client_name, reference, amount, notes) VALUES (?,?,?,?,?,?,?)`);
  const insOut = db.prepare(`INSERT INTO expenses (date, month, category, paid_to,    reference, amount, notes) VALUES (?,?,?,?,?,?,?)`);
  // Dedupe by (kind, month, category, client_name, amount)
  const existingIn  = new Set(db.prepare("SELECT date||'|'||COALESCE(category,'')||'|'||COALESCE(client_name,'')||'|'||amount AS k FROM income").all().map(r => r.k));
  const existingOut = new Set(db.prepare("SELECT date||'|'||COALESCE(category,'')||'|'||COALESCE(paid_to,'')||'|'||amount AS k FROM expenses").all().map(r => r.k));

  const txn = db.transaction(() => {
    for (const r of rows) {
      if (!r || typeof r !== 'object') continue;
      const amount = Number(r.amount) || 0;
      if (amount === 0 && !r.client_name && !r.category) { skipped++; continue; }
      const date = r.date || (r.month ? `${r.month}-01` : new Date().toISOString().slice(0,10));
      const month = r.month || date.slice(0,7);
      const key = `${date}|${r.category||''}|${r.client_name||''}|${amount}`;
      if (r.kind === 'in') {
        if (existingIn.has(key)) { skipped++; continue; }
        insIn.run(date, month, r.category||null, r.client_name||null, r.reference||null, amount, r.notes||null);
        existingIn.add(key); inserted++;
      } else {
        if (existingOut.has(key)) { skipped++; continue; }
        insOut.run(date, month, r.category||null, r.client_name||null, r.reference||null, amount, r.notes||null);
        existingOut.add(key); inserted++;
      }
    }
  });
  txn();
  logActivity({ type: 'import_cashflow', actor, details: { inserted, skipped, total: rows.length } });
  return { inserted, skipped };
}

function importApplicationRows(rows, actor) {
  let inserted = 0, updated = 0, skipped = 0;
  const newLeadId = () => {
    const last = db.prepare("SELECT lead_id FROM leads WHERE lead_id LIKE 'LEAD-%' ORDER BY id DESC LIMIT 1").get();
    const n = last ? parseInt(last.lead_id.split('-')[1]) + 1 : 1;
    return `LEAD-${String(n).padStart(4, '0')}`;
  };
  const ins = db.prepare(`INSERT INTO leads
    (lead_id, date_added, client_name, phone, email, destination, last_education, gpa, english_score,
     program, lead_source, lead_status, assigned_consultant, service_fee, paid, balance,
     source, referrer, nationality, passport, degree, major, intake_term, university,
     drive_link, deposit, application_stage)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const upd = db.prepare(`UPDATE leads SET
     source=COALESCE(?, source), referrer=COALESCE(?, referrer),
     nationality=COALESCE(?, nationality), passport=COALESCE(?, passport),
     degree=COALESCE(?, degree), major=COALESCE(?, major),
     intake_term=COALESCE(?, intake_term), university=COALESCE(?, university),
     drive_link=COALESCE(?, drive_link), destination=COALESCE(?, destination),
     application_stage=COALESCE(?, application_stage)
   WHERE id=?`);
  const insUniApp = db.prepare(`INSERT INTO lead_university_applications (lead_id, university, status) VALUES (?,?,?)`);

  // Pre-load passport map and name map for dedupe.
  const byPassport = new Map(db.prepare("SELECT id, passport FROM leads WHERE passport IS NOT NULL").all().map(r => [String(r.passport).toUpperCase(), r.id]));
  const byName = new Map(db.prepare("SELECT id, client_name FROM leads").all().map(r => [String(r.client_name || '').toLowerCase().trim(), r.id]));

  const STATUS_MAP = {
    'documents': 'documents', 'documents collecting': 'documents',
    'ready': 'ready', 'documents ready': 'ready',
    'submitted': 'submitted', 'applied to university': 'submitted',
    'interview': 'interview',
    'pre_admission': 'pre_admission', 'pre-admission': 'pre_admission',
    'deposit': 'deposit',
    'admitted': 'admitted', 'admission/jw received': 'admitted', 'jw received': 'admitted',
    'visa_applied': 'visa_applied', 'visa applied': 'visa_applied',
    'visa_approved': 'visa_approved', 'visa approved': 'visa_approved',
    'visa_rejected': 'visa_rejected', 'visa rejected': 'visa_rejected',
    'enrolled': 'enrolled',
    'cancelled': 'cancelled',
    'withdraw': 'withdraw', 'withdrawn': 'withdraw',
    'return': 'submitted', 'returned': 'submitted',
    'reject': 'documents', 'rejected': 'documents'
  };
  const APP_STAGE_FROM_STATUS = { ...STATUS_MAP };

  const txn = db.transaction(() => {
    for (const r of rows) {
      if (!r || !r.client_name?.trim()) { skipped++; continue; }
      const name = r.client_name.trim();
      const passportKey = r.passport ? String(r.passport).toUpperCase().trim() : null;
      let existingId = null;
      if (passportKey && byPassport.has(passportKey)) existingId = byPassport.get(passportKey);
      else if (byName.has(name.toLowerCase())) existingId = byName.get(name.toLowerCase());

      const statusKey = (r.status || '').toLowerCase().trim();
      const appStage = APP_STAGE_FROM_STATUS[statusKey] || 'documents';
      const firstUni = r.universities ? String(r.universities).split(/[,/;]/)[0]?.trim() : (r.university || null);

      if (existingId) {
        const lead = db.prepare("SELECT lead_status, application_stage FROM leads WHERE id=?").get(existingId);
        const nextStage = APP_STAGE_FROM_STATUS[statusKey] || lead?.application_stage || 'documents';
        const nextStatus = (lead?.lead_status && lead.lead_status !== 'New Lead') ? lead.lead_status : 'File Opened';
        
        db.prepare("UPDATE leads SET lead_status=? WHERE id=?").run(nextStatus, existingId);

        upd.run(
          r.source || null, r.referrer || null, r.nationality || null, r.passport || null,
          r.degree || null, r.major || null, r.intake_term || null, firstUni,
          r.drive_link || null, r.destination || null, nextStage, existingId);
        updated++;
      } else {
        const lead_id = newLeadId();
        const info = ins.run(
          lead_id, r.date_added || new Date().toISOString().slice(0, 10),
          name, r.phone || null, r.email || null, r.destination || null,
          r.last_education || null, r.gpa || null, r.english_score || null,
          r.program || r.major || null, r.lead_source || 'Excel import',
          'File Opened',
          r.assigned_consultant || null, r.service_fee || 0, r.paid || 0, (r.service_fee || 0) - (r.paid || 0),
          r.source || null, r.referrer || null, r.nationality || null, r.passport || null,
          r.degree || null, r.major || null, r.intake_term || null, firstUni,
          r.drive_link || null, r.deposit || 0,
          appStage
        );
        existingId = info.lastInsertRowid;
        if (passportKey) byPassport.set(passportKey, existingId);
        byName.set(name.toLowerCase(), existingId);
        inserted++;
      }

      // Per-university applications from the comma-separated 'universities' field
      if (r.universities && existingId) {
        const list = String(r.universities).split(/[,/;]/).map(s => s.trim()).filter(Boolean);
        const have = new Set(db.prepare("SELECT university FROM lead_university_applications WHERE lead_id=?").all(existingId).map(x => x.university.toLowerCase()));
        const uStatus = STATUS_MAP[statusKey] || 'documents';
        for (const u of list) {
          if (have.has(u.toLowerCase())) continue;
          insUniApp.run(existingId, u, uStatus);
        }
      }
    }
  });
  txn();
  logActivity({ type: 'import_applications', actor, details: { inserted, updated, skipped, total: rows.length } });
  return { inserted, updated, skipped };
}

app.post('/api/import/cashflow', (req, res) => requireAdmin(req, res, () => {
  const rows = Array.isArray(req.body?.rows) ? req.body.rows : [];
  if (rows.length === 0) return res.status(400).json({ error: 'No rows to import' });
  if (rows.length > 5000) return res.status(400).json({ error: 'Too many rows in one batch (max 5000)' });
  try { res.json(importCashflowRows(rows, req.user)); }
  catch (e) { res.status(500).json({ error: e.message }); }
}));

app.post('/api/import/applications', (req, res) => requireAdmin(req, res, () => {
  const rows = Array.isArray(req.body?.rows) ? req.body.rows : [];
  if (rows.length === 0) return res.status(400).json({ error: 'No rows to import' });
  if (rows.length > 5000) return res.status(400).json({ error: 'Too many rows in one batch (max 5000)' });
  try { res.json(importApplicationRows(rows, req.user)); }
  catch (e) { res.status(500).json({ error: e.message }); }
}));

app.get('/api/debug/db', (req, res) => requireAdmin(req, res, () => {
  try {
    const channels = db.prepare("SELECT id, type, name, page_id, active, status FROM channels").all();
    const recentConvs = db.prepare(`
      SELECT conversations.*, contacts.name as contact_name, contacts.messenger_id
      FROM conversations 
      LEFT JOIN contacts ON contacts.id = conversations.contact_id 
      ORDER BY conversations.id DESC LIMIT 15
    `).all();
    const recentMessages = db.prepare(`
      SELECT messages.*, conversations.channel_id 
      FROM messages 
      LEFT JOIN conversations ON conversations.id = messages.conversation_id 
      ORDER BY messages.id DESC LIMIT 30
    `).all();
    res.json({ channels, recentConvs, recentMessages });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}));

// ─── ADMIN: wipe all leads (+ documents, uni-apps, activity log, KPI targets) ───
// Optional body: { conversations: true } → also wipes chat threads, messages & contacts.
// Finance (income/expenses), employees, attendance, payroll, users & settings are NEVER touched.
app.delete('/api/admin/wipe-leads', (req, res) => requireAdmin(req, res, () => {
  try {
    const wipeConversations = !!(req.body && req.body.conversations);
    const count = db.prepare("SELECT COUNT(*) as c FROM leads").get().c;

    const wipe = db.transaction(() => {
      db.prepare("DELETE FROM leads").run();                 // cascades documents + uni-apps
      db.prepare("DELETE FROM activity_log").run();          // stale KPI / performance history
      db.prepare("DELETE FROM kpi_targets").run();           // old monthly targets
      const seqTables = ['leads','lead_documents','lead_university_applications','activity_log','kpi_targets'];
      if (wipeConversations) {
        db.prepare("DELETE FROM messages").run();
        db.prepare("DELETE FROM conversations").run();
        db.prepare("DELETE FROM contacts").run();
        seqTables.push('messages','conversations','contacts');
      }
      // Reset auto-increment so IDs start fresh
      db.prepare(`DELETE FROM sqlite_sequence WHERE name IN (${seqTables.map(() => '?').join(',')})`).run(...seqTables);
    });
    wipe();

    res.json({ ok: true, deleted: count, conversationsWiped: wipeConversations });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}));

// ─── SYSTEM HEALTH & BACKUP ───────────────────────────────────────────
app.get('/api/health/db-size', (req, res) => {
  try {
    const stats = db.prepare("SELECT page_count * page_size as bytes FROM pragma_page_count(), pragma_page_size()").get();
    res.json({ bytes: stats?.bytes || 0, tables: db.prepare("SELECT count(*) as c FROM sqlite_master WHERE type='table'").get().c });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/health/backup', (req, res) => requireAdmin(req, res, () => {
  try {
    db.flush();
    const data = db.export();
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="crm_backup_${new Date().toISOString().slice(0,10)}.db"`);
    res.send(Buffer.from(data));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}));

app.get('/api/health/export-json', (req, res) => requireAdmin(req, res, () => {
  try {
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map(r => r.name);
    const exportData = {};
    for (const t of tables) {
      try {
        exportData[t] = db.prepare(`SELECT * FROM "${t}"`).all();
      } catch (err) {
        exportData[t] = { error: err.message };
      }
    }
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="crm_export_${new Date().toISOString().slice(0,10)}.json"`);
    res.json(exportData);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}));

// ─── STAFF REPLY to a student through the portal thread ───────────────────



// Public debug endpoint removed after successful verification

app.get('/api/media/:msgId', async (req, res) => {
  try {
    const row = db.prepare(`
      SELECT m.id, m.media_url, m.media_mime, m.type as msg_type,
             ch.access_token, ch.type as chan_type
      FROM messages m
      JOIN conversations cv ON cv.id = m.conversation_id
      JOIN channels ch ON ch.id = cv.channel_id
      WHERE m.id = ?
    `).get(req.params.msgId);

    if (!row) {
      return res.status(404).json({ error: 'Message not found' });
    }

    if (!row.media_url) {
      return res.status(400).json({ error: 'Message has no media attachment' });
    }

    // 1. Local uploads
    if (row.media_url.startsWith('/uploads')) {
      const filePath = join(__dirname, row.media_url);
      if (existsSync(filePath)) {
        return res.sendFile(filePath);
      }
      return res.status(404).json({ error: 'Local file not found' });
    }

    // 2. Direct HTTP/HTTPS URLs (Messenger/Instagram)
    if (row.media_url.startsWith('http')) {
      try {
        const mediaRes = await fetch(row.media_url);
        if (!mediaRes.ok) {
          return res.status(mediaRes.status).json({ error: `Failed to fetch remote media: ${mediaRes.statusText}` });
        }
        const contentType = mediaRes.headers.get('content-type') || row.media_mime || 'application/octet-stream';
        res.setHeader('Content-Type', contentType);
        const arrayBuffer = await mediaRes.arrayBuffer();
        return res.send(Buffer.from(arrayBuffer));
      } catch (fetchErr) {
        return res.status(500).json({ error: `Failed to fetch remote media: ${fetchErr.message}` });
      }
    }

    // 3. Meta Media ID (numeric)
    const token = row.access_token;
    if (!token) {
      return res.status(400).json({ error: 'Channel has no access token to fetch Meta media' });
    }

    // Step 1: Query Meta Graph API to resolve media URL
    let downloadUrl = null;
    try {
      const metaRes = await fetch(`https://graph.facebook.com/v19.0/${row.media_url}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!metaRes.ok) {
        const errText = await metaRes.text();
        return res.status(metaRes.status).json({ error: `Meta Graph API error: ${errText}` });
      }
      const metaBody = await metaRes.json();
      downloadUrl = metaBody.url;
    } catch (metaErr) {
      return res.status(500).json({ error: `Meta Graph API request failed: ${metaErr.message}` });
    }

    if (!downloadUrl) {
      return res.status(500).json({ error: 'Meta Graph API did not return a media URL' });
    }

    // Step 2: Download the binary media from the resolved URL
    try {
      const imgRes = await fetch(downloadUrl, {
        headers: { Authorization: `Bearer ${token}`, 'User-Agent': 'WhatsApp/2.0' }
      });
      if (!imgRes.ok) {
        const errText = await imgRes.text();
        return res.status(imgRes.status).json({ error: `Failed to download media from Meta CDN: ${errText}` });
      }
      const contentType = imgRes.headers.get('content-type') || row.media_mime || 'application/octet-stream';
      res.setHeader('Content-Type', contentType);
      const arrayBuffer = await imgRes.arrayBuffer();
      return res.send(Buffer.from(arrayBuffer));
    } catch (downloadErr) {
      return res.status(500).json({ error: `Failed to download media from Meta CDN: ${downloadErr.message}` });
    }

  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

app.get('/api/public/debug-db', (req, res) => {
  const token = req.query.token || req.headers['x-api-key'];
  if (token !== INTERNAL_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  res.download(DB_PATH, 'crm.db');
});

app.post('/api/public/client-log', (req, res) => {
  try {
    const logPath = join(__dirname, 'dist', 'client-errors.json');
    let logs = [];
    if (existsSync(logPath)) {
      try {
        logs = JSON.parse(readFileSync(logPath, 'utf8'));
      } catch {}
    }
    const entry = {
      timestamp: new Date().toISOString(),
      ...req.body
    };
    console.log('[Client Error Logged]', entry);
    logs.push(entry);
    if (logs.length > 100) logs = logs.slice(-100);
    writeFileSync(logPath, JSON.stringify(logs, null, 2), 'utf8');
  } catch (err) {
    console.error('[Client Log Error]', err.message);
  }
  res.json({ ok: true });
});

// Public — student fetches the conversation thread (their messages + staff replies)
app.get('/api/public/student/:token/thread', (req, res) => {
  const lead = db.prepare("SELECT * FROM leads WHERE public_token=? AND public_enabled=1").get(req.params.token);
  if (!lead) return res.status(404).json({ error: 'Portal link not active.' });
  const rows = db.prepare(`SELECT id, type, actor_name, details, created_at
    FROM activity_log
    WHERE lead_id=? AND type IN ('note','reply_to_student','student_doc_upload')
    ORDER BY id ASC`).all(lead.id);
  res.json(rows);
});

// ─── STUDENT PORTAL (public link) ──────────────────────────────────────────
// Returns the public share URL for a lead, regenerating the token on demand.

// Enable/disable the public link without forgetting the token.

// QR code as a PNG image, generated via a public QR endpoint. We proxy it so
// the front-end can embed without exposing the URL builder logic.

// PUBLIC — what the student sees at /s/:token. No auth. Sanitised payload.
app.get('/api/public/student/:token', (req, res) => {
  const lead = db.prepare("SELECT * FROM leads WHERE public_token=? AND public_enabled=1").get(req.params.token);
  if (!lead) return res.status(404).json({ error: 'This portal link is not active.' });

  const uniApps = db.prepare("SELECT id, university, program, status, application_id, submitted_on, decision_on, notes FROM lead_university_applications WHERE lead_id=? ORDER BY id").all(lead.id);
  const docs = db.prepare(`SELECT id, doc_type, status, notes, file_url, student_uploaded_url, student_uploaded_at, requested_by_student, received_on
                           FROM lead_documents
                           WHERE lead_id=?
                           ORDER BY requested_by_student DESC, id ASC`).all(lead.id);

  res.json({
    student: {
      ref_id: lead.lead_id,
      name: lead.client_name,
      nationality: lead.nationality,
      destination: lead.destination,
      university: lead.university,
      degree: lead.degree,
      major: lead.major,
      intake_term: lead.intake_term,
      application_stage: lead.application_stage,
      visa_deadline: lead.visa_deadline,
      departure_date: lead.departure_date,
      assigned_consultant: lead.assigned_consultant,
      drive_link: lead.drive_link,
      blood_group: lead.blood_group,
    },
    stages: getApplicationStages(),
    universities: uniApps,
    documents: docs.map(d => ({
      id: d.id,
      doc_type: d.doc_type,
      status: d.status,
      requested_by_student: !!d.requested_by_student,
      notes: d.notes,
      file_url: d.file_url,
      student_uploaded_url: d.student_uploaded_url,
      student_uploaded_at: d.student_uploaded_at,
      received_on: d.received_on,
    })),
    updated_at: new Date().toISOString(),
  });
});

// PUBLIC — student attaches a Drive (or any URL) link for a requested doc.
app.post('/api/public/student/:token/documents/:docId', (req, res) => {
  const lead = db.prepare("SELECT * FROM leads WHERE public_token=? AND public_enabled=1").get(req.params.token);
  if (!lead) return res.status(404).json({ error: 'This portal link is not active.' });
  const doc = db.prepare("SELECT * FROM lead_documents WHERE id=? AND lead_id=?").get(req.params.docId, lead.id);
  if (!doc) return res.status(404).json({ error: 'Document not found' });
  const { url, notes } = req.body || {};
  if (!url || !/^https?:\/\//i.test(String(url))) {
    return res.status(400).json({ error: 'A valid http(s) URL is required (e.g. a Google Drive share link).' });
  }
  db.prepare(`UPDATE lead_documents SET
      student_uploaded_url=?, student_uploaded_at=datetime('now'),
      status=CASE WHEN status='pending' THEN 'received' ELSE status END,
      received_on=COALESCE(received_on, date('now')),
      notes=COALESCE(?, notes),
      updated_at=datetime('now')
    WHERE id=?`).run(String(url).trim(), notes ?? null, doc.id);
  logActivity({ type: 'student_doc_upload', actor: { name: lead.client_name }, lead, details: { doc_type: doc.doc_type, url } });
  res.json({ ok: true });
});

// PUBLIC — student sends a short message. Becomes a 'note' in the timeline.
app.post('/api/public/student/:token/message', (req, res) => {
  const lead = db.prepare("SELECT * FROM leads WHERE public_token=? AND public_enabled=1").get(req.params.token);
  if (!lead) return res.status(404).json({ error: 'This portal link is not active.' });
  const { text } = req.body || {};
  if (!text || !String(text).trim()) return res.status(400).json({ error: 'text is required' });
  logActivity({ type: 'note', actor: { name: `${lead.client_name} (Student)` }, lead, details: `[via student portal] ${String(text).trim()}` });
  res.json({ ok: true });
});

// ─────────────────────────────────────────────────────────
// FINANCE
// ─────────────────────────────────────────────────────────
app.post('/api/income', (req, res) => {
  const d = req.body; const month = d.date?.slice(0,7)||null;
  const info = db.prepare(`INSERT INTO income (date,month,category,lead_id,client_name,reference,amount,notes,employee_id) VALUES (@date,@month,@category,@lead_id,@client_name,@reference,@amount,@notes,@employee_id)`).run({ ...d, month, amount: d.amount||0, employee_id: d.employee_id || null });
  const row = db.prepare("SELECT * FROM income WHERE id=?").get(info.lastInsertRowid);
  // Try to attach to a real lead so this payment shows on the lead's timeline.
  const lead = row.lead_id ? db.prepare("SELECT * FROM leads WHERE lead_id=?").get(row.lead_id) : null;
  logActivity({ type: 'payment_recorded', actor: req.user, lead, amount: row.amount, details: { client_name: row.client_name, lead_id: row.lead_id, category: row.category, reference: row.reference } });
  res.json(row);
});



// ─── CASHFLOW (aligned with CashFlow 2026.xlsx) ────────────────────────────
const INCOME_CATEGORIES = [
  'Service Charge', 'File Opening', 'Application Deposit', 'Investment',
  'Marketing', 'Refund', 'Previous Cash', 'Other Income',
];
const EXPENSE_CATEGORIES = [
  'Salary', 'Office Rent', 'Air Ticket', 'Medical', 'App Fee',
  'Meta Marketing', 'Marketing', 'Client Hospitality', 'Visa Fee',
  'Translation Fee', 'Office Supplies', 'Utilities', 'Travel',
  'Mata Support', 'Refund Out', 'Other Expense',
];

// Helper — opening balance for a given month = initial cash + all prior in/out.
function computeOpeningBalance(month) {
  const initial = parseFloat(getConfig('cash_initial')) || 0;
  if (!month) return initial;
  const sumIn  = db.prepare("SELECT COALESCE(SUM(amount),0) AS s FROM income   WHERE month < ? AND (exclude_from_cash IS NULL OR exclude_from_cash = 0)").get(month).s;
  const sumOut = db.prepare("SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE month < ?").get(month).s;
  return initial + sumIn - sumOut;
}

// Categories endpoint — frontend uses these as dropdown presets.

// Set initial cash (admin only) — the one-time opening balance.

// Monthly ledger — what the Excel shows for one month, side by side.
// Includes running balance per row so the table reads like a real cashflow.

// Year view — 12 months at a glance with running cash.

// Investor / partner contributions — derived from income where category='Investment'.
// Tracks both totals by person and time-series.

// ─────────────────────────────────────────────────────────
// EMPLOYEES / ATTENDANCE / KPI  (unchanged from before)
// ─────────────────────────────────────────────────────────
app.post('/api/employees/auto-link', (req, res) => {
  const user = req.user;
  if (!user?.id) return res.status(401).json({ error: 'Unauthorized' });

  // 1. Check if already linked
  let emp = findEmployeeForUser(user);
  if (emp) return res.json({ created: false, employee: emp });

  // 2. Generate a unique emp_id
  const prefix = 'E-';
  const maxEmp = db.prepare("SELECT MAX(CAST(SUBSTR(emp_id,3) AS INTEGER)) as m FROM employees WHERE emp_id LIKE 'E-%'").get();
  const nextNum = (maxEmp?.m || 0) + 1;
  const newEmpId = `${prefix}${String(nextNum).padStart(2, '0')}`;

  // 3. Create employee record using the user's data
  const roleLabel = user.roles?.includes('founder_ceo') ? 'admin' :
                    user.roles?.includes('managing_director') ? 'admin' :
                    user.roles?.includes('consultant') ? 'consultant' : 'manager';

  try {
    const info = db.prepare(
      `INSERT INTO employees (emp_id, name, role, email, phone, salary, active, join_date)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(newEmpId, user.name || user.email.split('@')[0], roleLabel, user.email, null, 0, 'Yes', new Date().toISOString().slice(0, 10));

    emp = db.prepare("SELECT * FROM employees WHERE id=?").get(info.lastInsertRowid);

    // 4. If the users table has an emp_id column, update it too (optional, best-effort)
    try {
      db.prepare("UPDATE users SET emp_id=? WHERE id=?").run(newEmpId, user.id);
    } catch (e) {
      // emp_id column may not exist on users table — that's fine, email match is enough
    }

    res.json({ created: true, employee: emp });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get('/api/employees', (req, res) => res.json(db.prepare("SELECT * FROM employees ORDER BY id").all()));
app.get('/api/employees/active', (req, res) => res.json(db.prepare("SELECT id, emp_id, name, role, email, phone, salary FROM employees WHERE active = 'Yes' OR active IS NULL OR active = '1' ORDER BY name").all()));
app.post('/api/employees', (req, res) => {
  const d = req.body;
  const info = db.prepare(`INSERT INTO employees (emp_id,name,role,email,phone,device_id,salary,active,join_date) VALUES (@emp_id,@name,@role,@email,@phone,@device_id,@salary,@active,@join_date)`).run({ ...d, salary: d.salary||0, active: d.active||'Yes', join_date: d.join_date||null });
  res.json(db.prepare("SELECT * FROM employees WHERE id=?").get(info.lastInsertRowid));
});
app.put('/api/employees/:id', (req, res) => {
  const d = req.body;
  db.prepare(`UPDATE employees SET emp_id=@emp_id,name=@name,role=@role,email=@email,phone=@phone,device_id=@device_id,salary=@salary,active=@active,join_date=@join_date WHERE id=@id`).run({ ...d, id: req.params.id, salary: d.salary||0, join_date: d.join_date||null });
  res.json(db.prepare("SELECT * FROM employees WHERE id=?").get(req.params.id));
});
app.delete('/api/employees/:id', (req, res) => { db.prepare("DELETE FROM employees WHERE id=?").run(req.params.id); res.json({ ok:true }); });

app.get('/api/attendance', (req, res) => {
  const { month, emp_id, date } = req.query;
  const where=[]; const params={};
  if (month)  { where.push("date LIKE @month"); params.month=`${month}%`; }
  if (emp_id) { where.push("emp_id=@emp_id");   params.emp_id=emp_id; }
  if (date)   { where.push("date=@date");        params.date=date; }
  const ws = where.length ? 'WHERE '+where.join(' AND ') : '';
  res.json(db.prepare(`SELECT * FROM attendance ${ws} ORDER BY date DESC, check_in DESC`).all(params));
});
app.post('/api/attendance/checkin', (req, res) => {
  const { emp_id, date, time, device_id, ssid, source } = req.body;
  const emp = db.prepare("SELECT * FROM employees WHERE emp_id=?").get(emp_id);
  if (!emp) return res.status(404).json({ error: 'Employee not found' });
  const existing = db.prepare("SELECT * FROM attendance WHERE emp_id=? AND date=?").get(emp_id, date);
  if (existing) return res.status(409).json({ error: 'Already checked in', record: existing });
  const openHHMM = getConfig('office_open')||'11:00', grace = parseInt(getConfig('grace_minutes')||'30');
  const [oh,om] = openHHMM.split(':').map(Number);
  const [ch,cm] = (time||'00:00').split(':').map(Number);
  const status = (ch*60+cm) <= (oh*60+om+grace) ? 'Present' : 'Late';
  const info = db.prepare(`INSERT INTO attendance (emp_id,name,date,check_in,status,device_id,ssid,source) VALUES (?,?,?,?,?,?,?,?)`).run(emp_id, emp.name, date, time, status, device_id||emp.device_id, ssid||'', source||'manual');
  res.json(db.prepare("SELECT * FROM attendance WHERE id=?").get(info.lastInsertRowid));
});
app.put('/api/attendance/:id/checkout', (req, res) => {
  const { time } = req.body;
  const rec = db.prepare("SELECT * FROM attendance WHERE id=?").get(req.params.id);
  if (!rec) return res.status(404).json({ error: 'Not found' });
  let hours_worked = null;
  if (rec.check_in && time) {
    const [ih,im] = rec.check_in.split(':').map(Number);
    const [oh,om] = time.split(':').map(Number);
    hours_worked = Math.max(0, (oh*60+om - (ih*60+im)) / 60);
  }
  db.prepare("UPDATE attendance SET check_out=?,hours_worked=? WHERE id=?").run(time, hours_worked, req.params.id);
  res.json(db.prepare("SELECT * FROM attendance WHERE id=?").get(req.params.id));
});
app.post('/api/attendance', (req, res) => {
  const d = req.body;
  const emp = db.prepare("SELECT * FROM employees WHERE emp_id=?").get(d.emp_id);
  const info = db.prepare(`INSERT INTO attendance (emp_id,name,date,check_in,check_out,hours_worked,status,device_id,ssid,source,notes) VALUES (@emp_id,@name,@date,@check_in,@check_out,@hours_worked,@status,@device_id,@ssid,@source,@notes)`).run({ emp_id: d.emp_id, name: emp?.name||d.name||'', date: d.date, check_in: d.check_in||d.time, check_out: d.check_out||null, hours_worked: d.hours_worked||null, status: d.status||'Present', device_id: d.device_id||'', ssid: d.ssid||'', source: d.source||'manual', notes: d.notes||null });
  res.json(db.prepare("SELECT * FROM attendance WHERE id=?").get(info.lastInsertRowid));
});
app.put('/api/attendance/:id', (req, res) => {
  const d = req.body;
  db.prepare(`UPDATE attendance SET check_in=@check_in,check_out=@check_out,hours_worked=@hours_worked,status=@status,notes=@notes WHERE id=@id`).run({ ...d, id: req.params.id });
  res.json(db.prepare("SELECT * FROM attendance WHERE id=?").get(req.params.id));
});
app.delete('/api/attendance/:id', (req, res) => { db.prepare("DELETE FROM attendance WHERE id=?").run(req.params.id); res.json({ ok:true }); });

app.get('/api/attendance/summary/:month', (req, res) => {
  const { month } = req.params;
  const [y,m] = month.split('-').map(Number);
  const daysInMonth = new Date(y,m,0).getDate();
  let workingDays = 0;
  for (let d=1; d<=daysInMonth; d++) { const dow = new Date(y,m-1,d).getDay(); if (dow!==5&&dow!==6) workingDays++; }
  const employees = db.prepare("SELECT * FROM employees WHERE active='Yes'").all();
  const summary = employees.map(emp => {
    const logs = db.prepare("SELECT * FROM attendance WHERE emp_id=? AND date LIKE ?").all(emp.emp_id, `${month}%`);
    const present = logs.filter(l=>l.status==='Present').length;
    const late    = logs.filter(l=>l.status==='Late').length;
    const absent  = Math.max(0, workingDays-present-late);
    const totalHours = logs.reduce((s,l)=>s+(l.hours_worked||0),0);
    const avgCheckin = logs.filter(l=>l.check_in).map(l=>l.check_in).sort()[Math.floor(logs.length/2)]||null;
    return { ...emp, present, late, absent, workingDays, totalHours: totalHours.toFixed(1), avgCheckin, attendancePct: workingDays>0?Math.round(((present+late)/workingDays)*100):0, logs };
  });
  res.json({ summary, workingDays });
});

app.get('/api/kpi/:month', (req, res) => {
  const { month } = req.params;
  const user = req.user;

  let consultants;
  if (canViewOwnLeadsOnly(user)) {
    // Consultant: only their own KPI
    const me = user.consultant_name || user.name || '';
    consultants = [me];
  } else {
    // Admin, MD, Investor, App Manager, Marketing Manager: all consultants
    consultants = db.prepare("SELECT DISTINCT assigned_consultant FROM leads WHERE assigned_consultant IS NOT NULL AND assigned_consultant != ''").all().map(r=>r.assigned_consultant);
  }

  res.json(consultants.map(c => {
    const total = db.prepare("SELECT COUNT(*) as n FROM leads WHERE assigned_consultant=?").get(c).n;
    const thisMonth = db.prepare("SELECT COUNT(*) as n FROM leads WHERE assigned_consultant=? AND (date_added LIKE ? OR created_at LIKE ?)").get(c,`${month}%`,`${month}%`).n;
    const byStatus = Object.fromEntries(db.prepare("SELECT lead_status,COUNT(*) as n FROM leads WHERE assigned_consultant=? GROUP BY lead_status").all(c).map(r=>[r.lead_status,r.n]));
    const revenue  = db.prepare("SELECT SUM(service_fee) as s FROM leads WHERE assigned_consultant=?").get(c).s||0;
    const collected= db.prepare("SELECT SUM(paid) as s FROM leads WHERE assigned_consultant=?").get(c).s||0;
    const target   = db.prepare("SELECT * FROM kpi_targets WHERE consultant=? AND month=?").get(c,month)||{};
    return { consultant:c, total, thisMonth, enrolled:byStatus['Enrolled']||0, fileOpened:byStatus['File Opened']||0, officeVisited:byStatus['Office Visited']||0, positive:byStatus['Positive']||0, notInterested:byStatus['Not Interested']||0, revenue, collected, conversionRate: total>0?((( byStatus['File Opened']||0)/total)*100).toFixed(1):0, responseRate: total>0?(((total-(byStatus['No Response']||0))/total)*100).toFixed(1):0, target_leads:target.target_leads||0, target_enrolled:target.target_enrolled||0, target_revenue:target.target_revenue||0 };
  }));
});
app.put('/api/kpi/targets', (req, res) => {
  const { consultant, month, target_leads, target_enrolled, target_revenue } = req.body;
  if (!consultant || !month) return res.status(400).json({ error: 'consultant and month are required' });
  try {
    db.prepare(`INSERT INTO kpi_targets (consultant,month,target_leads,target_enrolled,target_revenue) VALUES (?,?,?,?,?) ON CONFLICT(consultant,month) DO UPDATE SET target_leads=excluded.target_leads,target_enrolled=excluded.target_enrolled,target_revenue=excluded.target_revenue`).run(consultant, month, Number(target_leads)||0, Number(target_enrolled)||0, Number(target_revenue)||0);
    const saved = db.prepare("SELECT * FROM kpi_targets WHERE consultant=? AND month=?").get(consultant, month);
    res.json({ ok: true, saved });
  } catch(e) {
    console.error('[kpi/targets]', e.message);
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────
// PAYROLL
// ─────────────────────────────────────────────────────────
function workingDaysInMonth(month) {
  const [y, m] = month.split('-').map(Number);
  const days = new Date(y, m, 0).getDate();
  let wd = 0;
  for (let d = 1; d <= days; d++) { const dow = new Date(y, m - 1, d).getDay(); if (dow !== 5 && dow !== 6) wd++; }
  return wd;
}

// Auto-record payroll payment as an expense in Finance
function logPayrollExpense(row) {
  if (!row || row.status !== 'paid') return;
  const date = row.paid_on || new Date().toISOString().slice(0, 10);
  const expenseMonth = date.slice(0, 7);

  // Check if expense already exists to prevent duplicate entries by looking up the unique reference "Salary - YYYY-MM"
  const existing = db.prepare("SELECT * FROM expenses WHERE category='Salary' AND paid_to=? AND reference=?")
    .get(row.name, `Salary - ${row.month}`);
  
  if (existing) {
    db.prepare(`UPDATE expenses SET 
                  date = ?, 
                  month = ?, 
                  amount = ?, 
                  notes = ? 
                WHERE id = ?`)
      .run(
        date,
        expenseMonth,
        row.net_pay || 0,
        row.notes || `Salary payment for ${row.month}`,
        existing.id
      );
  } else {
    db.prepare(`INSERT INTO expenses (date, month, category, paid_to, reference, amount, notes)
                VALUES (?, ?, 'Salary', ?, ?, ?, ?)`)
      .run(
        date,
        expenseMonth,
        row.name,
        `Salary - ${row.month}`,
        row.net_pay || 0,
        row.notes || `Salary payment for ${row.month}`
      );
  }
  
  // Log activity
  logActivity({
    type: 'expense_recorded',
    actor: { name: 'System' },
    amount: row.net_pay,
    to: row.name,
    details: `Auto-recorded salary expense for ${row.month}`
  });
}

// List payroll entries for a month (auto-creates rows for active employees if missing)
app.get('/api/payroll', (req, res) => requireAdmin(req, res, () => {
  const month = req.query.month || new Date().toISOString().slice(0, 7);
  const wd = workingDaysInMonth(month);
  
  // Generate payroll for all active employees
  const employees = db.prepare("SELECT * FROM employees WHERE active='Yes'").all();
  
  const ensure = db.prepare(`INSERT OR IGNORE INTO payroll
    (month, emp_id, name, base_salary, working_days, days_worked, net_pay)
    VALUES (?, ?, ?, ?, ?, ?, ?)`);
  const recalc = db.prepare("UPDATE payroll SET days_worked=?, working_days=? WHERE month=? AND emp_id=? AND name=?");

  for (const emp of employees) {
    const present = db.prepare("SELECT COUNT(*) as n FROM attendance WHERE emp_id=? AND date LIKE ? AND (status='Present' OR status='Late')")
      .get(emp.emp_id, `${month}%`).n;
    ensure.run(month, emp.emp_id, emp.name, emp.salary || 0, wd, present, emp.salary || 0);
    recalc.run(present, wd, month, emp.emp_id, emp.name);
  }

  // Fetch all active employees' payrolls for the month
  const activeEmpNames = employees.map(e => e.name);
  const placeholders = activeEmpNames.map(() => '?').join(',');
  const rows = db.prepare(`SELECT * FROM payroll WHERE month=? AND name IN (${placeholders}) ORDER BY name`).all(month, ...activeEmpNames);

  // Defensive deduplication to ensure same name is never shown twice in payroll
  const seen = new Set();
  const uniqueRows = [];
  for (const r of rows) {
    const key = `${r.month}-${r.name}`;
    if (seen.has(key)) {
      db.prepare("DELETE FROM payroll WHERE id=?").run(r.id);
    } else {
      seen.add(key);
      uniqueRows.push(r);
    }
  }

  const totals = uniqueRows.reduce((a, r) => ({
    base: a.base + (r.base_salary || 0),
    bonus: a.bonus + (r.bonus || 0),
    deductions: a.deductions + (r.deductions || 0),
    net: a.net + (r.net_pay || 0),
    paid: a.paid + (r.status === 'paid' ? (r.net_pay || 0) : 0),
    pending: a.pending + (r.status !== 'paid' ? (r.net_pay || 0) : 0),
  }), { base: 0, bonus: 0, deductions: 0, net: 0, paid: 0, pending: 0 });

  res.json({ month, workingDays: wd, rows: uniqueRows, totals });
}));

// Adjust a single payroll line (bonus, deductions, status, paid_on, notes)
app.put('/api/payroll/:id', (req, res) => requireAdmin(req, res, () => {
  const cur = db.prepare("SELECT * FROM payroll WHERE id=?").get(req.params.id);
  if (!cur) return res.status(404).json({ error: 'Not found' });
  const { bonus, deductions, status, paid_on, notes, base_salary } = req.body || {};
  const base = (base_salary !== undefined ? Number(base_salary) : cur.base_salary) || 0;
  const b = (bonus      !== undefined ? Number(bonus)      : cur.bonus)      || 0;
  const d = (deductions !== undefined ? Number(deductions) : cur.deductions) || 0;
  const net = base + b - d;
  const stat = status || cur.status;
  const paidOn = (stat === 'paid') ? (paid_on || cur.paid_on || new Date().toISOString().slice(0, 10)) : null;
  db.prepare(`UPDATE payroll SET base_salary=?, bonus=?, deductions=?, net_pay=?, status=?, paid_on=?, notes=? WHERE id=?`)
    .run(base, b, d, net, stat, paidOn, notes ?? cur.notes ?? null, req.params.id);
  
  const updated = db.prepare("SELECT * FROM payroll WHERE id=?").get(req.params.id);
  if (stat === 'paid') {
    logPayrollExpense(updated);
  } else {
    db.prepare("DELETE FROM expenses WHERE category='Salary' AND paid_to=? AND reference=?")
      .run(updated.name, `Salary - ${updated.month}`);
  }
  res.json(updated);
}));

app.post('/api/payroll/:id/mark-paid', (req, res) => requireAdmin(req, res, () => {
  const cur = db.prepare("SELECT * FROM payroll WHERE id=?").get(req.params.id);
  if (!cur) return res.status(404).json({ error: 'Not found' });
  db.prepare("UPDATE payroll SET status='paid', paid_on=COALESCE(paid_on, ?) WHERE id=?")
    .run(new Date().toISOString().slice(0, 10), req.params.id);
  
  const updated = db.prepare("SELECT * FROM payroll WHERE id=?").get(req.params.id);
  logPayrollExpense(updated);
  res.json(updated);
}));

// ─────────────────────────────────────────────────────────
// EMPLOYEE PERFORMANCE — Attendance + Daily Logs + Activity
// ─────────────────────────────────────────────────────────

// Daily log — what an employee writes before they leave for the day.

// Submit (or upsert) today's log for the current user

// "Did I submit today's log?" — used by the dashboard banner

// Employee KPI dashboard — Attendance + Office Work + Activity per employee.
app.get('/api/employee-kpi', (req, res) => requireManagerOrAdmin(req, res, () => {
  const month = req.query.month || new Date().toISOString().slice(0, 7);
  const [y, m] = month.split('-').map(Number);
  const start = `${month}-01`;
  const endDate = new Date(y, m, 0);
  const end = endDate.toISOString().slice(0, 10);
  const today = new Date().toISOString().slice(0, 10);

  // Working days in the month (Sun-Thu = working in Bangladesh, per existing logic)
  const daysInMonth = endDate.getDate();
  let workingDays = 0;
  for (let d = 1; d <= daysInMonth; d++) {
    const dow = new Date(y, m - 1, d).getDay();
    if (dow !== 5 && dow !== 6) workingDays++;
  }
  // Effective working days so far (don't penalise for days that haven't happened yet)
  let effWorking = 0;
  const todayInMonth = today >= start && today <= end;
  const cutoff = todayInMonth ? today : end;
  for (let d = 1; d <= daysInMonth; d++) {
    const date = `${month}-${String(d).padStart(2, '0')}`;
    if (date > cutoff) break;
    const dow = new Date(y, m - 1, d).getDay();
    if (dow !== 5 && dow !== 6) effWorking++;
  }

  const employees = db.prepare("SELECT * FROM employees WHERE active='Yes'").all();
  // Activity types we score against. Weights are intentionally simple.
  const ACT_WEIGHTS = {
    lead_created:              3,
    lead_status_changed:       2,
    lead_assigned:             1,
    lead_payment:              4,
    payment_recorded:          2,
    application_stage_changed: 3,
    uni_app_status:            3,
    reply_to_student:          2,
    note:                      1,
  };
  const ACT_GROUPS = {
    lead_work:    ['lead_created', 'lead_status_changed', 'lead_assigned'],
    payments:     ['lead_payment', 'payment_recorded'],
    application:  ['application_stage_changed', 'uni_app_status'],
    communication:['reply_to_student', 'note'],
  };

  const rows = employees.map(emp => {
    // — Attendance —
    const attLogs = db.prepare("SELECT * FROM attendance WHERE emp_id=? AND date BETWEEN ? AND ?").all(emp.emp_id, start, end);
    const present = attLogs.filter(l => l.status === 'Present').length;
    const late    = attLogs.filter(l => l.status === 'Late').length;
    const absent  = Math.max(0, effWorking - present - late);
    const hours   = attLogs.reduce((s, l) => s + (l.hours_worked || 0), 0);
    const avgIn   = attLogs.filter(l => l.check_in).map(l => l.check_in).sort()[Math.floor(attLogs.length / 2)] || null;
    const attendancePct = effWorking > 0 ? Math.round(((present + late) / effWorking) * 100) : 0;

    // — Office Work (daily logs) —
    const logs = db.prepare("SELECT date FROM daily_logs WHERE emp_id=? AND date BETWEEN ? AND ?").all(emp.emp_id, start, end);
    const logsSubmitted = logs.length;
    // Streak: count back from today (or end of month) however many consecutive days have a log
    let streak = 0;
    {
      const dates = new Set(logs.map(l => l.date));
      const d = new Date(Math.min(new Date(today).getTime(), endDate.getTime()));
      while (true) {
        const ds = d.toISOString().slice(0, 10);
        if (ds < start) break;
        const dow = d.getDay();
        if (dow !== 5 && dow !== 6) {
          if (!dates.has(ds)) break;
          streak++;
        }
        d.setDate(d.getDate() - 1);
      }
    }
    const logPct = effWorking > 0 ? Math.round((logsSubmitted / effWorking) * 100) : 0;

    // — Activity (auto-pulled from activity_log) —
    // Match by both possible identities: user account name and user_id link
    const acts = db.prepare(`
      SELECT type, COUNT(*) as n
      FROM activity_log
      WHERE substr(created_at,1,10) BETWEEN ? AND ?
        AND (actor_name = ? OR actor_user_id IN (SELECT id FROM users WHERE emp_id=? OR LOWER(email)=LOWER(?)))
      GROUP BY type`).all(start, end, emp.name, emp.emp_id, emp.email || '');
    const actByType = {}; acts.forEach(a => actByType[a.type] = a.n);
    let actScore = 0;
    Object.entries(ACT_WEIGHTS).forEach(([type, w]) => actScore += (actByType[type] || 0) * w);
    const groupTotals = Object.fromEntries(Object.entries(ACT_GROUPS).map(([g, types]) =>
      [g, types.reduce((s, t) => s + (actByType[t] || 0), 0)]
    ));
    const totalEvents = Object.values(actByType).reduce((s, n) => s + n, 0);

    // — Composite Score (0-100). Attendance 30 + Office Work 20 + Activity 50.
    // Activity is normalised against a "good day = 12 weighted points" expectation.
    const attendanceScore = Math.min(30, (attendancePct / 100) * 30);
    const logsScore       = Math.min(20, (logPct / 100) * 20);
    const targetActScore  = Math.max(1, effWorking * 12);
    const activityScore   = Math.min(50, (actScore / targetActScore) * 50);
    const score = Math.round(attendanceScore + logsScore + activityScore);

    return {
      id: emp.id,
      emp_id: emp.emp_id, name: emp.name, role: emp.role,
      attendance: { present, late, absent, workingDays: effWorking, totalHours: +hours.toFixed(1), avgCheckIn: avgIn, attendancePct },
      office_work: { logsSubmitted, logPct, streak, effWorking },
      activity:    { total: totalEvents, score: actScore, by_type: actByType, by_group: groupTotals },
      score,
    };
  }).sort((a, b) => b.score - a.score);

  res.json({ month, workingDays, effWorking, employees: rows });
}));

// ─── REPORTS — weekly / monthly performance digest ─────────────────────────
// Comprehensive aggregation across all subsystems in one JSON response so
// the Dashboard can render the whole digest with one fetch.
function dayRangeFor(period, anchorIso) {
  const anchor = new Date(anchorIso + 'T00:00:00Z');
  const day = (d) => new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  if (period === 'week') {
    // ISO-ish week, but office-friendly: Sun → Sat for Bangladesh weeks.
    const dow = anchor.getUTCDay(); // 0 = Sunday
    const start = day(new Date(anchor.getTime() - dow * 86400000));
    const end   = day(new Date(start.getTime() + 6 * 86400000));
    const prevStart = day(new Date(start.getTime() - 7 * 86400000));
    const prevEnd   = day(new Date(end.getTime()   - 7 * 86400000));
    return { start, end, prevStart, prevEnd, label: `${start.toISOString().slice(5,10)}–${end.toISOString().slice(5,10)}`, prevLabel: `${prevStart.toISOString().slice(5,10)}–${prevEnd.toISOString().slice(5,10)}` };
  }
  // month
  const start = new Date(Date.UTC(anchor.getUTCFullYear(), anchor.getUTCMonth(), 1));
  const end   = new Date(Date.UTC(anchor.getUTCFullYear(), anchor.getUTCMonth() + 1, 0));
  const prevStart = new Date(Date.UTC(anchor.getUTCFullYear(), anchor.getUTCMonth() - 1, 1));
  const prevEnd   = new Date(Date.UTC(anchor.getUTCFullYear(), anchor.getUTCMonth(), 0));
  const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  return { start, end, prevStart, prevEnd,
    label: `${monthNames[anchor.getUTCMonth()]} ${anchor.getUTCFullYear()}`,
    prevLabel: `${monthNames[prevStart.getUTCMonth()]} ${prevStart.getUTCFullYear()}`,
  };
}
function isoDate(d) { return d.toISOString().slice(0, 10); }

app.get('/api/reports', (req, res) => requireManagerOrAdmin(req, res, () => {
  const period = req.query.period === 'week' ? 'week' : 'month';
  const anchor = (req.query.date || new Date().toISOString().slice(0, 10)).slice(0, 10);
  const range = dayRangeFor(period, anchor);
  const startStr = isoDate(range.start), endStr = isoDate(range.end);
  const prevStartStr = isoDate(range.prevStart), prevEndStr = isoDate(range.prevEnd);

  // ── Leads ──────────────────────────────────────────────────────────────
  const newLeadsRow = db.prepare(`SELECT COUNT(*) AS n FROM leads
    WHERE (date_added BETWEEN ? AND ?) OR (substr(created_at,1,10) BETWEEN ? AND ?)`).get(startStr, endStr, startStr, endStr);
  const newLeadsPrev = db.prepare(`SELECT COUNT(*) AS n FROM leads
    WHERE (date_added BETWEEN ? AND ?) OR (substr(created_at,1,10) BETWEEN ? AND ?)`).get(prevStartStr, prevEndStr, prevStartStr, prevEndStr);
  const leadsBySource = db.prepare(`SELECT COALESCE(source,'Unknown') AS k, COUNT(*) AS n FROM leads
    WHERE (date_added BETWEEN ? AND ?) OR (substr(created_at,1,10) BETWEEN ? AND ?) GROUP BY source`).all(startStr, endStr, startStr, endStr);
  const leadsByDest = db.prepare(`SELECT COALESCE(destination,'Unknown') AS k, COUNT(*) AS n FROM leads
    WHERE (date_added BETWEEN ? AND ?) OR (substr(created_at,1,10) BETWEEN ? AND ?) GROUP BY destination`).all(startStr, endStr, startStr, endStr);
  const enrolled = db.prepare(`SELECT COUNT(*) AS n FROM activity_log
    WHERE type='lead_status_changed' AND to_value='Enrolled' AND substr(created_at,1,10) BETWEEN ? AND ?`).get(startStr, endStr).n;
  const enrolledPrev = db.prepare(`SELECT COUNT(*) AS n FROM activity_log
    WHERE type='lead_status_changed' AND to_value='Enrolled' AND substr(created_at,1,10) BETWEEN ? AND ?`).get(prevStartStr, prevEndStr).n;

  // ── Applications ───────────────────────────────────────────────────────
  const stagesAdvanced = db.prepare(`SELECT to_value AS stage, COUNT(*) AS n FROM activity_log
    WHERE type='application_stage_changed' AND substr(created_at,1,10) BETWEEN ? AND ? GROUP BY to_value`).all(startStr, endStr);
  const uniMoves = db.prepare(`SELECT to_value AS status, COUNT(*) AS n FROM activity_log
    WHERE type='uni_app_status' AND substr(created_at,1,10) BETWEEN ? AND ? GROUP BY to_value`).all(startStr, endStr);

  // ── Cashflow ───────────────────────────────────────────────────────────
  const cashIn  = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s, COUNT(*) AS c FROM income   WHERE date BETWEEN ? AND ? AND (exclude_from_cash IS NULL OR exclude_from_cash = 0)`).get(startStr, endStr);
  const cashOut = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s, COUNT(*) AS c FROM expenses WHERE date BETWEEN ? AND ?`).get(startStr, endStr);
  const prevIn  = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM income   WHERE date BETWEEN ? AND ? AND (exclude_from_cash IS NULL OR exclude_from_cash = 0)`).get(prevStartStr, prevEndStr).s;
  const prevOut = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE date BETWEEN ? AND ?`).get(prevStartStr, prevEndStr).s;
  const incomeCat  = db.prepare(`SELECT COALESCE(category,'Uncategorised') AS k, SUM(amount) AS v FROM income   WHERE date BETWEEN ? AND ? AND (exclude_from_cash IS NULL OR exclude_from_cash = 0) GROUP BY category ORDER BY v DESC`).all(startStr, endStr);
  const expenseCat = db.prepare(`SELECT COALESCE(category,'Uncategorised') AS k, SUM(amount) AS v FROM expenses WHERE date BETWEEN ? AND ? GROUP BY category ORDER BY v DESC`).all(startStr, endStr);
  const topClients = db.prepare(`SELECT client_name AS k, SUM(amount) AS v FROM income WHERE date BETWEEN ? AND ? AND client_name IS NOT NULL AND (exclude_from_cash IS NULL OR exclude_from_cash = 0) GROUP BY client_name ORDER BY v DESC LIMIT 5`).all(startStr, endStr);
  // Cash position at end of period
  const initial = parseFloat(getConfig('cash_initial')) || 0;
  const priorIn  = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM income   WHERE date < ? AND (exclude_from_cash IS NULL OR exclude_from_cash = 0)`).get(startStr).s;
  const priorOut = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE date < ?`).get(startStr).s;
  const opening = initial + priorIn - priorOut;
  const closing = opening + cashIn.s - cashOut.s;

  // ── Attendance summary ─────────────────────────────────────────────────
  const activeEmps = db.prepare("SELECT COUNT(*) AS n FROM employees WHERE active='Yes'").get().n;
  const attRows = db.prepare(`SELECT emp_id, status FROM attendance WHERE date BETWEEN ? AND ?`).all(startStr, endStr);
  const presentCount = attRows.filter(r => r.status === 'Present' || r.status === 'Late').length;
  const lateCount    = attRows.filter(r => r.status === 'Late').length;
  // Working-day count in the range (Sun-Thu)
  let workingDays = 0;
  for (let d = new Date(range.start); d <= range.end; d.setUTCDate(d.getUTCDate() + 1)) {
    const dow = d.getUTCDay(); if (dow !== 5 && dow !== 6) workingDays++;
  }
  const attendancePct = (activeEmps * workingDays) > 0
    ? Math.round((presentCount / (activeEmps * workingDays)) * 100) : 0;
  const dailyLogsSubmitted = db.prepare(`SELECT COUNT(*) AS n FROM daily_logs WHERE date BETWEEN ? AND ?`).get(startStr, endStr).n;

  // ── Top Performers (this period) ───────────────────────────────────────
  // Use activity-points to rank consultants by ACTOR_NAME
  const ACT_WEIGHTS = { lead_created:3, lead_status_changed:2, lead_assigned:1, lead_payment:4, payment_recorded:2, application_stage_changed:3, uni_app_status:3, reply_to_student:2, note:1 };
  const actorRows = db.prepare(`SELECT actor_name, type, COUNT(*) AS n FROM activity_log
    WHERE substr(created_at,1,10) BETWEEN ? AND ? AND actor_name IS NOT NULL AND actor_name != 'System'
    GROUP BY actor_name, type`).all(startStr, endStr);
  const byActor = {};
  actorRows.forEach(r => {
    if (!byActor[r.actor_name]) byActor[r.actor_name] = { name: r.actor_name, points: 0, events: 0, by_type: {} };
    byActor[r.actor_name].events += r.n;
    byActor[r.actor_name].points += (ACT_WEIGHTS[r.type] || 0) * r.n;
    byActor[r.actor_name].by_type[r.type] = r.n;
  });
  const topPerformers = Object.values(byActor).sort((a, b) => b.points - a.points).slice(0, 5);

  // ── Highlights — notable single events ─────────────────────────────────
  const highlights = [];
  const enrollEvents = db.prepare(`SELECT lead_name, actor_name, created_at FROM activity_log
    WHERE type='lead_status_changed' AND to_value='Enrolled' AND substr(created_at,1,10) BETWEEN ? AND ?
    ORDER BY id DESC LIMIT 3`).all(startStr, endStr);
  enrollEvents.forEach(e => highlights.push({ icon: '🎓', text: `${e.lead_name} enrolled (by ${e.actor_name})` }));

  const bigPays = db.prepare(`SELECT amount, lead_name, actor_name FROM activity_log
    WHERE type IN ('lead_payment','payment_recorded') AND substr(created_at,1,10) BETWEEN ? AND ? AND amount IS NOT NULL
    ORDER BY amount DESC LIMIT 3`).all(startStr, endStr);
  bigPays.forEach(p => highlights.push({ icon: '💰', text: `৳${Number(p.amount).toLocaleString()} payment${p.lead_name ? ` for ${p.lead_name}` : ''}${p.actor_name ? ` (by ${p.actor_name})` : ''}` }));

  const visaApprovals = db.prepare(`SELECT lead_name, actor_name FROM activity_log
    WHERE type='application_stage_changed' AND to_value='visa_approved' AND substr(created_at,1,10) BETWEEN ? AND ?
    ORDER BY id DESC LIMIT 3`).all(startStr, endStr);
  visaApprovals.forEach(v => highlights.push({ icon: '🛂', text: `${v.lead_name} visa approved (by ${v.actor_name})` }));

  const newLeadCount = db.prepare(`SELECT COUNT(*) AS n FROM leads WHERE lead_status='New Lead' AND (((date_added BETWEEN ? AND ?) OR (substr(created_at,1,10) BETWEEN ? AND ?)))`).get(startStr, endStr, startStr, endStr).n;
  const officeVisitCount = db.prepare(`SELECT COUNT(*) AS n FROM leads WHERE lead_status='Office Visited' AND (((date_added BETWEEN ? AND ?) OR (substr(created_at,1,10) BETWEEN ? AND ?)))`).get(startStr, endStr, startStr, endStr).n;
  const fileOpenCount = db.prepare(`SELECT COUNT(*) AS n FROM leads WHERE lead_status='File Opened' AND (((date_added BETWEEN ? AND ?) OR (substr(created_at,1,10) BETWEEN ? AND ?)))`).get(startStr, endStr, startStr, endStr).n;
  const positiveCount = db.prepare(`SELECT COUNT(*) AS n FROM leads WHERE lead_status='Positive' AND (((date_added BETWEEN ? AND ?) OR (substr(created_at,1,10) BETWEEN ? AND ?)))`).get(startStr, endStr, startStr, endStr).n;
  const noResponseCount = db.prepare(`SELECT COUNT(*) AS n FROM leads WHERE lead_status='No Response' AND (((date_added BETWEEN ? AND ?) OR (substr(created_at,1,10) BETWEEN ? AND ?)))`).get(startStr, endStr, startStr, endStr).n;

  const workTimeRow = db.prepare(`SELECT COALESCE(SUM(hours_worked),0) AS total_hours, COALESCE(AVG(hours_worked),0) AS avg_hours FROM attendance WHERE date BETWEEN ? AND ?`).get(startStr, endStr);

  const delta = (cur, prev) => prev === 0 ? (cur > 0 ? 100 : 0) : Math.round(((cur - prev) / prev) * 100);

  res.json({
    period: { type: period, start: startStr, end: endStr, label: range.label,
              previousStart: prevStartStr, previousEnd: prevEndStr, previousLabel: range.prevLabel },
    headline: {
      new_leads:    { current: newLeadsRow.n, previous: newLeadsPrev.n, delta: delta(newLeadsRow.n, newLeadsPrev.n) },
      enrolments:   { current: enrolled, previous: enrolledPrev, delta: delta(enrolled, enrolledPrev) },
      revenue:      { current: cashIn.s,  previous: prevIn,  delta: delta(cashIn.s, prevIn) },
      net_cash:     { current: cashIn.s - cashOut.s, previous: prevIn - prevOut, delta: delta(cashIn.s - cashOut.s, prevIn - prevOut) },
      attendance:   { current: attendancePct },
    },
    leads:         { 
      new: newLeadsRow.n, 
      by_source: leadsBySource, 
      by_destination: leadsByDest, 
      enrolled, 
      conversion_rate: newLeadsRow.n ? Math.round((enrolled / newLeadsRow.n) * 100) : 0,
      by_status: {
        new_lead: newLeadCount,
        office_visit: officeVisitCount,
        file_open: fileOpenCount,
        positive: positiveCount,
        no_response: noResponseCount
      }
    },
    applications:  { stages_advanced: stagesAdvanced, university_moves: uniMoves },
    cashflow:      { opening, in: cashIn.s, out: cashOut.s, net: cashIn.s - cashOut.s, closing,
                     income_by_category: incomeCat, expense_by_category: expenseCat, top_clients: topClients,
                     income_entries: cashIn.c, expense_entries: cashOut.c },
    attendance:    { active_employees: activeEmps, working_days: workingDays, attendance_pct: attendancePct,
                     late_count: lateCount, total_logs: dailyLogsSubmitted,
                     total_hours: Math.round(workTimeRow.total_hours),
                     avg_hours: Number(workTimeRow.avg_hours.toFixed(1)) },
    top_performers: topPerformers,
    highlights,
  });
}));

// Per-employee drilldown — full activity feed + daily logs for one person
app.get('/api/employee-kpi/:emp_id', (req, res) => requireManagerOrAdmin(req, res, () => {
  const month = req.query.month || new Date().toISOString().slice(0, 7);
  const start = `${month}-01`;
  const endDate = new Date(parseInt(month.slice(0, 4)), parseInt(month.slice(5)), 0);
  const end = endDate.toISOString().slice(0, 10);
  const emp = db.prepare("SELECT * FROM employees WHERE emp_id=?").get(req.params.emp_id);
  if (!emp) return res.status(404).json({ error: 'Employee not found' });

  const attendance = db.prepare("SELECT * FROM attendance WHERE emp_id=? AND date BETWEEN ? AND ? ORDER BY date").all(emp.emp_id, start, end);
  const logs       = db.prepare("SELECT * FROM daily_logs WHERE emp_id=? AND date BETWEEN ? AND ? ORDER BY date DESC").all(emp.emp_id, start, end);
  const activity   = db.prepare(`SELECT * FROM activity_log
    WHERE substr(created_at,1,10) BETWEEN ? AND ?
      AND (actor_name = ? OR actor_user_id IN (SELECT id FROM users WHERE emp_id=? OR LOWER(email)=LOWER(?)))
    ORDER BY id DESC LIMIT 500`).all(start, end, emp.name, emp.emp_id, emp.email || '');
  res.json({ employee: emp, month, attendance, logs, activity });
}));

// ─────────────────────────────────────────────────────────
// CHANNELS (WhatsApp accounts, Pages, IG accounts)
// ─────────────────────────────────────────────────────────




// Track in-flight syncs so a channel can't be synced twice at once.
const activeSyncs = new Set();

// Helper to resolve dynamic Page Access Token using System User token if needed
async function resolvePageAccessToken(pageId, configuredToken) {
  if (!pageId || !configuredToken) return configuredToken;
  try {
    const res = await fetch(`https://graph.facebook.com/v19.0/${pageId}?fields=access_token&access_token=${configuredToken}`);
    const data = await res.json();
    if (data.access_token) {
      console.log(`[facebook] Dynamically resolved Page Access Token for Page ID: ${pageId}`);
      return data.access_token;
    } else if (data.error) {
      console.warn(`[facebook] Token resolution API returned error for Page ID ${pageId}: ${data.error.message}`);
    }
  } catch (err) {
    console.error(`[facebook] Network error resolving Page Access Token for Page ID ${pageId}:`, err.message);
  }
  return configuredToken;
}

// Helper to sync channel name & avatar from Graph API
async function syncChannelMetadata(channelId) {
  const channel = db.prepare("SELECT * FROM channels WHERE id=?").get(channelId);
  if (!channel) return;
  let token = channel.access_token || getConfig('page_access_token');
  if (!token) return;

  if (channel.type === 'messenger' || channel.type === 'instagram') {
    const pageId = channel.page_id;
    if (!pageId) return;
    try {
      const effectiveToken = await resolvePageAccessToken(pageId, token);
      const res = await fetch(`https://graph.facebook.com/v19.0/${pageId}?fields=name,picture.type(large)&access_token=${effectiveToken}`);
      const data = await res.json();
      if (data.name) {
        const avatarUrl = data.picture?.data?.url || null;
        db.prepare("UPDATE channels SET name = ?, avatar_url = ? WHERE id = ?").run(data.name, avatarUrl, channelId);
        console.log(`[channel-metadata] Updated messenger/instagram channel ${channelId} (${data.name}) avatar: ${avatarUrl ? 'yes' : 'no'}`);
      }
    } catch (err) {
      console.warn(`[channel-metadata] Error syncing messenger/instagram channel ${channelId}:`, err.message);
    }
  } else if (channel.type === 'whatsapp') {
    const phoneId = channel.phone_number_id;
    if (!phoneId) return;
    try {
      const res = await fetch(`https://graph.facebook.com/v19.0/${phoneId}/whatsapp_business_profile?fields=profile_picture_url&access_token=${token}`);
      const data = await res.json();
      const avatarUrl = data.data?.[0]?.profile_picture_url || null;
      if (avatarUrl) {
        db.prepare("UPDATE channels SET avatar_url = ? WHERE id = ?").run(avatarUrl, channelId);
        console.log(`[channel-metadata] Updated WhatsApp channel ${channelId} avatar: yes`);
      }
    } catch (err) {
      console.warn(`[channel-metadata] Error syncing WhatsApp channel ${channelId}:`, err.message);
    }
  }
}

// Helper to sync historical messages from Facebook/Instagram Page Channel
async function syncChannelMessages(channelId, months = 6, maxConvs = 100) {
  const channel = db.prepare("SELECT * FROM channels WHERE id=?").get(channelId);
  if (!channel) return { imported: 0, skipped: 0 };
  if (channel.type === 'tiktok') {
    console.log(`[sync] Skipping TikTok channel ${channel.name} (id=${channelId}) — sync not yet supported`);
    return { imported: 0, skipped: 0, reason: 'tiktok_not_supported' };
  }
  if (channel.type !== 'messenger' && channel.type !== 'instagram') return { imported: 0, skipped: 0 };

  // Fallback: use global page_access_token if channel-level token is missing
  let token = channel.access_token || getConfig('page_access_token');
  if (!token) {
    console.error(`[sync] No access token for channel ${channel.name} (id=${channelId})`);
    return { imported: 0, skipped: 0 };
  }

  const pageId = channel.page_id;
  if (!pageId) {
    console.error(`[sync] No page_id for channel ${channel.name} (id=${channelId}) — cannot call conversations API`);
    return { imported: 0, skipped: 0 };
  }

  // Dynamically resolve the Page Access Token from the configured token (e.g. System User token)
  token = await resolvePageAccessToken(pageId, token);

  const since   = Math.floor(Date.now() / 1000) - (months * 30 * 24 * 3600);

  const MAX_MESSAGES = 5000;
  let imported = 0, skipped = 0, conversations = 0;

  async function fbGet(url, label = 'FB API') {
    const r = await fetch(url);
    const d = await r.json();
    if (d.error) {
      console.error(`[sync] ${label} error: code=${d.error.code} subcode=${d.error.error_subcode} msg=${d.error.message}`);
      throw new Error(`${label}: ${d.error.message}`);
    }
    if (!d.data) {
      console.warn(`[sync] ${label} returned no data field. Response keys: ${Object.keys(d).join(', ')}`);
    }
    // Log first item for debugging when data is empty or suspicious
    if (Array.isArray(d.data) && d.data.length > 0) {
      console.log(`[sync] ${label}: ${d.data.length} items, first id=${d.data[0]?.id}, updated=${d.data[0]?.updated_time || d.data[0]?.created_time}`);
    } else if (Array.isArray(d.data)) {
      console.log(`[sync] ${label}: 0 items returned`);
    }
    return { items: d.data || [], nextUrl: d.paging?.next || null };
  }

  const stmtInsertMsg = db.prepare(
    `INSERT OR IGNORE INTO messages
       (conversation_id, direction, type, content, media_url, wa_message_id, status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, 'delivered', ?)`
  );
  const stmtConvUpdate = db.prepare(
    `UPDATE conversations SET last_message=?, last_message_at=?
     WHERE id=? AND (last_message_at IS NULL OR last_message_at < ?)`
  );
  const stmtIncrementUnread = db.prepare(
    `UPDATE conversations SET unread_count = unread_count + 1 WHERE id=?`
  );

  const insertBatch = db.transaction((rows, conv) => {
    let added = 0;
    for (let i = 0; i < rows.length; i++) {
      const msg = rows[i];
      const fromPage = String(msg.from?.id) === String(pageId);

      let content, type = 'text', mediaUrl = null;
      const att = msg.attachments?.data?.[0];
      if (msg.message) {
        content = msg.message;
      } else if (msg.sticker) {
        content = '😊 Sticker'; type = 'sticker'; mediaUrl = msg.sticker;
      } else if (att) {
        const mime = att.mime_type || '';
        mediaUrl = att.image_data?.url || att.video_data?.url || att.file_url || null;
        if (mime.startsWith('image'))      { content = '📷 Photo';      type = 'image'; }
        else if (mime.startsWith('video')) { content = '🎥 Video';      type = 'video'; }
        else if (mime.startsWith('audio')) { content = '🎵 Audio';      type = 'audio'; }
        else                               { content = `📎 ${att.name || 'File'}`; type = 'file'; }
      } else {
        content = '[message]';
      }

      const createdAt = msg.created_time
        ? new Date(msg.created_time).toISOString().replace('T', ' ').slice(0, 19)
        : null;

      try {
        const result = stmtInsertMsg.run(
          conv.id, fromPage ? 'out' : 'in', type, content, mediaUrl, msg.id, createdAt
        );
        if (result.changes > 0) {
          added++;
          if (createdAt) stmtConvUpdate.run(content, createdAt, conv.id, createdAt);
          if (!fromPage) stmtIncrementUnread.run(conv.id);
        } else if (i === 0) {
          console.log(`[sync] insertBatch: msg.id=${msg.id} skipped (changes=0, likely duplicate wa_message_id)`);
        }
      } catch (insertErr) {
        console.error(`[sync] insertBatch error: msg.id=${msg.id}`, insertErr.message);
        // Log first insert error only to avoid console spam
        if (i === 0) console.error(`[sync] First insert error details:`, insertErr);
      }
    }
    return added;
  });

  if (db.pauseSave) db.pauseSave();
  let convCounter = 0;

  const cutoffMs = since * 1000;
  const toSqlTime = (t) => t ? new Date(t).toISOString().replace('T', ' ').slice(0, 19) : null;

  // Determine platform parameter for filtering
  const platform = channel.type === 'instagram' ? 'instagram' : 'messenger';

  try {
    let convUrl = `https://graph.facebook.com/v19.0/${pageId}/conversations`
      + `?platform=${platform}`
      + `&fields=updated_time,participants,snippet`
      + `&limit=50&access_token=${token}`;

    console.log(`[sync] Starting ${channel.name} (${platform}) pageId=${pageId} token=${token.slice(0,14)}...`);

    let stop = false;
    while (convUrl && !stop && imported + skipped < MAX_MESSAGES && conversations < maxConvs) {
      const { items: fbConvs, nextUrl } = await fbGet(convUrl, 'conversations');
      console.log(`[sync] Got ${fbConvs.length} conversations from FB`);
      convUrl = nextUrl;

      for (const fbConv of fbConvs) {
        if (imported + skipped >= MAX_MESSAGES || conversations >= maxConvs) { stop = true; break; }

        if (fbConv.snippet) {
          const s = fbConv.snippet.toLowerCase();
          if (s.includes('commented on') || s.includes('কমেন্ট করেছেন') || s.includes('created this chat') || s.includes('চ্যাটটি তৈরি করেছে')) {
            console.log(`[sync] Skipping comment-reply conversation: "${fbConv.snippet}"`);
            continue;
          }
        }

        const updatedMs = fbConv.updated_time ? new Date(fbConv.updated_time).getTime() : 0;
        if (updatedMs && updatedMs < cutoffMs) { stop = true; break; }

        conversations++;
        const other = (fbConv.participants?.data || []).find(p => String(p.id) !== String(pageId));
        if (!other) continue;

        let avatar = null;
        try {
          const pr = await fetch(`https://graph.facebook.com/v19.0/${other.id}?fields=profile_pic,name&access_token=${token}`);
          const pd = await pr.json();
          if (!pd.error) avatar = pd.profile_pic || null;
          if (pd.name) other.name = pd.name;
        } catch {}

        const contact = upsertContact({ name: other.name || 'Messenger User', messenger_id: other.id, avatar_url: avatar });
        const conv    = upsertConversation(contact.id, channel.id, 'messenger');

        const convTime = toSqlTime(fbConv.updated_time);
        if (convTime) {
          db.prepare(`UPDATE conversations SET last_message=COALESCE(@snip,last_message), last_message_at=@t
                      WHERE id=@id AND (last_message_at IS NULL OR last_message_at < @t)`)
            .run({ snip: fbConv.snippet || null, t: convTime, id: conv.id });
        }

        let msgUrl = `https://graph.facebook.com/v19.0/${fbConv.id}/messages`
          + `?fields=message,from,created_time,sticker,attachments{mime_type,name,image_data,video_data,file_url}`
          + `&limit=25&access_token=${token}`;
        let convMsgCount = 0;

        while (msgUrl && imported + skipped < MAX_MESSAGES && convMsgCount < 50) {
          const { items: msgs, nextUrl: nextMsgUrl } = await fbGet(msgUrl, 'messages');
          msgUrl = nextMsgUrl;
          if (msgs.length === 0) break;

          const oldest = msgs[msgs.length - 1]?.created_time;
          const added = insertBatch(msgs, conv);
          imported += added;
          skipped  += msgs.length - added;
          convMsgCount += msgs.length;
          console.log(`[sync] conv ${conv.id}: ${msgs.length} msgs, ${added} added, ${msgs.length - added} skipped`);
          if (oldest && new Date(oldest).getTime() < cutoffMs) break;
        }

        if (++convCounter % 10 === 0 && db.resumeSave && db.pauseSave) {
          db.resumeSave();
          db.pauseSave();
          broadcast('sync_progress', { channel_id: channel.id, channel: channel.name, conversations, imported });
        }
      }
    }

    const capped = (imported + skipped >= MAX_MESSAGES);
    console.log(`[sync] ${channel.name}: ${conversations} convs, ${imported} imported, ${skipped} skipped${capped ? ' (capped)' : ''}`);
    broadcast('sync_done', { channel_id: channel.id, channel: channel.name, imported, skipped, conversations, capped });
    return { imported, skipped, conversations, capped };

  } catch (e) {
    console.error('[sync] error:', e.message);
    broadcast('sync_error', { channel_id: channel.id, channel: channel.name, error: e.message, imported, conversations });
    throw e;
  } finally {
    if (db.resumeSave) db.resumeSave();
  }
}

// ─── Sync historical messages from a Messenger / Instagram channel ───────────
// Runs in the BACKGROUND and responds immediately — a long sync would otherwise
// exceed nginx's gateway timeout (504). Progress streams over SSE; the inbox
// polling picks up new conversations as they're imported.

// ─────────────────────────────────────────────────────────
// CONTACTS
// ─────────────────────────────────────────────────────────
app.get('/api/contacts', (req, res) => {
  const { search } = req.query;
  const params = {};
  let where = '';
  if (search && search !== 'undefined' && search !== 'null') {
    where = 'WHERE contacts.name LIKE @search OR contacts.phone LIKE @search';
    params.search = `%${search}%`;
  }
  res.json(db.prepare(`SELECT contacts.*, leads.lead_status, leads.lead_id as crm_lead_id, leads.destination FROM contacts LEFT JOIN leads ON leads.id=contacts.lead_id ${where} ORDER BY contacts.id DESC LIMIT 100`).all(params));
});

app.put('/api/contacts/:id', (req, res) => {
  const d = req.body;
  db.prepare(`UPDATE contacts SET name=@name,phone=@phone,email=@email,lead_id=@lead_id WHERE id=@id`).run({ ...d, id: req.params.id });
  res.json(db.prepare("SELECT * FROM contacts WHERE id=?").get(req.params.id));
});

// ─────────────────────────────────────────────────────────
// CONVERSATIONS
// ─────────────────────────────────────────────────────────
const CONV_SELECT = `
  SELECT conversations.*,
    contacts.name  AS contact_name,
    contacts.phone AS contact_phone,
    contacts.avatar_url AS contact_avatar,
    contacts.wa_id, contacts.messenger_id, contacts.instagram_id, contacts.tiktok_id,
    contacts.lead_id AS contact_lead_id,
    channels.name  AS channel_name,
    channels.type  AS channel_type,
    channels.color AS channel_color,
    channels.consultant AS channel_consultant,
    channels.phone_number_id,
    leads.lead_id AS lead_id,
    leads.lead_status,
    leads.destination AS lead_destination,
    leads.assigned_consultant AS lead_assigned_consultant,
    employees.name AS lead_employee_name,
    leads.assigned_employee_id AS lead_assigned_employee_id,
    (SELECT direction FROM messages WHERE conversation_id = conversations.id ORDER BY created_at DESC, id DESC LIMIT 1) AS last_message_direction,
    (SELECT status FROM messages WHERE conversation_id = conversations.id ORDER BY created_at DESC, id DESC LIMIT 1) AS last_message_status,
    (SELECT COUNT(*) FROM messages WHERE conversation_id = conversations.id AND direction = 'out') AS outbound_count
  FROM conversations
  LEFT JOIN contacts  ON contacts.id  = conversations.contact_id
  LEFT JOIN channels  ON channels.id  = conversations.channel_id
  LEFT JOIN leads   ON leads.id     = conversations.lead_id
  LEFT JOIN employees ON employees.id = leads.assigned_employee_id
`;




// Convert conversation contact into a CRM lead (creating new lead or linking to existing)

// ─────────────────────────────────────────────────────────
// MESSAGES
// ─────────────────────────────────────────────────────────

// File upload endpoint for base64 encoded media attachments
app.post('/api/upload', (req, res) => {
  try {
    const { name, data } = req.body;
    if (!name || !data) {
      return res.status(400).json({ error: 'name and data (base64) are required' });
    }
    // Clean filename
    const cleanName = name.replace(/[^a-zA-Z0-9.-]/g, '_');
    const filename = `${Date.now()}_${cleanName}`;
    const filePath = join(UPLOADS_DIR, filename);

    // Decode base64
    const buffer = Buffer.from(data, 'base64');
    writeFileSync(filePath, buffer);

    const protocol = req.headers['x-forwarded-proto'] || 'http';
    const host = req.get('host');
    const fileUrl = `${protocol}://${host}/uploads/${filename}`;

    res.json({
      url: fileUrl,
      relativeUrl: `/uploads/${filename}`,
      name: filename
    });
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Send message

// ─────────────────────────────────────────────────────────
// QUICK REPLIES
// ─────────────────────────────────────────────────────────
app.get('/api/quick-replies', (req, res) => res.json(db.prepare("SELECT * FROM quick_replies ORDER BY category, title").all()));
app.post('/api/quick-replies', (req, res) => {
  const { title, content, category } = req.body;
  const info = db.prepare("INSERT INTO quick_replies (title,content,category) VALUES (?,?,?)").run(title, content, category||null);
  res.json(db.prepare("SELECT * FROM quick_replies WHERE id=?").get(info.lastInsertRowid));
});
app.put('/api/quick-replies/:id', (req, res) => {
  const { title, content, category } = req.body;
  db.prepare("UPDATE quick_replies SET title=?,content=?,category=? WHERE id=?").run(title, content, category||null, req.params.id);
  res.json(db.prepare("SELECT * FROM quick_replies WHERE id=?").get(req.params.id));
});
app.delete('/api/quick-replies/:id', (req, res) => { db.prepare("DELETE FROM quick_replies WHERE id=?").run(req.params.id); res.json({ ok:true }); });

// ─────────────────────────────────────────────────────────
// WEBSITE LEAD INGESTION WEBHOOK (public)
// ─────────────────────────────────────────────────────────
app.post('/api/webhook/website-lead', async (req, res) => {
  try {
    const { name, phone, email, destination, source, referrer, message, page_url } = req.body || {};
    if (!name) return res.status(400).json({ error: 'name is required' });
    const lead_id = nextLeadId();
    let assigned_consultant = null;
    let leadSource = 'Website';
    let actualSource = source || null;
    let actualDestination = destination || null;

    if (source === 'China') {
      assigned_consultant = 'Abdullah Al Rakib';
      actualDestination = actualDestination || 'China';
    } else if (source === 'Bangladesh Office') {
      assigned_consultant = 'Taj Ahmed';
      actualDestination = actualDestination || 'Bangladesh';
      actualSource = actualSource || 'In-House';
    } else if (source === 'B2B') {
      assigned_consultant = 'Tahmid Imam';
      actualDestination = actualDestination || 'Bangladesh';
      actualSource = actualSource || 'B2B';
    }

    const params = leadParams({
      client_name: name,
      phone: phone || null,
      email: email || null,
      destination: actualDestination,
      lead_source: leadSource,
      source: actualSource,
      referrer: referrer || null,
      assigned_consultant,
      notes: message || null,
      event_source_url: page_url || null,
    }, lead_id, 0);

    const info = db.prepare(LEAD_INSERT_SQL).run(params);
    const lead = db.prepare("SELECT * FROM leads WHERE id=?").get(info.lastInsertRowid);

    sendCAPIEvent('Lead', { ...lead, event_source_url: page_url || undefined }).catch(() => {});
    logActivity({ type: 'lead_created', actor: { name: 'Website Webhook' }, lead, details: { source: leadSource, destination: lead.destination, assigned_consultant: lead.assigned_consultant } });
    broadcast('new_lead', { lead });

    res.json({ success: true, lead_id: lead.id });
  } catch (e) {
    console.error('[website-lead] webhook error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────
// META WEBHOOK — WhatsApp + Messenger + Instagram + Lead Ads + TikTok placeholder
// ─────────────────────────────────────────────────────────
app.get('/webhook/meta', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode !== 'subscribe') return res.sendStatus(403);
  // Accept: global config token, any channel's verify token, or common defaults
  const globalToken = getConfig('verify_token') || '';
  const defaults = ['eduexpress2024', 'eduexpress_verify_2024', 'eduexpress', 'verify_token'];
  const channelTokens = db.prepare("SELECT webhook_verify_token FROM channels").all().map(r => r.webhook_verify_token).filter(Boolean);
  const allTokens = [globalToken, ...defaults, ...channelTokens].filter(Boolean);
  if (allTokens.includes(token)) {
    console.log('✅ Meta webhook verified with token:', token);
    return res.status(200).send(challenge);
  }
  console.log('❌ Webhook verify failed. Got:', token, '| Expected one of:', allTokens);
  res.sendStatus(403);
});

app.post('/webhook/meta', async (req, res) => {
  res.sendStatus(200);
  const body = req.body;

  // ── WhatsApp Cloud API ─────────────────────────────────
  if (body.object === 'whatsapp_business_account') {
    for (const entry of body.entry || []) {
      for (const change of entry.changes || []) {
        if (change.field !== 'messages') continue;
        const val = change.value;
        const phoneNumberId = val.metadata?.phone_number_id;
        const channel = db.prepare("SELECT * FROM channels WHERE phone_number_id=? AND type='whatsapp'").get(phoneNumberId);
        if (!channel) { console.log('⚠️ Unknown WA channel:', phoneNumberId); continue; }

        // Delivery/read status updates
        for (const status of val.statuses || []) {
          db.prepare("UPDATE messages SET status=? WHERE wa_message_id=?").run(status.status, status.id);
          const msg = db.prepare("SELECT conversation_id FROM messages WHERE wa_message_id=?").get(status.id);
          if (msg) {
            broadcast('message_status', { wa_message_id: status.id, status: status.status }, (u) => userHasAccessToConversation(u, msg.conversation_id));
          } else {
            broadcast('message_status', { wa_message_id: status.id, status: status.status });
          }
        }

        // Incoming messages
        for (const msg of val.messages || []) {
          const profileName = val.contacts?.find(c=>c.wa_id===msg.from)?.profile?.name || msg.from;
          const contact = upsertContact({ name: profileName, phone: msg.from, wa_id: msg.from });
          const conv    = upsertConversation(contact.id, channel.id, 'whatsapp');

          // If message is from a Meta Paid Ad (Click-to-WhatsApp referral), auto-create a lead
          if (msg.referral && !contact.lead_id) {
            createLeadFromReferral({
              contact,
              channel,
              referralData: msg.referral,
              sourcePlatform: 'whatsapp'
            });
            const updatedContact = db.prepare("SELECT * FROM contacts WHERE id=?").get(contact.id);
            if (updatedContact) contact.lead_id = updatedContact.lead_id;
          }

          let content, type = msg.type, mediaUrl = null, caption = null;
          if (msg.type === 'text')     { content = msg.text?.body; }
          else if (msg.type === 'image')    { mediaUrl = msg.image?.id;    caption = msg.image?.caption; content = '[Image]'; }
          else if (msg.type === 'audio')    { mediaUrl = msg.audio?.id;    content = '[Voice Message]'; }
          else if (msg.type === 'video')    { mediaUrl = msg.video?.id;    caption = msg.video?.caption; content = '[Video]'; }
          else if (msg.type === 'document') { mediaUrl = msg.document?.id; content = `[Document: ${msg.document?.filename||''}]`; }
          else if (msg.type === 'location') { content = `📍 Location: ${msg.location?.latitude},${msg.location?.longitude}`; }
          else if (msg.type === 'button')   { content = msg.button?.text; type='text'; }
          else { content = `[${msg.type}]`; }

          saveInboundMessage(conv.id, content, type, msg.id, mediaUrl, caption);
          // Run automation rules on the incoming message
          const savedMsg = db.prepare("SELECT * FROM messages WHERE conversation_id=? ORDER BY id DESC LIMIT 1").get(conv.id);
          if (savedMsg) {
            executeAutomationRules({ conversation: conv, message: savedMsg, channel, contact });
          }
          const waInCount = db.prepare("SELECT COUNT(*) as n FROM messages WHERE conversation_id=? AND direction='in'").get(conv.id).n;
          if (waInCount === 1) {
            // Forward to n8n — Gemini generates personalised AI welcome
            setImmediate(() => forwardToN8N({
              platform: 'whatsapp',
              conversationId: conv.id,
              senderName: profileName,
              messageText: content || ''
            }));
          }
          console.log(`📱 WA [${channel.name}] ${profileName}: ${content}`);
        }
      }
    }
    return;
  }

  // ── Facebook Page (Messenger + Lead Ads) ───────────────
  if (body.object === 'page') {
    for (const entry of body.entry || []) {
      const pageId = entry.id;

      // Lead Ads
      for (const change of entry.changes || []) {
        if (change.field === 'leadgen') {
          const { leadgen_id, form_id, ad_id } = change.value;
          try {
            const channel = db.prepare("SELECT * FROM channels WHERE (page_id=? OR ig_account_id=?)").get(pageId, pageId);
            const token = channel?.access_token || getConfig('page_access_token');
            if (!token) continue;
            const metaRes = await fetch(`https://graph.facebook.com/v19.0/${leadgen_id}?fields=field_data,ad_id,ad_name,campaign_id,campaign_name,form_id&access_token=${token}`);
            const metaData = await metaRes.json();
            if (metaData.error) continue;
            const fields = {};
            (metaData.field_data||[]).forEach(f => { fields[f.name] = f.values?.[0]||null; });

            // Determine routing based on campaign/ad name
            const campaignName = (metaData.campaign_name || metaData.ad_name || '').toLowerCase();
            let destination = fields.destination || null;
            let source = metaData.campaign_name || 'Meta Ad';
            let assigned_consultant = null;
            if (campaignName.includes('china') || campaignName.includes('chinese') || campaignName.includes('中国')) {
              destination = 'China';
              source = 'China';
              assigned_consultant = 'Abdullah Al Rakib';
            } else if (campaignName.includes('bangladesh') || campaignName.includes('bd') || campaignName.includes('office')) {
              destination = 'Bangladesh';
              source = 'In-House';
              assigned_consultant = 'Taj Ahmed';
            } else if (campaignName.includes('b2b') || campaignName.includes('agent')) {
              destination = 'Bangladesh';
              source = 'B2B';
              assigned_consultant = 'Tahmid Imam';
            }

            const lead_id = nextLeadId();
            const client_name = fields.full_name||fields.name||`${fields.first_name||''} ${fields.last_name||''}`.trim()||'Unknown';
            db.prepare(`INSERT OR IGNORE INTO leads (lead_id,date_added,client_name,phone,email,destination,lead_source,lead_status,meta_lead_id,meta_form_id,meta_ad_id,meta_campaign,source,assigned_consultant,notes)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
              .run(lead_id, new Date().toISOString().slice(0,10), client_name, fields.phone_number||null, fields.email||null, destination,
                source,'New Lead',leadgen_id,form_id,ad_id||null,metaData.campaign_name||null,source,assigned_consultant,JSON.stringify(fields));
            const lead = db.prepare("SELECT * FROM leads WHERE meta_lead_id=?").get(leadgen_id);
            if (lead) {
              sendCAPIEvent('Lead', { ...lead, event_source_url: fields.link_url || fields.page_url || undefined });
              broadcast('new_lead', { lead });

              // Automatically create a contact and conversation if phone is available
              if (lead.phone) {
                const whatsappChannel = getWhatsAppChannelForConsultant(lead.assigned_consultant);
                if (whatsappChannel) {
                  const contact = upsertContact({
                    name: lead.client_name,
                    phone: lead.phone,
                    wa_id: lead.phone,
                    lead_id: lead.id
                  });
                  const conv = upsertConversation(contact.id, whatsappChannel.id, 'whatsapp');
                  db.prepare("UPDATE conversations SET lead_id=? WHERE id=?").run(lead.id, conv.id);

                  // Forward to n8n — Gemini generates personalised AI welcome for Lead Ad
                  setImmediate(() => forwardToN8N({
                    platform: 'whatsapp',
                    conversationId: conv.id,
                    senderName: lead.client_name,
                    messageText: 'New Lead Ad inquiry'
                  }));

                  console.log(`[leadgen] Auto-created WhatsApp conversation for lead ${lead.lead_id}`);
                }
              }
            }
            console.log(`✅ Meta Lead: ${lead_id} — ${client_name}`);
          } catch(e) { console.error('Lead webhook error:', e.message); }
        }
      }

      // Messenger messages
      for (const messaging of entry.messaging || []) {
        if (!messaging.message || messaging.message.is_echo) continue;
        const senderId = messaging.sender.id;
        const channel = db.prepare("SELECT * FROM channels WHERE page_id=? AND type='messenger'").get(pageId);
        if (!channel) continue;

        const contact = db.prepare("SELECT * FROM contacts WHERE messenger_id=?").get(senderId) || upsertContact({ name: `Messenger User`, messenger_id: senderId });
        // Fetch name + profile picture from Messenger API
        try {
          const pageToken = await resolvePageAccessToken(pageId, channel.access_token);
          const nr = await fetch(`https://graph.facebook.com/v19.0/${senderId}?fields=name,profile_pic&access_token=${pageToken}`);
          const nd = await nr.json();
          if (nd.name) db.prepare("UPDATE contacts SET name=? WHERE id=?").run(nd.name, contact.id);
          if (nd.profile_pic) db.prepare("UPDATE contacts SET avatar_url=COALESCE(avatar_url,?) WHERE id=?").run(nd.profile_pic, contact.id);
        } catch {}

        const conv = upsertConversation(contact.id, channel.id, 'messenger');

        const referral = messaging.referral || messaging.message?.referral;
        // If message is from a Meta Paid Ad (Click-to-Messenger referral), auto-create a lead
        if (referral && !contact.lead_id) {
          createLeadFromReferral({
            contact,
            channel,
            referralData: referral,
            sourcePlatform: 'messenger'
          });
          const updatedContact = db.prepare("SELECT * FROM contacts WHERE id=?").get(contact.id);
          if (updatedContact) contact.lead_id = updatedContact.lead_id;
        }

        // Extract text or media attachment
        let text = messaging.message.text, mtype = 'text', murl = null;
        const att = messaging.message.attachments?.[0];
        if (!text && att) {
          murl = att.payload?.url || null;
          if (att.type === 'image')      { text = '📷 Photo';  mtype = 'image'; }
          else if (att.type === 'video') { text = '🎥 Video';  mtype = 'video'; }
          else if (att.type === 'audio') { text = '🎵 Audio';  mtype = 'audio'; }
          else if (att.type === 'file')  { text = '📎 File';   mtype = 'file'; }
          else                           { text = `[${att.type}]`; mtype = att.type || 'text'; }
        }
        if (!text) text = '[message]';
        saveInboundMessage(conv.id, text, mtype, messaging.message.mid, murl);
        // Run automation rules
        const savedMsg = db.prepare("SELECT * FROM messages WHERE conversation_id=? ORDER BY id DESC LIMIT 1").get(conv.id);
        if (savedMsg) {
          executeAutomationRules({ conversation: conv, message: savedMsg, channel, contact });
        }
        const msInCount = db.prepare("SELECT COUNT(*) as n FROM messages WHERE conversation_id=? AND direction='in'").get(conv.id).n;
        if (msInCount === 1) {
          // Forward to n8n — Gemini generates personalised AI welcome
          setImmediate(() => forwardToN8N({
            platform: 'messenger',
            conversationId: conv.id,
            senderName: 'Messenger User', // DB will have real name shortly after
            messageText: text || ''
          }));
        }
        console.log(`💬 Messenger [${channel.name}]: ${text}`);
      }
    }
    return;
  }

  // ── Instagram ──────────────────────────────────────────
  if (body.object === 'instagram') {
    for (const entry of body.entry || []) {
      for (const msg of entry.messaging || []) {
        if (!msg.message || msg.message.is_echo) continue;
        const senderId = msg.sender.id;
        const igAccountId = entry.id;
        const channel = db.prepare("SELECT * FROM channels WHERE ig_account_id=? AND type='instagram'").get(igAccountId);
        if (!channel) continue;

        const contact = db.prepare("SELECT * FROM contacts WHERE instagram_id=?").get(senderId) || upsertContact({ name: `Instagram User`, instagram_id: senderId });
        try {
          const pageToken = await resolvePageAccessToken(channel.page_id, channel.access_token);
          const nr = await fetch(`https://graph.facebook.com/v19.0/${senderId}?fields=name,username&access_token=${pageToken}`);
          const nd = await nr.json();
          if (nd.name || nd.username) db.prepare("UPDATE contacts SET name=? WHERE id=?").run(nd.name||'@'+nd.username, contact.id);
        } catch {}

        const conv = upsertConversation(contact.id, channel.id, 'instagram');

        const referral = msg.referral || msg.message?.referral;
        // If message is from a Meta Paid Ad (Instagram Click-to-Chat referral), auto-create a lead
        if (referral && !contact.lead_id) {
          createLeadFromReferral({
            contact,
            channel,
            referralData: referral,
            sourcePlatform: 'instagram'
          });
          const updatedContact = db.prepare("SELECT * FROM contacts WHERE id=?").get(contact.id);
          if (updatedContact) contact.lead_id = updatedContact.lead_id;
        }
        const text = msg.message.text || '[message]';
        saveInboundMessage(conv.id, text, 'text', msg.message.mid);
        console.log(`📸 Instagram [${channel.name}]: ${text}`);
      }
    }
  }

  // ── TikTok placeholder (future integration) ─────────────
  if (body.object === 'tiktok') {
    console.log('[tiktok] Webhook received but integration not yet implemented.');
  }
});

// ─────────────────────────────────────────────────────────
// META CONFIG + CAPI
// ─────────────────────────────────────────────────────────
app.get('/api/meta/config', (req, res) => {
  const rows = db.prepare("SELECT key,value FROM meta_config").all();
  const config = Object.fromEntries(rows.map(r => [r.key, r.value]));
  if (config.page_access_token) config.page_access_token = config.page_access_token.slice(0,12)+'••••••••';
  if (config.capi_token) config.capi_token = config.capi_token.slice(0,12)+'••••••••';
  res.json(config);
});
app.post('/api/meta/config', (req, res) => {
  const allowed = ['page_access_token','capi_token','pixel_id','app_secret','verify_token','test_event_code','office_open','grace_minutes'];
  for (const [key,value] of Object.entries(req.body)) {
    if (!allowed.includes(key)||!value||value.includes('••')) continue;
    db.prepare("INSERT INTO meta_config (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(key,value);
  }
  res.json({ ok:true });
});
app.post('/api/meta/test-capi', async (req, res) => {
  const result = await sendCAPIEvent(req.body.event_name||'Lead', { lead_id:'TEST-001', phone:'01700000000', email:'test@example.com', client_name:'Test User', destination:'China' });
  res.json(result);
});
app.get('/api/meta/stats', (req, res) => {
  const total = db.prepare("SELECT COUNT(*) as c FROM leads WHERE meta_lead_id IS NOT NULL").get().c;
  const byStatus = db.prepare("SELECT lead_status,COUNT(*) as c FROM leads WHERE meta_lead_id IS NOT NULL GROUP BY lead_status").all();
  const byCampaign = db.prepare("SELECT meta_campaign,COUNT(*) as c FROM leads WHERE meta_campaign IS NOT NULL GROUP BY meta_campaign ORDER BY c DESC").all();
  const recent = db.prepare("SELECT * FROM leads WHERE meta_lead_id IS NOT NULL ORDER BY id DESC LIMIT 10").all();
  res.json({ total, byStatus, byCampaign, recent });
});

// ─────────────────────────────────────────────────────────
// AUTOMATION HUB
// ─────────────────────────────────────────────────────────

// Automation Rules




// Test automation rule

// Message Templates
app.get('/api/templates', (req, res) => requireManagerOrAdmin(req, res, () => {
  const rows = db.prepare("SELECT * FROM message_templates ORDER BY category, usage_count DESC, id DESC").all();
  res.json(rows.map(r => {
    try { r.variables = r.variables ? JSON.parse(r.variables) : []; } catch (e) { r.variables = []; }
    return r;
  }));
}));

app.post('/api/templates', (req, res) => {
  const { name, category, language, content, variables, approved } = req.body || {};
  if (!name || !content) return res.status(400).json({ error: 'name and content are required' });
  const info = db.prepare(`INSERT INTO message_templates (name, category, language, content, variables, approved)
    VALUES (?,?,?,?,?,?)`).run(name, category || 'general', language || 'en', content, variables ? JSON.stringify(variables) : null, approved ?? 0);
  const r = db.prepare("SELECT * FROM message_templates WHERE id=?").get(info.lastInsertRowid);
  try { r.variables = r.variables ? JSON.parse(r.variables) : []; } catch (e) { r.variables = []; }
  res.json(r);
});

app.put('/api/templates/:id', (req, res) => {
  const { name, category, language, content, variables, approved } = req.body || {};
  const cur = db.prepare("SELECT * FROM message_templates WHERE id=?").get(req.params.id);
  if (!cur) return res.status(404).json({ error: 'Not found' });
  db.prepare(`UPDATE message_templates SET name=COALESCE(?,name), category=COALESCE(?,category), language=COALESCE(?,language), content=COALESCE(?,content), variables=COALESCE(?,variables), approved=COALESCE(?,approved) WHERE id=?`)
    .run(name ?? null, category ?? null, language ?? null, content ?? null, variables ? JSON.stringify(variables) : null, approved ?? null, req.params.id);
  const r = db.prepare("SELECT * FROM message_templates WHERE id=?").get(req.params.id);
  try { r.variables = r.variables ? JSON.parse(r.variables) : []; } catch (e) { r.variables = []; }
  res.json(r);
});

app.delete('/api/templates/:id', (req, res) => {
  db.prepare("DELETE FROM message_templates WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

// Contact Tags
app.get('/api/tags', (req, res) => requireManagerOrAdmin(req, res, () => {
  const rows = db.prepare("SELECT * FROM contact_tags ORDER BY name").all();
  const counts = db.prepare("SELECT tag_id, COUNT(*) as c FROM contact_tag_assignments GROUP BY tag_id").all();
  const countMap = Object.fromEntries(counts.map(c => [c.tag_id, c.c]));
  res.json(rows.map(r => ({ ...r, contact_count: countMap[r.id] || 0 })));
}));

app.post('/api/tags', (req, res) => requireAdmin(req, res, () => {
  const { name, color } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name is required' });
  try {
    const info = db.prepare("INSERT INTO contact_tags (name, color) VALUES (?,?)").run(name, color || '#3b82f6');
    res.json(db.prepare("SELECT * FROM contact_tags WHERE id=?").get(info.lastInsertRowid));
  } catch (e) {
    res.status(400).json({ error: e.message.includes('UNIQUE') ? 'Tag name already exists' : e.message });
  }
}));

app.delete('/api/tags/:id', (req, res) => requireAdmin(req, res, () => {
  db.prepare("DELETE FROM contact_tags WHERE id=?").run(req.params.id);
  res.json({ ok: true });
}));

app.get('/api/tags/:id/contacts', (req, res) => requireAdmin(req, res, () => {
  const contacts = db.prepare(`
    SELECT c.* FROM contacts c
    JOIN contact_tag_assignments cta ON cta.contact_id = c.id
    WHERE cta.tag_id = ?
  `).all(req.params.id);
  res.json({ contacts });
}));

// Conversation Notes


// Conversation Tags


// Broadcast Campaigns






// Automation Analytics

// ─────────────────────────────────────────────────────────
// SETTINGS
// ─────────────────────────────────────────────────────────


// ─────────────────────────────────────────────────────────
// MARKETING / SOCIAL AUTOMATION  (admin + manager UI; n8n via x-api-key)
// ─────────────────────────────────────────────────────────
// Access guard: admin, manager, or trusted n8n service (super_admin via x-api-key).
function requireMarketing(req, res, next) {
  if (isFullAdmin(req.user) || userHasAnyRole(req.user, 'marketing_manager') || req.user?.role === 'super_admin') return next();
  return res.status(403).json({ error: 'Marketing access required' });
}
// Keep only whitelisted, present keys from a request body.
function pickFields(body, allowed) {
  const out = {};
  for (const k of allowed) if (body && body[k] !== undefined) out[k] = body[k];
  return out;
}
// Generic CRUD for simple marketing tables.
function marketingCrud(path, table, cols) {
  app.get(`/api/marketing/${path}`, (req, res) => requireMarketing(req, res, () => {
    res.json(db.prepare(`SELECT * FROM ${table} ORDER BY id DESC`).all());
  }));
  app.post(`/api/marketing/${path}`, (req, res) => requireMarketing(req, res, () => {
    const data = pickFields(req.body, cols);
    const keys = Object.keys(data);
    if (!keys.length) return res.status(400).json({ error: 'no valid fields' });
    const info = db.prepare(`INSERT INTO ${table} (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`).run(...keys.map(k => data[k]));
    res.json(db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(info.lastInsertRowid));
  }));
  app.put(`/api/marketing/${path}/:id`, (req, res) => requireMarketing(req, res, () => {
    const data = pickFields(req.body, cols);
    const keys = Object.keys(data);
    if (!keys.length) return res.status(400).json({ error: 'no valid fields' });
    db.prepare(`UPDATE ${table} SET ${keys.map(k => k + '=?').join(',')} WHERE id=?`).run(...keys.map(k => data[k]), req.params.id);
    res.json(db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(req.params.id));
  }));
  app.delete(`/api/marketing/${path}/:id`, (req, res) => requireMarketing(req, res, () => {
    db.prepare(`DELETE FROM ${table} WHERE id=?`).run(req.params.id);
    res.json({ ok: true });
  }));
}

const POST_COLS = ['week','post_date','slot_time','page','pillar','format','hook','body','hashtags','brief','asset_url','status','rejection_reason','published_url','reach','engagement','source'];

// ── Content posts (weekly calendar) ──

// n8n pulls what to publish: approved/asset_ready posts due today or earlier.






// Bulk approve a whole week (drafted + edit -> approved).

// n8n writes a generated week. Replaces only its own un-touched drafts so it never clobbers your edits/approvals.

// ── Simple tables (evergreen, competitors, knowledge base) ──
marketingCrud('evergreen', 'evergreen_bank', ['page_pool','pillar','body','hashtags','asset_url','status']);
marketingCrud('competitors', 'competitor_intel', ['log_date','competitor','channel','observation','link','our_angle','added_by']);
marketingCrud('kb/universities', 'kb_universities', ['name','country','city','programs','intakes','tuition','lang_req','admission_url','brochure_url','partner','notes','last_verified']);
marketingCrud('kb/scholarships', 'kb_scholarships', ['name','country','type','coverage','eligibility','deadline','source_url','status','last_verified','notes']);
marketingCrud('kb/sources', 'kb_sources', ['topic','url','source_type','use_for','date_added','notes']);
marketingCrud('kb/docs', 'kb_docs', ['name','type','destination','drive_url','version','owner','updated_at']);

// ── Brain API pool (rotation state; secrets stay in n8n) ──

// ── Social Media Engine v2.0 — New Tables ──
marketingCrud('research', 'research_intelligence', ['topic','category','urgency','competitor','source_url','source_type','insight_summary','recommended_angle','evidence','status','used_in_post_id','research_date']);
marketingCrud('viral-topics', 'viral_topics', ['topic','platform','hashtag','relevance_score','engagement_velocity','reach_estimate','sentiment','why_viral','recommended_hook','recommended_cta','recommended_pillar','status','used_in_post_id']);
marketingCrud('psychology', 'psychology_profiles', ['segment','pain_points','aspirations','fears','trusted_sources','decision_factors','content_preferences','peak_hours','language_preference','voice_tone','primary_platform','secondary_platform']);
marketingCrud('scripts', 'content_scripts', ['script_name','category','destination','pillar','format','hook','body','cta','duration_seconds','shot_list','on_screen_text','psychology_target','avg_score','usage_count','status']);
marketingCrud('hooks', 'content_hooks', ['hook_text','hook_type','destination','pillar','format','psychology_target','usage_count','avg_reach','avg_engagement','conversion_rate','status']);
marketingCrud('ab-tests', 'ab_tests', ['test_name','variable','variant_a','variant_b','variant_c','page','start_date','end_date','status','a_reach','a_engagement','a_leads','b_reach','b_engagement','b_leads','c_reach','c_engagement','c_leads','winner','winner_confidence','insights']);
marketingCrud('scale-up', 'scale_up_recommendations', ['recommendation_type','title','description','expected_impact','expected_lead_lift','confidence_score','based_on_data','action_items','status','approved_by']);
marketingCrud('publishing-queue', 'publishing_queue', ['post_id','page','platform','scheduled_at','published_at','status','error_message','platform_post_id','platform_post_url','reach','engagement']);
marketingCrud('creative-guidelines', 'creative_guidelines', ['guideline_name','category','platform','specification','examples','do_s','dont_s']);
marketingCrud('offer-sources', 'offer_sources', ['name','url','source_type','description','drive_folder_url','is_active']);

// ── Designer Queue ──

// ── Quality Score ──

// ── Analytics ──








// ── Research Engine Analytics ──


app.get('/api/marketing/research/gap-analysis', (req, res) => requireMarketing(req, res, () => {
  // What competitors post about that we don't
  const competitorTopics = db.prepare(`
    SELECT DISTINCT topic, competitor, category, recommended_angle
    FROM research_intelligence
    WHERE category = 'competitor_move' AND status != 'archived'
    ORDER BY research_date DESC
    LIMIT 100
  `).all();
  const ourPillars = db.prepare(`SELECT DISTINCT pillar FROM content_posts WHERE status IN ('published','scheduled','approved')`).all().map(r => r.pillar);
  const gaps = competitorTopics.filter(ct => !ourPillars.includes(ct.recommended_angle));
  res.json({ competitorTopics, ourPillars, gaps });
}));

// ── Content Factory Data Sources ──




// ── Lead Attribution ──

// ── Publishing Queue / Due (for n8n) ──

// ── LLM Settings ────────────────────────────────────────


// ── LLM Test / Debug Endpoint ────────────────────────────────────────

// ── AI Content Generator ────────────────────────────────────────
// Calls LLM API to generate real content based on user inputs
// Manual publish trigger — queues post and sends to n8n webhook

// n8n callback webhook — reports publish success/failure
// This is called by n8n with x-api-key header (handled by global middleware)

// Retry a failed publish

// Full publishing queue with post details

// ── n8n Config — raw tokens for publishing engine (n8n-only, x-api-key required) ──

// Get publishing configuration (page tokens, platforms)

// ═══════════════════════════════════════════════════════════
//  PROFESSIONAL SMM PIPELINE v3.0 — Campaigns, Pipeline Board, Assets, Comments, Performance
// ═══════════════════════════════════════════════════════════

// ── Campaigns CRUD ────────────────────────────────────────





// ── Pipeline Board — Kanban data grouped by status ─────────

// ── Move post between pipeline stages ─────────────────────

// ── Post Comments ─────────────────────────────────────────



// ── Post Performance (manual entry or webhook sync) ───────


// ── Content Assets ────────────────────────────────────────










// ── Content Calendar Slots ────────────────────────────────────────




// Auto-assign a post to a calendar slot

// ── Auto-Scheduling Engine ────────────────────────────────────────

// ── Best Time Analytics ────────────────────────────────────────


// ── Publishing Schedule (auto-polling endpoint) ────────────────────



// ── Pipeline Logs (audit trail) ──────────────────────────

// ── Dashboard Stats ───────────────────────────────────────

// Catch-all: serve React app for any non-API route (production)
// Express v5 requires '/{*path}' instead of '*'
if (process.env.NODE_ENV === 'production') {
  app.get('/{*path}', (req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.sendFile(join(__dirname, 'dist', 'index.html'));
  });
}

let isBackgroundSyncing = false;

// Background loop to poll Facebook for new messages because webhooks are dropped in Development mode
setInterval(async () => {
  try {
    if (!dbReady || isBackgroundSyncing) return;
    isBackgroundSyncing = true;
    const channels = db.prepare("SELECT id, name, type FROM channels WHERE type IN ('messenger', 'instagram') AND active = 1").all();
    for (const channel of channels) {
      // Run a fast, 1-month sync (max 5 conversations) in the background to prevent WASM OOM crashes
      await syncChannelMessages(channel.id, 1, 5).catch(err => {
        console.warn(`[sync-polling-loop] Sync failed for channel ${channel.name}:`, err.message);
      });
    }
  } catch (err) {
    console.error('[sync-polling-loop] Global error in background loop:', err.message);
  } finally {
    isBackgroundSyncing = false;
  }
}, 15000);
