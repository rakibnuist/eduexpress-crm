import Database from 'better-sqlite3';
import { readFileSync, existsSync, mkdirSync } from 'fs';
import { dirname } from 'path';

let _db = null;

export function isDead() { return false; }

export async function initDatabase(dbPath) {
  // Ensure directory exists
  const dir = dirname(dbPath);
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });

  _db = new Database(dbPath);
  _db.pragma('journal_mode = WAL');

  return {
    pragma(str) {
      try { _db.pragma(str); } catch {}
    },

    exec(sql) {
      const statements = sql.split(';').map(s => s.trim()).filter(Boolean);
      for (const stmt of statements) {
        try {
          _db.prepare(stmt).run();
        } catch (e) {
          if (!e.message.includes('already exists') && !e.message.includes('duplicate column')) {
            console.error('[sqldb] exec stmt failed:', e.message, '\n  →', stmt.slice(0, 80));
          }
        }
      }
    },

    prepare(sql) {
      // better-sqlite3 handles positional and named parameters natively, matching the old API behavior.
      return _db.prepare(sql);
    },

    transaction(fn) {
      // Return a function that executes the transaction
      return _db.transaction(fn);
    },

    // Save methods are no-ops because better-sqlite3 persists immediately.
    flush() {},
    pauseSave() {},
    resumeSave() {},

    tableNames() {
      try {
        const rows = _db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
        return rows.map(r => r.name);
      } catch { return []; }
    },

    close() { _db.close(); },

    export() { return readFileSync(dbPath); }
  };
}
